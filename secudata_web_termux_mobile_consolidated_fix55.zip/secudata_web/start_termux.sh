#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
echo "SECU-DAT Build: fix35-android-safe-500px-capture-shift-20260719"
echo "Server läuft gleich auf 0.0.0.0:8787"
echo "Im Browser besser die WLAN-IP oder localhost nutzen, nicht 0.0.0.0."
python -m secudata_web.app
