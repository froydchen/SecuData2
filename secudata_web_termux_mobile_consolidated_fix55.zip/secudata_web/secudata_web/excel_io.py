from __future__ import annotations

from datetime import datetime, time
from io import BytesIO
from pathlib import Path
from typing import Any, BinaryIO, Optional
import re

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .models import FinalRecord, MeasurementMetadata, MeasurementRaw, Project
from .protocol import decode_protocol_bitfield, decode_protocol_bitfield_from_fields
from .pcdocw_template import PCDOCW_TEMPLATE_ROWS

PACKAGE_ROOT = Path(__file__).resolve().parent.parent
TEMPLATE_PATH = PACKAGE_ROOT / "data" / "0701_template.xlsx"

# Legacy SECU-DAT internal import/export header. Kept so old backups still import.
HEADERS = [
    "createdAt",
    "measurementTimestamp",
    "rpe",
    "rins",
    "ipe",
    "u",
    "isOk",
    "id",
    "geraeteart",
    "hersteller",
    "raumEtage",
    "kunde",
    "typModell",
    "seriennummer",
    "pruefer",
    "zusatztext",
]

PCDOCW_HEADERS = PCDOCW_TEMPLATE_ROWS[3]
PCDOCW_COLS = {name: index for index, name in enumerate(PCDOCW_HEADERS) if name}

# PC.doc/PCDOCW uses numeric ## keys in the second header row.  The PSI raw
# record is therefore mapped to those keys first; the XLSX columns then simply
# read their row-5 key.  That mirrors pcdtemp.x~~ much more closely than a
# hand-built header-name export.
S2N_FIELD_TO_CODE = {
    0: 1,     # Identifikation des Gerätes
    1: 2,     # Kodierung / Bitfeld
    6: 3, 7: 4,       # R-SL MW/GW
    8: 5, 9: 6,       # D-RSL MW/GW
    10: 7, 11: 8,     # R-ISO MW/GW
    12: 9, 13: 10,    # U-ISO MW/GW
    14: 19, 15: 20,   # DI-STR MW/GW
    16: 15, 17: 16,   # UAC MW/GW
    18: 17, 19: 18,   # UDC MW/GW
    20: 11, 21: 12,   # EGA/IEA MW/GW
    28: 13, 29: 14,   # GA/IB MW/GW
}

OLD_0701_FIELD_TO_CODE = {
    0: 1, 1: 2,
    2: 3, 3: 4,
    4: 7, 5: 8,
    6: 9, 7: 10,
    8: 11, 9: 12,
    10: 19, 11: 20,
}

VALUE_LABEL_TO_CODE = {
    "MW R-SL": 3,
    "GW R-SL": 4,
    "MW ΔR-SL": 5,
    "GW ΔR-SL": 6,
    "MW R-ISO": 7,
    "GW R-ISO": 8,
    "MW U-ISO": 9,
    "GW U-ISO": 10,
    "MW EGA": 11,
    "GW EGA": 12,
    "MW EA": 11,
    "GW EA": 12,
    "MW IEA": 11,
    "GW IEA": 12,
    "MW GA": 13,
    "GW GA": 14,
    "MW DI-STR": 19,
    "GW DI-STR": 20,
    "MW UAC": 15,
    "GW UAC": 16,
    "MW UDC": 17,
    "GW UDC": 18,
    "MW RSL": 3,
    "GW RSL": 4,
    "MW RISO": 7,
    "GW RISO": 8,
    "MW UISO": 9,
    "GW UISO": 10,
    "MW ΔI": 19,
    "GW ΔI": 20,
    "RPE": 3,
    "RPE GW": 4,
    "RISO": 7,
    "RISO GW": 8,
    "ISO-U": 9,
    "ISO-U GW": 10,
    "IEA": 11,
    "IEA GW": 12,
    "IDIFF": 19,
    "IDIFF GW": 20,
}

HEADER_FALLBACK_TO_CODE = {
    "Identifikation des Gerätes": 1,
    "Kodierung und Klassifizierung": 2,
    "RPE": 3,
    "RPE GW": 4,
    "RDPE": 5,
    "RDPE GW": 6,
    "RISO": 7,
    "RISO GW": 8,
    "ISO-U": 9,
    "ISO-U GW": 10,
    "IEA": 11,
    "IEA GW": 12,
    "IB": 13,
    "IB GW": 14,
    "UAC MW (SKIII)": 15,
    "UAC GW": 16,
    "UDC MW (SKIII)": 17,
    "UDC GW": 18,
    "IDIFF ": 19,
    "IDIFF GW": 20,
    "##21": 21,
    "Prüfdatum": 22,
    "Uhrzeit": 23,
    "Gerät": 24,
    "Hersteller": 25,
    "Type": 26,
    "Identnummer": 27,
    "Name": 28,
    "Strasse": 29,
    "Postleitzahl": 30,
    "Ort": 31,
    "Schutzklasse": 110,
    "Sichtprüfung SL": 120,
    "Sichtprüfung Isolierteile": 121,
    "Sichtprüfung Gehäuse": 122,
    "Sichtprüfung Anschlussleitung": 123,
    "Sichtprüfung Typschild": 124,
    "Sichtprüfung bestanden": 125,
    "Sichtprüfung Sonstiges": 127,
    "RPE OK": 151,
    "RDPE OK": 152,
    "RISO OK": 153,
    "IEA OK": 154,
    "IB OK": 155,
    "Uklein OK ": 156,
    "IDIFF OK": 157,
    "Prüfergebnis": 159,
    "Gerät geprüft": 164,
    "Intervall": 312,
    "Norm": 322,
    "SN": 321,
    "Prüfsequenz": 330,
    "Bemerkung": 254,
    "Prüfer": 255,
    "Ort der Prüfung": 97,
    "Kundenfirma": 80,
    "internal": 0,
}

DEFAULT_NORM = "DIN VDE 0702"
DEFAULT_INTERVAL_MONTHS = "24"


def export_records_to_bytes(records: list[FinalRecord], project: Optional[Project] = None) -> bytes:
    """Export the active project in PC.doc-compatible 0701/0702 layout.

    The workbook is now based on the real user-provided 0701_template.xlsx so
    all side sheets and existing formatting survive.  Only the data rows on
    sheet ``Prüfdaten`` are rebuilt.
    """
    workbook = _load_export_template()
    sheet = workbook["Prüfdaten"] if "Prüfdaten" in workbook.sheetnames else workbook.active
    _clear_data_rows(sheet, start_row=7)

    headers = [_string(sheet.cell(4, col).value) for col in range(1, sheet.max_column + 1)]
    code_row = [_string(sheet.cell(5, col).value) for col in range(1, sheet.max_column + 1)]
    if not headers or headers[0] != "PCDOCW":
        headers = list(PCDOCW_HEADERS)
        code_row = list(PCDOCW_TEMPLATE_ROWS[4])

    for record in records:
        sheet.append(_record_to_pcdocw_row(record, project, headers, code_row))

    _format_pcdocw_sheet(sheet)

    output = BytesIO()
    workbook.save(output)
    return output.getvalue()


def export_records_to_path(records: list[FinalRecord], path: Path, project: Optional[Project] = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(export_records_to_bytes(records, project=project))


def import_records_from_bytes(payload: bytes) -> list[FinalRecord]:
    workbook = load_workbook(BytesIO(payload), data_only=True)
    sheet = workbook.active
    rows = list(sheet.iter_rows(values_only=True))
    if not rows:
        return []

    first_row = [_string(value) for value in rows[0]]
    if first_row[: len(HEADERS)] == HEADERS:
        return _import_legacy_records(rows)

    header_index = _find_pcdocw_header_row(rows)
    if header_index is not None:
        return _import_pcdocw_records(rows, header_index)

    raise ValueError("Excel-Kopf passt nicht zum erwarteten SECU-DAT- oder PCDOCW-Format.")


def safe_project_filename(project: Optional[Project], fallback: str = "messdaten_export") -> str:
    name = project.name if project else fallback
    cleaned = re.sub(r"[^A-Za-z0-9ÄÖÜäöüß_. -]+", "_", name).strip(" ._")
    return cleaned or fallback


def _load_export_template():
    if TEMPLATE_PATH.exists():
        return load_workbook(TEMPLATE_PATH)
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Prüfdaten"
    for template_row in PCDOCW_TEMPLATE_ROWS:
        sheet.append(list(template_row))
    return workbook


def _clear_data_rows(sheet, start_row: int = 7) -> None:
    if sheet.max_row >= start_row:
        sheet.delete_rows(start_row, sheet.max_row - start_row + 1)


def _record_to_pcdocw_row(
    record: FinalRecord,
    project: Optional[Project],
    headers: list[str],
    code_row: list[str],
) -> list[Any]:
    code_values = _pcdocw_code_values(record, project)
    width = max(len(headers), len(code_row), len(PCDOCW_HEADERS))
    row: list[Any] = [""] * width

    for index in range(width):
        code = _code_from_template_cell(code_row[index] if index < len(code_row) else "")
        header = headers[index] if index < len(headers) else ""
        if code is None:
            code = HEADER_FALLBACK_TO_CODE.get(header)
        if code is not None and code in code_values:
            row[index] = code_values[code]

    # The first PCDOCW column remains empty for data rows in the PC.doc export.
    if row:
        row[0] = ""
    return row


def _code_from_template_cell(value: str) -> Optional[int]:
    text = _string(value)
    match = re.fullmatch(r"##?(\d+)", text)
    if not match:
        return None
    return int(match.group(1))


def _pcdocw_code_values(record: FinalRecord, project: Optional[Project]) -> dict[int, Any]:
    meta = record.metadata
    measurement = record.measurement
    fields = [str(value) for value in (record.raw_fields or [])]
    code_values: dict[int, Any] = {}

    code_values.update(_code_values_from_raw_fields(fields))
    code_values.update(_code_values_from_measurement_items(measurement))

    bits = decode_protocol_bitfield_from_fields(fields)

    # User/project metadata are not invented values: they are explicit project or
    # capture inputs.  They are deliberately limited to the fields required for
    # the current workflow.
    customer = (project.customer if project else meta.kunde).strip()
    project_street = (project.street if project else "").strip()
    project_postal_code = (project.postal_code if project else "").strip()
    project_city = (project.city if project else "").strip()
    project_interval = (project.test_interval_months if project else "").strip()
    project_inspector = (project.inspector if project else "").strip()
    date_text, time_value = _date_time_for_export(measurement.timestamp or record.created_at)
    device = meta.geraeteart.strip()
    manufacturer = meta.hersteller.strip()
    room = meta.raum_etage.strip()
    external_id = meta.id.strip()

    code_values.setdefault(1, "XXXXXXXX")
    if record.raw_protocol and not code_values.get(1):
        code_values[1] = "XXXXXXXX"
    if not code_values.get(2) and fields and len(fields) > 1:
        code_values[2] = _clean_export_value(fields[1])

    # J/K are authoritative local receive time. The PSI clock frequently resets
    # to 01.01.07 12:00 and must never override the reception timestamp.
    code_values[22] = date_text
    code_values[23] = time_value
    code_values[24] = device or code_values.get(24, "") or "-"
    code_values[25] = manufacturer or code_values.get(25, "") or "-"
    code_values[26] = room or code_values.get(26, "") or "-"
    code_values[27] = external_id or code_values.get(27, "") or "-"

    # Correct project master-data columns requested by the user:
    # D/##28 Name, BY/##255 Prüfer, CJ/##312 Intervall, CL-CN/##29-31 address.
    if customer:
        code_values[28] = customer
    if project_inspector:
        code_values[255] = project_inspector
    if project_interval:
        code_values[312] = project_interval
    if project_street:
        code_values[29] = project_street
    if project_postal_code:
        code_values[30] = project_postal_code
    if project_city:
        code_values[31] = project_city

    code_values[0] = "X"

    _apply_bitfield_derived_values(code_values, bits, measurement)

    # PC.doc seems to duplicate the leakage/current value in ##21 for this 0701
    # export.  Only mirror this when the source value is actually present.
    if 21 not in code_values and 11 in code_values:
        code_values[21] = code_values[11]

    # Numeric fallback for simulated/legacy app records without raw PSI fields.
    # For true raw PSI records the bitfield/raw fields win and missing values stay
    # missing instead of being made up.
    if not bits.is_valid:
        if 159 not in code_values:
            code_values[159] = "OK" if measurement.is_ok else "NICHT OK"
        if 164 not in code_values:
            code_values[164] = 1 if measurement.is_ok else ""
        if 3 not in code_values and measurement.rpe is not None:
            code_values[3] = _format_number(measurement.rpe, "Ohm", sign=True)
        if 7 not in code_values and measurement.rins is not None:
            code_values[7] = _format_number(measurement.rins, "MOhm", sign=True)
        if 11 not in code_values and measurement.ipe is not None:
            code_values[11] = _format_number(measurement.ipe, "mA", sign=True)
            code_values.setdefault(21, code_values[11])
    return code_values


def _code_values_from_raw_fields(fields: list[str]) -> dict[int, Any]:
    if len(fields) < 2:
        return {}
    bitfield = fields[1].strip()
    if re.fullmatch(r"[0-9A-Fa-f]{24,}", bitfield):
        field_to_code = S2N_FIELD_TO_CODE
    elif re.fullmatch(r"[0-9A-Fa-f]{16}", bitfield):
        field_to_code = OLD_0701_FIELD_TO_CODE
    else:
        field_to_code = {}

    code_values: dict[int, Any] = {}
    for field_index, code in field_to_code.items():
        if field_index < len(fields):
            value = _clean_export_value(fields[field_index])
            if value:
                code_values[code] = value

    tail = _find_tail_metadata_start(fields)
    if tail is not None:
        tail_map = {
            0: 22,  # protocol text date, as seen in export_test
            1: 23,
            2: 24,
            3: 25,
            4: 26,
            5: 27,
            6: 28,
            7: 29,
            8: 30,
            9: 31,
        }
        for offset, code in tail_map.items():
            index = tail + offset
            if index < len(fields):
                value = _clean_export_value(fields[index])
                if value:
                    code_values[code] = _excel_time_or_text(value) if code == 23 else value
        # Last field is usually the protocol number. Keep it available for raw
        # diagnostics even though it is not displayed in the visible export columns.
        if fields:
            last = _clean_export_value(fields[-1])
            if re.fullmatch(r"\d{4,}", last):
                code_values[75] = last

    return code_values


def _code_values_from_measurement_items(measurement: MeasurementRaw) -> dict[int, Any]:
    result: dict[int, Any] = {}
    for item in measurement.values or []:
        label = _clean_label(item.get("label", ""))
        value = _clean_export_value(item.get("value", ""))
        if not label or not value:
            continue
        code = VALUE_LABEL_TO_CODE.get(label)
        if code is not None:
            result.setdefault(code, value)
    return result


def _clean_label(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip())


def _clean_export_value(value: Any) -> str:
    text = str(value or "").replace("Ω", "Ω")
    text = text.replace("MΩ", "MOhm").replace("Ω", "Ohm")
    text = text.replace("µ", "u").replace("μ", "u")
    return re.sub(r"\s+", " ", text).strip()


def _find_tail_metadata_start(fields: list[str]) -> Optional[int]:
    matches: list[int] = []
    for index in range(max(0, len(fields) - 45), max(0, len(fields) - 1)):
        if _looks_like_date(fields[index]) and _looks_like_time(fields[index + 1]):
            matches.append(index)
    return matches[-1] if matches else None


def _looks_like_date(value: Any) -> bool:
    return bool(re.fullmatch(r"\s*\d{2}[./-]\d{2}[./-]\d{2,4}\s*", str(value or "")))


def _looks_like_time(value: Any) -> bool:
    return bool(re.fullmatch(r"\s*\d{1,2}:\d{2}(?::\d{2})?\s*", str(value or "")))


def _apply_bitfield_derived_values(code_values: dict[int, Any], bits, measurement: MeasurementRaw) -> None:
    if not bits.is_valid:
        return

    protection_class = bits.protection_class
    if protection_class:
        code_values[110] = protection_class

    # L / ##159: result is derived from EE.7, not from a UI default.
    if bits.result_text:
        code_values[159] = bits.result_text
        code_values[164] = 1 if bits.result_text == "OK" else ""

    visual_performed = bits.visual_performed
    if visual_performed is False:
        for code in (120, 121, 122, 123, 124, 125, 127):
            code_values[code] = "-"
    elif visual_performed is True:
        code_values[120] = _visual_result(bits, 0) if protection_class == "I" else "-"
        code_values[121] = _visual_result(bits, 1)
        code_values[122] = _visual_result(bits, 2)
        code_values[123] = _visual_result(bits, 3)
        code_values[124] = _visual_result(bits, 4)
        code_values[127] = _visual_result(bits, 5)
        visual_failed = any(bits.visual_failed(index) for index in range(0, 6))
        code_values[125] = "NICHT OK" if visual_failed else "OK"

    measured_ok_map = {
        0: (151,),       # RSL/RPE
        1: (153,),       # RISO
        2: (154,),       # IEA/EGA
        3: (155,),       # Isonde / IB / Berührstrom
        4: (156, 256, 257),  # UAC/DC / SK III small voltage checks
        5: (157,),       # Differenzstrom
    }
    for measurement_bit, ok_codes in measured_ok_map.items():
        for ok_code in ok_codes:
            if _ok_code_has_source_value(ok_code, code_values) or bits.measured(measurement_bit):
                code_values[ok_code] = _measurement_result(bits, measurement_bit) if bits.measured(measurement_bit) else "-"

    if bits.measured(6):
        code_values[150] = "NICHT OK" if bits.visual_failed(7) else "OK"


def _visual_result(bits, bit_index: int) -> str:
    return "NICHT OK" if bits.visual_failed(bit_index) else "OK"


def _measurement_result(bits, bit_index: int) -> str:
    return "NICHT OK" if bits.failed(bit_index) else "OK"


def _ok_code_has_source_value(ok_code: int, code_values: dict[int, Any]) -> bool:
    source_map = {
        151: (3, 4),
        152: (5, 6),
        153: (7, 8),
        154: (11, 12),
        155: (13, 14),
        156: (15, 16, 17, 18),
        157: (19, 20),
        256: (15, 16),
        257: (17, 18),
    }
    return any(code_values.get(code) not in (None, "") for code in source_map.get(ok_code, ()))


def _date_time_for_export(value: str) -> tuple[str, Any]:
    text = str(value or "").strip()
    if not text:
        now = datetime.now()
        return now.strftime("%d.%m.%y"), time(now.hour, now.minute, now.second)
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%d.%m.%y %H:%M:%S", "%d.%m.%Y %H:%M:%S"):
        try:
            dt = datetime.strptime(text[:19], fmt)
            return dt.strftime("%d.%m.%y"), time(dt.hour, dt.minute, dt.second)
        except ValueError:
            pass
    match = re.search(r"(\d{2}[./-]\d{2}[./-]\d{2,4}).*?(\d{1,2}:\d{2})", text)
    if match:
        return match.group(1).replace("/", ".").replace("-", "."), _excel_time_or_text(match.group(2))
    date_match = re.search(r"\d{2}[./-]\d{2}[./-]\d{2,4}", text)
    time_match = re.search(r"\d{1,2}:\d{2}", text)
    return (date_match.group(0).replace("/", ".").replace("-", ".") if date_match else "", _excel_time_or_text(time_match.group(0)) if time_match else "")


def _excel_time_or_text(value: str) -> Any:
    text = str(value or "").strip()
    for fmt in ("%H:%M:%S", "%H:%M"):
        try:
            parsed = datetime.strptime(text, fmt)
            return time(parsed.hour, parsed.minute, parsed.second)
        except ValueError:
            pass
    return text


def _format_number(value: float, suffix: str, sign: bool = False) -> str:
    prefix = "+" if sign and value >= 0 else ""
    if abs(value) >= 100:
        body = f"{value:.1f}"
    elif abs(value) >= 10:
        body = f"{value:.2f}"
    else:
        body = f"{value:.3f}"
    return f"{prefix}{body}{suffix}"


def _format_pcdocw_sheet(sheet) -> None:
    sheet.freeze_panes = "A7"
    small = Font(name="Arial", size=8)
    header_font = Font(name="Arial", size=8, bold=True)
    grey = PatternFill("solid", fgColor="E8E8E8")
    for row in sheet.iter_rows():
        for cell in row:
            cell.font = small
            cell.alignment = Alignment(vertical="top", wrap_text=False)
    for row_number in (4, 5, 6):
        for cell in sheet[row_number]:
            cell.font = header_font
            cell.fill = grey
            cell.alignment = Alignment(vertical="top", wrap_text=False)
    # Keep the compact PC.doc look from the template/export_test.
    for col_idx in range(1, sheet.max_column + 1):
        header = str(sheet.cell(4, col_idx).value or "")
        width = 10
        if header in {"Name", "Gerät", "Hersteller", "Type", "Bemerkung", "Ort der Prüfung", "Kundenfirma"}:
            width = 18
        if header.startswith("Sichtprüfung") or header.startswith("Reparatur"):
            width = 12
        sheet.column_dimensions[get_column_letter(col_idx)].width = width
    sheet.row_dimensions[4].height = 28
    sheet.row_dimensions[5].height = 18
    sheet.row_dimensions[6].height = 18
    # Time column K is the observed PC.doc time column.
    for row_idx in range(7, sheet.max_row + 1):
        sheet.cell(row_idx, 11).number_format = "h:mm"


def _find_pcdocw_header_row(rows: list[tuple[Any, ...]]) -> Optional[int]:
    for index, row in enumerate(rows[:12]):
        values = [_string(value) for value in row]
        if values and values[0] == "PCDOCW" and "Identnummer" in values:
            return index
    return None


def _import_pcdocw_records(rows: list[tuple[Any, ...]], header_index: int) -> list[FinalRecord]:
    header = [_string(value) for value in rows[header_index]]
    col = {name: index for index, name in enumerate(header) if name}

    def at(row, name: str) -> str:
        idx = col.get(name)
        if idx is None or idx >= len(row):
            return ""
        return _string(row[idx])

    records: list[FinalRecord] = []
    for row in rows[header_index + 3:]:
        if not row or all(_string(value) == "" for value in row):
            continue
        if at(row, "Identifikation des Gerätes").startswith("##") or at(row, "Name") == "#D":
            continue
        if not any(at(row, field) for field in ("Identnummer", "Gerät", "Hersteller", "Prüfdatum", "Uhrzeit")):
            continue

        date_text = at(row, "Prüfdatum")
        time_text = at(row, "Uhrzeit")
        timestamp = _timestamp_from_parts(date_text, time_text)
        values = []
        for label_header in ("RPE", "RPE GW", "RDPE", "RDPE GW", "RISO", "RISO GW", "ISO-U", "ISO-U GW", "IEA", "IEA GW", "IB", "IB GW", "IDIFF ", "IDIFF GW", "UAC MW (SKIII)", "UAC GW", "UDC MW (SKIII)", "UDC GW"):
            value = at(row, label_header)
            if value:
                values.append({"label": label_header.strip(), "value": value})
        bitfield = at(row, "Kodierung und Klassifizierung")
        bits = decode_protocol_bitfield(bitfield)
        is_ok = (not bits.overall_failed) if bits.overall_failed is not None else at(row, "Prüfergebnis").strip().upper() not in {"NICHT OK", "FEHLER", "FAILED", "NIO"}
        records.append(FinalRecord(
            id=0,
            created_at=timestamp,
            measurement=MeasurementRaw(
                rpe=_float_or_none(at(row, "RPE")),
                rins=_float_or_none(at(row, "RISO")),
                ipe=_float_or_none(at(row, "IEA") or at(row, "IB") or at(row, "IDIFF ")),
                u=_float_or_none(at(row, "Spannung L1") or at(row, "UAC MW (SKIII)")),
                timestamp=timestamp,
                is_ok=is_ok,
                values=values,
            ),
            metadata=MeasurementMetadata(
                id=at(row, "Identnummer"),
                geraeteart=at(row, "Gerät"),
                hersteller=at(row, "Hersteller"),
                raum_etage=at(row, "Type") or at(row, "Raum"),
                kunde=at(row, "Name"),
                typ_modell="",
                seriennummer="",
                pruefer="",
                zusatztext="",
            ),
            raw_fields=_raw_fields_from_pcdocw_row(row, col),
            raw_source="PCDOCW_IMPORT",
        ))
    return records


def _raw_fields_from_pcdocw_row(row: tuple[Any, ...], col: dict[str, int]) -> list[str]:
    def at_name(name: str) -> str:
        idx = col.get(name)
        if idx is None or idx >= len(row):
            return ""
        return _string(row[idx])

    bitfield = at_name("Kodierung und Klassifizierung")
    if not bitfield:
        return []
    # Minimal reversible raw skeleton for later xlsx -> raw database workflows.
    # It keeps the load-bearing protocol identity/bitfield and the positional
    # measurement cells we can safely recover from the PCDOCW sheet.
    return [
        at_name("Identifikation des Gerätes") or "XXXXXXXX",
        bitfield,
        at_name("RPE"), at_name("RPE GW"),
        at_name("RDPE"), at_name("RDPE GW"),
        at_name("RISO"), at_name("RISO GW"),
        at_name("ISO-U"), at_name("ISO-U GW"),
        at_name("IEA"), at_name("IEA GW"),
        at_name("IDIFF "), at_name("IDIFF GW"),
    ]


def _import_legacy_records(rows: list[tuple[Any, ...]]) -> list[FinalRecord]:
    records: list[FinalRecord] = []
    for row in rows[1:]:
        if not row or all(value in (None, "") for value in row[: len(HEADERS)]):
            continue
        values = list(row) + [None] * max(0, len(HEADERS) - len(row))
        record = FinalRecord(
            id=0,
            created_at=_string(values[0]),
            measurement=MeasurementRaw(
                rpe=_float_or_none(values[2]),
                rins=_float_or_none(values[3]),
                ipe=_float_or_none(values[4]),
                u=_float_or_none(values[5]),
                timestamp=_string(values[1]),
                is_ok=_bool(values[6]),
            ),
            metadata=MeasurementMetadata(
                id=_string(values[7]),
                geraeteart=_string(values[8]),
                hersteller=_string(values[9]),
                raum_etage=_string(values[10]),
                kunde=_string(values[11]),
                typ_modell=_string(values[12]),
                seriennummer=_string(values[13]),
                pruefer=_string(values[14]),
                zusatztext=_string(values[15]),
            ),
        )
        if not record.created_at or not record.measurement.timestamp:
            raise ValueError("Excel enthält Datensatz ohne Zeitstempel.")
        records.append(record)
    return records


def _timestamp_from_parts(date_text: str, time_text: str) -> str:
    date_text = (date_text or datetime.now().strftime("%d.%m.%y")).replace("/", ".").replace("-", ".")
    if isinstance(time_text, time):
        time_text = time_text.strftime("%H:%M")
    time_text = time_text or "00:00"
    for fmt in ("%d.%m.%y %H:%M", "%d.%m.%Y %H:%M", "%d.%m.%y %H:%M:%S", "%d.%m.%Y %H:%M:%S"):
        try:
            return datetime.strptime(f"{date_text} {time_text}", fmt).isoformat(timespec="seconds")
        except ValueError:
            pass
    return datetime.now().isoformat(timespec="seconds")


def _string(value) -> str:
    if isinstance(value, time):
        return value.strftime("%H:%M")
    return "" if value is None else str(value).strip()


def _float_or_none(value):
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.lower() == "nan":
        return None
    match = re.search(r"[-+]?\d+(?:[,.]\d+)?", text)
    if not match:
        return None
    return float(match.group(0).replace(",", "."))


def _bool(value) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "wahr", "yes", "ja", "ok"}
