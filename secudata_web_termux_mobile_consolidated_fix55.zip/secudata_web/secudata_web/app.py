from __future__ import annotations

import asyncio
import io
from pathlib import Path
from typing import Any, Awaitable, Callable, Optional

import uvicorn
from starlette.applications import Starlette
from starlette.exceptions import HTTPException
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse, StreamingResponse
from starlette.staticfiles import StaticFiles
from starlette.routing import WebSocketRoute
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.websockets import WebSocket, WebSocketDisconnect

from .acquisition import SecutestAcquisitionService
from .client import SecutestClientError, SecutestLiveConnection
from .database import Database
from .dictionaries import (
    build_device_suggestions,
    build_id_suggestions,
    build_manufacturer_suggestions,
    expand_device_abbreviations,
)
from .excel_io import export_records_to_bytes, export_records_to_path, import_records_from_bytes, safe_project_filename
from .models import DraftInputState, MeasurementMetadata, RawProtocolRecord
from .sequences import MeasurementSequenceService
from .state import AppState, EventHub
from .raw_archive import append_raw_protocol, raw_archive_bytes
from .protocol import reset_button_hint_from_fields


PACKAGE_ROOT = Path(__file__).resolve().parent.parent
STATIC_DIR = PACKAGE_ROOT / "static"
DATA_DIR = PACKAGE_ROOT / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "secudata_web.db"

app = Starlette(debug=False)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

# Starlette has changed/de-emphasized decorator helpers across versions.
# Keep the route definitions below readable by providing tiny compatibility
# decorators that use Starlette's stable add_* methods internally.
def _route(path: str, methods: list[str] | None = None):
    def decorator(func):
        app.add_route(path, func, methods=methods)
        return func
    return decorator


def _websocket_route(path: str):
    def decorator(func):
        # Termux/Android can ship Starlette versions where the decorator helper
        # exists, but add_websocket_route() does not. Appending a WebSocketRoute
        # is stable across those versions. Ja, Versionstabellen-Bingo.
        app.routes.append(WebSocketRoute(path, func))
        return func
    return decorator


def _exception_handler(exc_class_or_status_code):
    def decorator(func):
        app.add_exception_handler(exc_class_or_status_code, func)
        return func
    return decorator


app.route = _route  # type: ignore[attr-defined]
app.websocket_route = _websocket_route  # type: ignore[attr-defined]
app.exception_handler = _exception_handler  # type: ignore[attr-defined]

class NoCacheMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        # Local field tool: stale JS/CSS is worse than an extra few milliseconds.
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response


app.add_middleware(NoCacheMiddleware)

database = Database(DB_PATH)
events = EventHub()
state = AppState(database, events)
client = SecutestLiveConnection(database, state)
acquisition = SecutestAcquisitionService(client)
sequences = MeasurementSequenceService(acquisition, database, state)
listen_task: Optional[asyncio.Task] = None
psi_action_lock = asyncio.Lock()


async def _detect_connected_device_topology() -> dict[str, str]:
    info = await acquisition.detect_connection_topology()
    topology = info.get("topology", "unknown")
    identity = info.get("identity", "")
    await state.set_connection_topology(topology, identity)
    if topology == "psi":
        label = "PSI"
    elif topology == "direct_secutest":
        label = "SECUTEST direkt"
    else:
        label = "unbekannt"
    await state.append_log(f"[IDN] Verbindungstopologie erkannt: {label} · {identity}")
    return info


async def _connect_and_detect_topology() -> dict[str, str]:
    await client.connect()
    return await _detect_connected_device_topology()


# =========================================================
# JSON / validation helpers
# =========================================================

async def _read_json(request: Request) -> dict[str, Any]:
    try:
        payload = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Ungültiger JSON-Body.") from exc
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="JSON-Body muss ein Objekt sein.")
    return payload


def _as_text(payload: dict[str, Any], key: str, default: str = "") -> str:
    value = payload.get(key, default)
    if value is None:
        return default
    return str(value)


def _as_optional_text(payload: dict[str, Any], key: str) -> Optional[str]:
    if key not in payload or payload[key] is None:
        return None
    return str(payload[key])


def _as_optional_bool(payload: dict[str, Any], key: str) -> Optional[bool]:
    if key not in payload or payload[key] is None:
        return None
    value = payload[key]
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "ja", "on"}:
            return True
        if normalized in {"0", "false", "no", "nein", "off"}:
            return False
    raise HTTPException(status_code=400, detail=f"'{key}' muss boolesch sein.")


def _as_optional_int(
    payload: dict[str, Any],
    key: str,
    *,
    minimum: Optional[int] = None,
    maximum: Optional[int] = None,
) -> Optional[int]:
    if key not in payload or payload[key] is None or payload[key] == "":
        return None
    try:
        value = int(payload[key])
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=f"'{key}' muss eine Ganzzahl sein.") from exc
    if minimum is not None and value < minimum:
        raise HTTPException(status_code=400, detail=f"'{key}' muss mindestens {minimum} sein.")
    if maximum is not None and value > maximum:
        raise HTTPException(status_code=400, detail=f"'{key}' darf höchstens {maximum} sein.")
    return value


def _as_optional_rst_code(payload: dict[str, Any], key: str) -> Optional[str]:
    value = _as_optional_text(payload, key)
    if value is None or value.strip() == "":
        return None
    text = value.strip().upper().removeprefix("RST!")
    if not text.isdigit() or not 1 <= int(text) <= 8:
        raise HTTPException(status_code=400, detail=f"'{key}' muss eine RST-Ziffer von 1 bis 8 sein.")
    return str(int(text))


def _as_optional_rst_address(payload: dict[str, Any], key: str) -> Optional[str]:
    value = _as_optional_text(payload, key)
    if value is None or value.strip() == "":
        return None
    text = value.strip().upper()
    if text.startswith("RST") and "!" in text:
        text = text[3:].split("!", 1)[0]
    if not text.isdigit() or not 0 <= int(text) <= 90:
        raise HTTPException(status_code=400, detail=f"'{key}' muss eine RST-Adresse von 0 bis 90 sein.")
    return str(int(text))


def _reset_code_for_button(settings: dict[str, str], button_name: Optional[str]) -> str:
    if button_name == "LEITUNGEN":
        return settings.get("rst_code_leitungen", "4")
    if button_name == "SK_I_II":
        return settings.get("rst_code_sk_i_ii", "3")
    return settings.get("rst_code_sk_i_ii", "3")


def _reset_address_from_settings(settings: dict[str, str]) -> str:
    return settings.get("rst_target_address", "1")


def _current_measurement_mode_button() -> Optional[str]:
    protocol = state.current_raw_protocol
    if protocol is not None:
        hint = reset_button_hint_from_fields(protocol.raw_fields or [])
        if hint:
            return hint
    return state.active_measurement_button or state.last_measurement_button


def _reset_command_label(settings: dict[str, str], reset_code: str, reset_address: str) -> str:
    if settings.get("device_addressing_enabled", "0") == "1":
        return f"RST{reset_address}!{reset_code}"
    return f"RST!{reset_code}"


def _draft_from_payload(payload: dict[str, Any]) -> DraftInputState:
    return DraftInputState(
        id=_as_text(payload, "id"),
        geraeteart=_as_text(payload, "geraeteart"),
        hersteller=_as_text(payload, "hersteller"),
        raum_etage=_as_text(payload, "raum_etage"),
        kunde=_as_text(payload, "kunde"),
        typ_modell="",
        seriennummer="",
        pruefer="",
        zusatztext="",
    )


def _metadata_from_payload(payload: dict[str, Any]) -> MeasurementMetadata:
    return MeasurementMetadata(
        id=_as_text(payload, "id"),
        geraeteart=expand_device_abbreviations(_as_text(payload, "geraeteart")),
        hersteller=_as_text(payload, "hersteller"),
        raum_etage=_as_text(payload, "raum_etage"),
        kunde=_as_text(payload, "kunde"),
        typ_modell="",
        seriennummer="",
        pruefer="",
        zusatztext="",
    )

def _project_payload(payload: dict[str, Any]) -> tuple[str, str, str, str, str, str, str, Optional[int]]:
    customer = _as_text(payload, "customer").strip()
    cycle_month = _as_text(payload, "cycle_month").strip()
    street = _as_text(payload, "street").strip()
    postal_code = _as_text(payload, "postal_code").strip()
    city = _as_text(payload, "city").strip()
    test_interval_months = (_as_text(payload, "test_interval_months").strip() or "24")
    inspector = _as_text(payload, "inspector").strip()
    project_id = _as_optional_int(payload, "id", minimum=1)
    if not customer:
        raise HTTPException(status_code=400, detail="Kundenname ist Pflicht.")
    if not cycle_month:
        raise HTTPException(status_code=400, detail="Prüfzyklus Monat/Jahr ist Pflicht.")
    if not street:
        raise HTTPException(status_code=400, detail="Straße ist Pflicht.")
    if not postal_code:
        raise HTTPException(status_code=400, detail="Postleitzahl ist Pflicht.")
    if not city:
        raise HTTPException(status_code=400, detail="Ort ist Pflicht.")
    if not test_interval_months:
        raise HTTPException(status_code=400, detail="Prüfintervall ist Pflicht.")
    if not inspector:
        raise HTTPException(status_code=400, detail="Prüfer ist Pflicht.")
    return customer, cycle_month, street, postal_code, city, test_interval_months, inspector, project_id


def _active_project_or_409():
    project = database.get_active_project()
    if project is None:
        raise HTTPException(status_code=409, detail="Kein Projekt geladen. Bitte Projekt erstellen oder laden.")
    return project


async def _archive_received_raw_protocol(protocol: Optional[RawProtocolRecord], reason: str = "receive") -> None:
    if protocol is None:
        return
    project = database.get_active_project()
    path = append_raw_protocol(DATA_DIR, project, protocol)
    await state.append_log(f"[ROHDATEN] Originalframe plus korrigierte Empfangs-/Sichtprüfungsfelder angefügt ({reason}): {path.name}")


def _is_psi_listen_safe_command(command: str) -> bool:
    normalized = command.strip().upper()
    # TAS!A is deliberately listen-safe: the direct-SECUTEST title-bar button
    # and the automatic post-PRX finalization both need to send it while
    # listen mode is active (that is the only mode the direct workflow runs in).
    return normalized in {"ESR?", "ESR0?", "WER?", "MEM!", "MEM0!", "TAS!A"}


def _ensure_remote_control_allowed(command: Optional[str] = None) -> None:
    """Block SECUTEST/remote-control actions while passive listening is active.

    PSI housekeeping commands remain allowed internally for the listen workflow and
    for post-save cleanup.  UI-triggered SECUTEST steering is deliberately blocked
    here, not only by disabled buttons. Grau ist keine Sicherheitsschicht.
    """
    if not state.listen_mode_enabled:
        return
    if command is not None and _is_psi_listen_safe_command(command):
        return
    raise HTTPException(status_code=409, detail="Lauschmodus aktiv – Fernsteuerung ist deaktiviert.")


async def _handle_direct_prx_fetch() -> None:
    await state.set_listen_state("fetching", "SECUTEST meldet neue Messdaten – rufe PRX?X/Y/Z ab …")
    protocol = await acquisition.fetch_direct_prx_record(timeout_ms=3500)
    measurement = protocol.parsed_measurement
    if measurement is None:
        await _archive_received_raw_protocol(protocol, reason="direct_prx_unparsed")
        raise RuntimeError("PRX?X/Y/Z vollständig empfangen, aber keine Messwerte erkannt")
    await _archive_received_raw_protocol(protocol, reason="direct_prx")
    hint = reset_button_hint_from_fields(protocol.raw_fields or [])
    if hint:
        state.last_measurement_button = hint
    await state.set_listen_measurement_ready(measurement, protocol)
    await state.append_log("[LAUSCH-DIREKT] PRX?X/Y/Z fehlerfrei übernommen – Eingabe am Handy freigegeben.")


async def _listen_mode_loop() -> None:
    await state.append_log("[LAUSCH] Lauschmodus gestartet.")
    last_reported_error = ""
    try:
        while state.listen_mode_enabled:
            if state.is_sequence_running:
                await asyncio.sleep(0.25)
                continue

            if not client.connected:
                await state.set_listen_state("waiting", "Lauschmodus aktiv – Verbindung wird automatisch hergestellt …")
                try:
                    async with psi_action_lock:
                        await _connect_and_detect_topology()
                    await state.append_log("[LAUSCH] TCP-Verbindung automatisch wiederhergestellt.")
                    last_reported_error = ""
                except Exception as exc:
                    message = str(exc)
                    if message != last_reported_error:
                        await state.append_log(f"[LAUSCH-WARN] Automatischer Verbindungsaufbau fehlgeschlagen: {message}")
                        last_reported_error = message
                    await state.set_listen_state("error", "Lauschmodus aktiv – automatischer Verbindungsaufbau fehlgeschlagen.", error=message)
                    await asyncio.sleep(1.5)
                    continue

            if state.connection_topology == "unknown":
                try:
                    async with psi_action_lock:
                        await _detect_connected_device_topology()
                except Exception as exc:
                    message = str(exc)
                    if message != last_reported_error:
                        await state.append_log(f"[LAUSCH-WARN] IDN?-Topologieerkennung fehlgeschlagen: {message}")
                        last_reported_error = message
                    await state.set_listen_state("error", "Lauschmodus aktiv – angeschlossenes Gerät konnte nicht erkannt werden.", error=message)
                    await asyncio.sleep(1.0)
                    continue

            if state.connection_topology == "direct_secutest":
                try:
                    # During local save/reset no second consumer may steal the RST ACK.
                    if state.is_loading:
                        await asyncio.sleep(0.1)
                        continue

                    if state.current_measurement is not None:
                        await state.set_listen_state("unsaved", "Messdaten empfangen – bitte Gerätedaten ergänzen und speichern.")
                        if await acquisition.wait_for_direct_prx_ready(timeout_ms=450):
                            await state.note_direct_prx_pending()
                            await state.append_log("[LAUSCH-DIREKT-WARN] Neues PRX$28 trotz ungespeicherter Messung – Abruf vorgemerkt.")
                        continue

                    pending = state.direct_prx_pending_count > 0
                    if not pending:
                        await state.set_listen_state("waiting", "Lauschmodus aktiv – warte direkt am SECUTEST auf PRX$28 …")
                        ready = await acquisition.wait_for_direct_prx_ready(timeout_ms=500)
                        if not ready:
                            continue
                        await state.note_direct_prx_pending(warn=False)
                        pending = True
                        await state.append_log("[LAUSCH-DIREKT] PRX$28 empfangen – vollständiger Abruf wird gestartet.")

                    async with psi_action_lock:
                        await _handle_direct_prx_fetch()
                    if pending:
                        await state.consume_direct_prx_pending()

                    # Important: do not send TAS!a from inside the PRX transaction
                    # or while the outer PSI/action lock is still held. A manual
                    # console TAS!a works reliably after the fetch even without a
                    # reset, so reproduce that state boundary deliberately. In
                    # addition, TAS!a must only fire once the metadata input has
                    # actually been unlocked for the user (app_state was set to
                    # MEASUREMENT_RECEIVED_NEEDS_METADATA inside
                    # _handle_direct_prx_fetch → set_listen_measurement_ready) -
                    # never earlier.
                    if state.app_state == "MEASUREMENT_RECEIVED_NEEDS_METADATA":
                        try:
                            tas_info = await acquisition.finalize_direct_prx_session(timeout_ms=3000)
                            await state.append_log(
                                f"[LAUSCH-DIREKT] Abschluss {tas_info.get('command', 'TAS!a')} nach >+XON -> {tas_info.get('ack', '?')}"
                            )
                        except Exception as tas_exc:
                            await state.append_log(
                                f"[LAUSCH-DIREKT-WARN] PRX-Daten übernommen, Abschluss-TAS!a fehlgeschlagen: {tas_exc}"
                            )
                    else:
                        await state.append_log(
                            "[LAUSCH-DIREKT-WARN] Abschluss-TAS!a übersprungen: Eingabe der Metadaten wurde nicht freigegeben."
                        )
                    last_reported_error = ""
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    message = str(exc)
                    if message != last_reported_error:
                        await state.append_log(f"[LAUSCH-DIREKT-WARN] PRX-Abruf fehlgeschlagen: {message}")
                        last_reported_error = message
                    await state.set_listen_state("error", "Direkter SECUTEST-Abruf über PRX?X/Y/Z fehlgeschlagen.", error=message)
                    await asyncio.sleep(0.5)
                continue

            # PSI topology: preserve the established ESR?/WER? workflow unchanged.
            if state.current_measurement is not None:
                await state.set_listen_state("unsaved", "Messdaten empfangen – bitte Gerätedaten ergänzen und speichern.")
                await asyncio.sleep(0.5)
                continue

            if state.is_loading:
                await asyncio.sleep(0.25)
                continue

            try:
                await state.set_listen_state("waiting", "Lauschmodus aktiv – warte auf PSI-Messdaten …")
                async with psi_action_lock:
                    count = await acquisition.query_psi_store_count()
                    state.listen_last_protocol_count = count
                    last_reported_error = ""
                    if count and count > 0:
                        await state.set_listen_state("fetching", f"PSI meldet {count} Protokoll(e) – rufe WER? ab …")
                        protocol = await acquisition.fetch_latest_psi_record(
                            clear_after_read=False,
                            wait_timeout_ms=3500,
                            poll_interval_s=0.2,
                        )
                        measurement = protocol.parsed_measurement
                        if measurement is None:
                            await _archive_received_raw_protocol(protocol, reason="listen_unparsed")
                            await state.set_listen_state(
                                "error",
                                "PSI-Daten empfangen, aber keine Messwerte erkannt.",
                                error="WER?-Datensatz ohne auswertbare Messwerte",
                            )
                            await state.append_log("[LAUSCH-WARN] WER? empfangen, aber keine auswertbaren Messwerte erkannt.")
                        else:
                            merged_draft = _merge_imported_metadata_into_draft(protocol.parsed_metadata)
                            if merged_draft is not None:
                                await state.broadcast_draft(merged_draft, reason="psi_listen")
                            await _archive_received_raw_protocol(protocol, reason="listen")
                            hint = reset_button_hint_from_fields(protocol.raw_fields or [])
                            if hint:
                                state.last_measurement_button = hint
                            await state.set_listen_measurement_ready(measurement, protocol)
                            await state.append_log("[LAUSCH] Neue PSI-Messdaten übernommen – Eingabe am Handy freigegeben.")
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                message = str(exc)
                if message != last_reported_error:
                    await state.append_log(f"[LAUSCH-WARN] ESR/WER fehlgeschlagen: {message}")
                    last_reported_error = message
                await state.set_listen_state("error", "Lauschmodus aktiv – Fehler beim ESR/WER-Polling.", error=message)

            await asyncio.sleep(0.5)
    finally:
        await state.append_log("[LAUSCH] Lauschmodus gestoppt.")


def _ensure_listen_task_running() -> None:
    global listen_task
    if listen_task is None or listen_task.done():
        listen_task = asyncio.create_task(_listen_mode_loop(), name="psi-listen-mode")


def _prefer_imported(imported: str, current: str) -> str:
    value = (imported or "").strip()
    return value if value else current


def _merge_imported_metadata_into_draft(imported: Optional[MeasurementMetadata]) -> Optional[DraftInputState]:
    if imported is None:
        return None
    current = database.get_draft()
    # Neue Messung = neue Gerätemetadaten.  ID, Geräteart und Hersteller dürfen
    # nicht mehr stumpf aus der letzten Prüfung übernommen werden.  Falls das PSI
    # echte Werte liefert, werden diese übernommen; leere PSI-Felder bleiben leer
    # und erscheinen im Frontend nur noch als Vorschlag.
    merged = DraftInputState(
        id=(imported.id or "").strip(),
        geraeteart=expand_device_abbreviations((imported.geraeteart or "").strip()),
        hersteller=(imported.hersteller or "").strip(),
        # Raum ist ein persistent gesetzter Arbeitskontext. PSI/PC.doc-Daten
        # liefern hier gern alte Beispiel-/Vorgabewerte (z. B. "Büro").
        # Deshalb niemals mit importierten Messdaten überschreiben; nur der
        # Nutzer oder das Raum-Popup ändern diesen Wert.
        raum_etage=current.raum_etage,
        kunde=current.kunde,
        typ_modell=current.typ_modell,
        seriennummer=current.seriennummer,
        pruefer=current.pruefer,
        zusatztext=current.zusatztext,
    )
    return database.save_draft(merged)


@app.exception_handler(HTTPException)
async def _http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)


@app.exception_handler(Exception)
async def _generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    return JSONResponse({"detail": str(exc)}, status_code=500)


# =========================================================
# Basic routes
# =========================================================

@app.route("/", methods=["GET"])
async def index(request: Request) -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"})


@app.route("/manifest.webmanifest", methods=["GET"])
async def manifest(request: Request) -> FileResponse:
    return FileResponse(STATIC_DIR / "manifest.webmanifest", media_type="application/manifest+json", headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"})


@app.route("/sw.js", methods=["GET"])
async def service_worker(request: Request) -> FileResponse:
    return FileResponse(STATIC_DIR / "sw.js", media_type="application/javascript", headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"})


@app.route("/api/state", methods=["GET"])
async def get_state(request: Request) -> JSONResponse:
    return JSONResponse(state.snapshot())


@app.route("/api/measurement-rate", methods=["GET"])
async def get_measurement_rate(request: Request) -> JSONResponse:
    return JSONResponse(state.measurement_rate_snapshot())


@app.route("/api/listen-mode", methods=["POST"])
async def set_listen_mode(request: Request) -> JSONResponse:
    payload = await _read_json(request)
    enabled = _as_optional_bool(payload, "enabled")
    if enabled is None:
        raise HTTPException(status_code=400, detail="'enabled' fehlt.")

    if enabled:
        if state.is_sequence_running:
            raise HTTPException(status_code=409, detail="Messung läuft noch – Lauschmodus kann erst danach aktiviert werden.")
        if state.current_measurement is not None:
            raise HTTPException(status_code=409, detail="Ungespeicherte Messdaten vorhanden – bitte zuerst speichern oder verwerfen.")
        _active_project_or_409()
        auto_connected = False
        if not client.connected:
            await state.append_log("[LAUSCH] Aktivierung angefordert – TCP-Verbindung wird automatisch hergestellt.")
            try:
                await _connect_and_detect_topology()
                auto_connected = True
            except SecutestClientError as exc:
                raise HTTPException(status_code=502, detail=f"Lauschmodus nicht aktiviert: {exc}") from exc
        elif state.connection_topology == "unknown":
            try:
                await _detect_connected_device_topology()
            except Exception as exc:
                raise HTTPException(status_code=502, detail=f"Lauschmodus nicht aktiviert: IDN?-Erkennung fehlgeschlagen: {exc}") from exc
        listen_message = (
            "Lauschmodus aktiv – warte direkt am SECUTEST auf PRX$28 …"
            if state.connection_topology == "direct_secutest"
            else "Lauschmodus aktiv – warte auf PSI-Messdaten …"
        )
        await state.set_listen_mode(True, listen_message)
        _ensure_listen_task_running()
        return JSONResponse({
            "ok": True,
            "listen_mode_enabled": True,
            "connection_auto_opened": auto_connected,
            "state": state.snapshot(),
        })

    if state.current_measurement is not None:
        raise HTTPException(status_code=409, detail="Ungespeicherte Messdaten vorhanden – bitte zuerst speichern oder verwerfen.")
    await state.set_listen_mode(False, "Lauschmodus aus.")
    return JSONResponse({"ok": True, "listen_mode_enabled": False, "state": state.snapshot()})


@app.websocket_route("/ws")
async def websocket_endpoint(websocket: WebSocket) -> None:
    await events.connect(websocket)
    try:
        await websocket.send_json({"type": "state", "state": state.snapshot()})
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        await events.disconnect(websocket)
    except Exception:
        await events.disconnect(websocket)


# =========================================================
# Settings + connection
# =========================================================

@app.route("/api/settings", methods=["POST"])
async def update_settings(request: Request) -> JSONResponse:
    payload = await _read_json(request)
    updates: dict[str, Any] = {}

    host = _as_optional_text(payload, "host")
    port = _as_optional_int(payload, "port", minimum=1, maximum=65535)
    simulation_enabled = _as_optional_bool(payload, "simulation_enabled")
    autosave_enabled = _as_optional_bool(payload, "autosave_enabled")
    autosave_path = _as_optional_text(payload, "autosave_path")
    poll_interval_ms = _as_optional_int(payload, "poll_interval_ms", minimum=50, maximum=10000)
    command_timeout_ms = _as_optional_int(payload, "command_timeout_ms", minimum=200, maximum=30000)
    rst_code_sk_i_ii = _as_optional_rst_code(payload, "rst_code_sk_i_ii")
    rst_code_leitungen = _as_optional_rst_code(payload, "rst_code_leitungen")
    device_addressing_enabled = _as_optional_bool(payload, "device_addressing_enabled")
    rst_target_address = _as_optional_rst_address(payload, "rst_target_address")
    post_reset_settle_ms = _as_optional_int(payload, "post_reset_settle_ms", minimum=0, maximum=10000)
    room_prompt_idle_seconds = _as_optional_int(payload, "room_prompt_idle_seconds", minimum=0, maximum=86400)
    measurement_rate_window_minutes = _as_optional_int(payload, "measurement_rate_window_minutes", minimum=5, maximum=240)
    capture_scroll_position_px = _as_optional_int(payload, "capture_scroll_position_px", minimum=0, maximum=5000)
    auto_scan_after_measurement = _as_optional_bool(payload, "auto_scan_after_measurement")

    if host is not None:
        updates["host"] = host.strip()
    if port is not None:
        updates["port"] = str(port)
    if simulation_enabled is not None:
        updates["simulation_enabled"] = "1" if simulation_enabled else "0"
    if autosave_enabled is not None:
        updates["autosave_enabled"] = "1" if autosave_enabled else "0"
    if autosave_path is not None:
        updates["autosave_path"] = autosave_path.strip()
    if poll_interval_ms is not None:
        updates["poll_interval_ms"] = str(poll_interval_ms)
    if command_timeout_ms is not None:
        updates["command_timeout_ms"] = str(command_timeout_ms)
    if rst_code_sk_i_ii is not None:
        updates["rst_code_sk_i_ii"] = rst_code_sk_i_ii
    if rst_code_leitungen is not None:
        updates["rst_code_leitungen"] = rst_code_leitungen
    if device_addressing_enabled is not None:
        updates["device_addressing_enabled"] = "1" if device_addressing_enabled else "0"
    if rst_target_address is not None:
        updates["rst_target_address"] = rst_target_address
    if post_reset_settle_ms is not None:
        updates["post_reset_settle_ms"] = str(post_reset_settle_ms)
    if room_prompt_idle_seconds is not None:
        updates["room_prompt_idle_seconds"] = str(room_prompt_idle_seconds)
    if measurement_rate_window_minutes is not None:
        updates["measurement_rate_window_minutes"] = str(measurement_rate_window_minutes)
    if capture_scroll_position_px is not None:
        updates["capture_scroll_position_px"] = str(capture_scroll_position_px)
    if auto_scan_after_measurement is not None:
        updates["auto_scan_after_measurement"] = "1" if auto_scan_after_measurement else "0"

    previous = database.get_settings()
    current = database.set_settings(updates)
    if client.connected and any(key in updates for key in ("host", "port")):
        await client.disconnect()
        await state.append_log("[SETTINGS] Host/Port geändert – Verbindung getrennt.")
    await state.emit_state()
    return JSONResponse({"settings": current, "changed": updates, "previous": previous})


@app.route("/api/connect", methods=["POST"])
async def connect(request: Request) -> JSONResponse:
    try:
        info = await _connect_and_detect_topology()
    except SecutestClientError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:
        await client.disconnect()
        raise HTTPException(status_code=502, detail=f"Verbunden, aber IDN?-Erkennung fehlgeschlagen: {exc}") from exc
    return JSONResponse({
        "ok": True,
        "status": state.connection_status,
        "detail": state.connection_detail,
        "topology": info.get("topology", "unknown"),
        "identity": info.get("identity", ""),
    })


@app.route("/api/disconnect", methods=["POST"])
async def disconnect(request: Request) -> JSONResponse:
    await client.disconnect()
    state.direct_prx_pending_count = 0
    await state.set_connection_topology("unknown", "")
    return JSONResponse({"ok": True, "status": state.connection_status})


# =========================================================
# Projects
# =========================================================

@app.route("/api/projects", methods=["GET"])
async def list_projects(request: Request) -> JSONResponse:
    active = database.get_active_project()
    return JSONResponse({
        "active_project": active.to_dict() if active else None,
        "projects": [project.to_dict() for project in database.get_projects()],
    })


@app.route("/api/projects", methods=["POST"])
async def save_project(request: Request) -> JSONResponse:
    payload = await _read_json(request)
    customer, cycle_month, street, postal_code, city, test_interval_months, inspector, project_id = _project_payload(payload)
    try:
        project = database.upsert_project(
            customer,
            cycle_month,
            street=street,
            postal_code=postal_code,
            city=city,
            test_interval_months=test_interval_months,
            inspector=inspector,
            project_id=project_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    draft = database.get_draft()
    draft.kunde = project.customer
    database.save_draft(draft)
    await state.broadcast_draft(draft, reason="project")
    await state.append_log(f"[PROJEKT] Aktiv: {project.name}")
    await state.emit_state()
    return JSONResponse({"ok": True, "project": project.to_dict()})


@app.route("/api/projects/active", methods=["POST"])
async def activate_project(request: Request) -> JSONResponse:
    payload = await _read_json(request)
    project_id = _as_optional_int(payload, "id", minimum=1)
    if project_id is None:
        raise HTTPException(status_code=400, detail="Projekt-ID fehlt.")
    try:
        project = database.set_active_project(project_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    draft = database.get_draft()
    draft.kunde = project.customer
    database.save_draft(draft)
    await state.broadcast_draft(draft, reason="project")
    await state.append_log(f"[PROJEKT] Geladen: {project.name}")
    await state.emit_state()
    return JSONResponse({"ok": True, "project": project.to_dict()})


# =========================================================
# Draft + suggestions
# =========================================================

@app.route("/api/draft", methods=["POST"])
async def save_draft(request: Request) -> JSONResponse:
    payload = await _read_json(request)
    draft = database.save_draft(_draft_from_payload(payload))
    # Do not echo every keystroke back through a full state broadcast.
    # Mobile browsers otherwise race their own input and occasionally lose the last character.
    return JSONResponse({"draft": draft.to_dict()})


@app.route("/api/draft/expand-device", methods=["POST"])
async def expand_draft_device(request: Request) -> JSONResponse:
    payload = await _read_json(request)
    value = expand_device_abbreviations(_as_text(payload, "value"))
    return JSONResponse({"value": value})


@app.route("/api/suggestions", methods=["GET"])
async def suggestions(request: Request) -> JSONResponse:
    field = request.query_params.get("field", "")
    q = request.query_params.get("q", "")
    geraeteart = request.query_params.get("geraeteart", "")
    metadata_rows = database.metadata_rows()
    if field == "id":
        values = build_id_suggestions([row["id"] for row in metadata_rows], q)
    elif field == "geraeteart":
        values = build_device_suggestions([row["geraeteart"] for row in metadata_rows], q)
    elif field == "hersteller":
        values = build_manufacturer_suggestions(metadata_rows, geraeteart, q)
    else:
        raise HTTPException(status_code=400, detail="Unbekanntes Vorschlagsfeld")
    return JSONResponse({"field": field, "values": values})


# =========================================================
# Commands / debug console
# =========================================================

@app.route("/api/command", methods=["POST"])
async def send_command(request: Request) -> JSONResponse:
    payload = await _read_json(request)
    command = _as_text(payload, "command").strip()
    if not command:
        raise HTTPException(status_code=400, detail="Leerer Befehl wurde verworfen.")
    _ensure_remote_control_allowed(command)
    expected = _as_text(payload, "expected", "auto").strip() or "auto"
    timeout_ms = _as_optional_int(payload, "timeout_ms", minimum=200, maximum=30000)
    try:
        frame = await client.send_command(command, expected=expected, timeout_ms=timeout_ms)
    except Exception as exc:
        await state.append_log(f"[CMD-ERR] {command}: {exc}")
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    return JSONResponse({"ok": True, "frame": frame.to_dict()})


@app.route("/api/manual/enter", methods=["POST"])
async def manual_enter(request: Request) -> JSONResponse:
    _ensure_remote_control_allowed("TAS!4")
    try:
        await acquisition.press_enter()
        await state.append_log("ENTER (TAS!4) gesendet.")
        return JSONResponse({"ok": True})
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.route("/api/manual/mes", methods=["POST"])
async def manual_mes(request: Request) -> JSONResponse:
    _ensure_remote_control_allowed("MES?")
    try:
        mes = await acquisition.query_mes_status()
        await state.update_device_status(mes.raw_response)
        await state.append_log(f"MES?: {mes.raw_response}")
        return JSONResponse({"ok": True, "status": mes.to_dict()})
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.route("/api/manual/clear-psi", methods=["POST"])
async def manual_clear_psi(request: Request) -> JSONResponse:
    _ensure_remote_control_allowed("MEM!")
    try:
        async with psi_action_lock:
            detail = await acquisition.clear_psi_memory_verified(force=True)
        settings = database.get_settings()
        psi_addr = "0" if settings.get("device_addressing_enabled", "0") == "1" else ""
        await state.append_log(f"PSI-Speicher wurde geleert (MEM{psi_addr}!); ESR{psi_addr}?=0 bestätigt.")
        return JSONResponse({"ok": True, "detail": detail})
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.route("/api/manual/tas-a", methods=["POST"])
async def manual_tas_a(request: Request) -> JSONResponse:
    """Manual title-bar fallback: send TAS!a via the same console path as the
    automatic direct-mode finalization (see SecutestAcquisitionService.send_tas_a)."""
    _ensure_remote_control_allowed("TAS!A")
    try:
        async with psi_action_lock:
            info = await acquisition.send_tas_a()
        await state.append_log(f"[MANUELL] {info.get('command', 'TAS!a')} gesendet -> {info.get('ack', '?')}")
        return JSONResponse({"ok": True, "tas": info})
    except Exception as exc:
        await state.append_log(f"[MANUELL-ERR] TAS!a fehlgeschlagen: {exc}")
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.route("/api/manual/reset-init", methods=["POST"])
async def manual_reset_init(request: Request) -> JSONResponse:
    _ensure_remote_control_allowed("RST!")
    try:
        payload = await _read_json(request) if request.headers.get("content-length") not in (None, "0") else {}
        settings = database.get_settings()
        reset_code = _as_optional_rst_code(payload, "rst_code") or _reset_code_for_button(
            settings, state.active_measurement_button or state.last_measurement_button
        )
        reset_address = _as_optional_rst_address(payload, "rst_address") or _reset_address_from_settings(settings)
        await state.append_log(f"[INIT] Adressierung kurz prüfen/ggf. setzen → RST{reset_address}!{reset_code} → danach wieder kurz prüfen/ggf. setzen.")
        info = await acquisition.reset_mode_and_initialize(reset_code, reset_address)
        await state.append_log(f"[INIT] {info.get('reset_command', f'RST{reset_address}!{reset_code}')} + Adressierung abgeschlossen.")
        return JSONResponse({"ok": True, "init": info})
    except Exception as exc:
        await state.append_log(f"[INIT-ERR] Reset/Adressierung fehlgeschlagen: {exc}")
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.route("/api/manual/fetch-latest", methods=["POST"])
async def manual_fetch_latest(request: Request) -> JSONResponse:
    _ensure_remote_control_allowed("WER?")
    try:
        async with psi_action_lock:
            protocol = await acquisition.fetch_latest_psi_record(clear_after_read=False)
        measurement = protocol.parsed_measurement
        if measurement is None:
            raise RuntimeError("Datensatz vorhanden, aber keine Messwerte erkannt.")
        merged_draft = _merge_imported_metadata_into_draft(protocol.parsed_metadata)
        if merged_draft is not None:
            await state.broadcast_draft(merged_draft, reason="psi_import")
        await _archive_received_raw_protocol(protocol, reason="manual_fetch")
        hint = reset_button_hint_from_fields(protocol.raw_fields or [])
        if hint:
            state.last_measurement_button = hint
        await state.set_measurement_ready(measurement, protocol)
        await state.append_log("[WER] Letzter PSI-Datensatz übernommen.")
        return JSONResponse({"ok": True, "protocol": protocol.to_dict(), "draft": merged_draft.to_dict() if merged_draft else None})
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


# =========================================================
# Sequences
# =========================================================

async def _run_sequence(button_name: str, runner: Callable[[], Awaitable[Any]]) -> dict[str, Any]:
    _ensure_remote_control_allowed(button_name)
    if state.is_sequence_running:
        raise HTTPException(status_code=409, detail="Es läuft bereits eine Sequenz.")
    if state.current_measurement is not None:
        raise HTTPException(status_code=409, detail="Achtung, ungespeicherte Messergebnisse: Bitte speichern oder verwerfen.")

    await state.append_log(f"[SEQ] {button_name} gestartet")
    await state.set_sequence_running(True, button_name)
    try:
        result = await runner()

        # TX/RX already logs every MES?/TAS!/WER? frame live.  Do not replay the
        # full step list afterwards, otherwise the mobile log looks as if old
        # MES? events were processed again.  Only keep the compact milestones and
        # failures for readability.
        await state.append_log(f"[SEQ] {result.message}")
        for step in result.steps:
            important = step.step_name in {"finish_detected", "wer_fetch", "psi_fetch", "auto_halt"}
            if important or not step.success:
                await state.append_log(step.detail)
                if step.raw_data and step.step_name in {"wer_fetch", "psi_fetch"}:
                    await state.append_log(f"[RAW] {step.raw_data[:220]}")
        measurement = sequences.consume_last_imported_measurement()
        raw_protocol = sequences.consume_last_imported_raw_protocol()
        merged_draft = _merge_imported_metadata_into_draft(raw_protocol.parsed_metadata) if raw_protocol else None
        if merged_draft is not None:
            await state.broadcast_draft(merged_draft, reason="psi_import")
        await _archive_received_raw_protocol(raw_protocol, reason=button_name)
        if raw_protocol:
            hint = reset_button_hint_from_fields(raw_protocol.raw_fields or [])
            if hint:
                state.last_measurement_button = hint
        await state.set_sequence_result(result, measurement, raw_protocol)
        return {"ok": result.success, "result": result.to_dict()}
    except Exception as exc:
        message = f"Sequenz abgebrochen: {exc}"
        await state.append_log(f"[SEQ] {message}")
        await state.set_error(message)
        raise HTTPException(status_code=502, detail=message) from exc



@app.route("/api/sequence/cancel", methods=["POST"])
async def cancel_sequence(request: Request) -> JSONResponse:
    if not state.is_sequence_running:
        return JSONResponse({"ok": True, "message": "Keine laufende Sequenz."})
    await state.request_sequence_cancel()
    await state.append_log("[SEQ] Abbruch angefordert – Sequenz stoppt nach dem aktuellen TX/RX-Schritt.")
    return JSONResponse({"ok": True, "message": "Abbruch angefordert."})


@app.route("/api/sequence/cancel-reset", methods=["POST"])
async def cancel_sequence_and_reset(request: Request) -> JSONResponse:
    _ensure_remote_control_allowed("RST!")
    await state.request_sequence_cancel()
    settings = database.get_settings()
    button_name = _current_measurement_mode_button()
    reset_code = _reset_code_for_button(settings, button_name)
    reset_address = _reset_address_from_settings(settings)
    await state.append_log(
        f"[SEQ] Abbruch + Modus-Reset angefordert: {_reset_command_label(settings, reset_code, reset_address)}."
    )
    if not client.connected or settings.get("simulation_enabled", "0") == "1":
        return JSONResponse({"ok": True, "message": "Abbruch angefordert; Reset übersprungen (Simulation oder offline)."})
    try:
        info = await acquisition.reset_mode_and_initialize(reset_code, reset_address)
        await state.append_log(f"[SEQ] Abbruch-Reset abgeschlossen: {info.get('reset_command', 'RST')}.")
        return JSONResponse({"ok": True, "message": "Abbruch + Reset abgeschlossen.", "detail": info})
    except Exception as exc:
        await state.append_log(f"[SEQ-WARN] Abbruch-Reset fehlgeschlagen: {exc}")
        return JSONResponse({"ok": False, "message": str(exc)}, status_code=502)


@app.route("/api/measurement/discard", methods=["POST"])
async def discard_current_measurement(request: Request) -> JSONResponse:
    payload = await _read_json(request)
    had_local_measurement = state.current_measurement is not None

    # Standard dialog: PSI prüfen/leeren und danach Modus-Reset. Der mobile
    # Swipe nach oben prüft/leert den PSI ebenfalls, lässt den Messmodus aber
    # unverändert. Wichtig: Die PSI-Prüfung läuft auch dann, wenn der lokale
    # Messzustand aus irgendeinem Grund bereits leer ist.
    do_reset = _as_optional_bool(payload, "reset")
    if do_reset is None:
        do_reset = True

    state.is_loading = True
    await state.emit_state()
    settings = database.get_settings()
    if state.connection_topology == "direct_secutest":
        await state.append_log(
            "[MEAS] Verwerfen angefordert – Direktmodus: kein PSI-Speichercheck"
            + ("; anschließend unadressierter Reset." if do_reset else "; kein Reset.")
        )
    else:
        psi_addr = "0" if settings.get("device_addressing_enabled", "0") == "1" else ""
        await state.append_log(
            f"[MEAS] Verwerfen angefordert – PSI-Bestand wird mit ESR{psi_addr}? geprüft"
            + ("; anschließend Reset." if do_reset else "; kein Reset.")
        )

    cleanup = await _run_discard_device_cleanup(do_reset=do_reset)
    if not cleanup.get("ok", False):
        state.is_loading = False
        await state.emit_state()
        message = (
            "Verwerfen abgebrochen: Direkt-Reset fehlgeschlagen."
            if state.connection_topology == "direct_secutest"
            else "Verwerfen abgebrochen: PSI-Speicher konnte nicht sicher geprüft/geleert werden."
        )
        await state.append_log(f"[VERWERFEN-STOP] {message}")
        return JSONResponse(
            {"ok": False, "message": message, "post_save_cleanup": cleanup},
            status_code=502,
        )

    if had_local_measurement:
        await state.discard_current_measurement()
    else:
        state.is_loading = False
        await state.emit_state()

    psi_info = cleanup.get("psi", {}) if isinstance(cleanup.get("psi"), dict) else {}
    cleared = bool(psi_info.get("clear_sent"))
    psi_text = (
        "Direktmodus: kein PSI-Cleanup"
        if state.connection_topology == "direct_secutest"
        else ("PSI geprüft und geleert" if cleared else "PSI geprüft: bereits leer")
    )
    reset_failed = bool(cleanup.get("reset_warning"))
    if do_reset and reset_failed:
        reset_text = "; Reset/Init mit Warnung"
    elif do_reset:
        reset_text = " + Reset/Init erledigt"
    else:
        reset_text = ", kein Reset"
    local_text = "Messung verworfen. " if had_local_measurement else "Keine lokale Messung vorhanden. "
    message = f"{local_text}{psi_text}{reset_text}."
    return JSONResponse({"ok": True, "message": message, "post_save_cleanup": cleanup})


async def _run_discard_device_cleanup(*, do_reset: bool) -> dict[str, Any]:
    result: dict[str, Any] = {
        "ok": True,
        "steps": [],
        "mode": "discard_with_reset" if do_reset else "discard_without_reset",
    }
    settings = database.get_settings()
    if settings.get("simulation_enabled", "0") == "1":
        result["steps"].append({"name": "simulation_skip", "ok": True})
        result["psi"] = {"verified_empty": True, "skipped": "simulation"}
        return result

    if state.connection_topology == "direct_secutest":
        result["mode"] = "direct_discard_with_reset" if do_reset else "direct_discard_without_reset"
        result["psi"] = {"verified_empty": True, "skipped": "direct_secutest"}
        result["steps"].append({"name": "psi_cleanup_skipped", "ok": True, "detail": "direct_secutest"})
        if not do_reset:
            return result
        if state.direct_prx_pending_count > 0:
            result["steps"].append({"name": "direct_reset", "ok": True, "skipped": "PRX$28 wartet auf Abruf"})
            await state.append_log(
                "[VERWERFEN-DIREKT] Neues PRX$28 ist vorgemerkt – Reset übersprungen, damit der wartende Datensatz erhalten bleibt."
            )
            return result
        try:
            await state.append_log("[VERWERFEN-DIREKT] Vor Reset reale Drehschalterstellung mit TAS? abfragen.")
            init_info = await acquisition.reset_mode_direct()
            await state.append_log(
                f"[VERWERFEN-DIREKT] TAS? -> {init_info.get('tas_response', '?')} · "
                f"Schalter {init_info.get('switch_position', '?')} -> {init_info.get('reset_command', 'RST!?')} · "
                ""
            )
            result["steps"].append({"name": "direct_reset", "ok": True, "detail": init_info})
            return result
        except Exception as exc:
            result["ok"] = False
            result["steps"].append({"name": "direct_reset", "ok": False, "error": str(exc)})
            await state.append_log(f"[VERWERFEN-DIREKT-WARN] Reset fehlgeschlagen: {exc}")
            return result

    try:
        psi_addr = "0" if settings.get("device_addressing_enabled", "0") == "1" else ""
        await state.append_log(f"[VERWERFEN] PSI-Protokollanzahl prüfen (ESR{psi_addr}?).")
        psi_info = await acquisition.clear_psi_memory_verified(force=False)
        result["psi"] = psi_info
        result["steps"].append({"name": "check_and_clear_psi", "ok": True, "detail": psi_info})
        before_count = psi_info.get("before_count")
        if psi_info.get("clear_sent"):
            await state.append_log(
                f"[VERWERFEN] PSI hatte {before_count if before_count is not None else 'unbekannt viele'} "
                f"Protokoll(e); MEM{psi_addr}! gesendet und ESR{psi_addr}?=0 bestätigt."
            )
        else:
            await state.append_log(f"[VERWERFEN] ESR{psi_addr}? meldet 0 Protokolle – MEM{psi_addr}! nicht nötig.")
    except Exception as exc:
        result["ok"] = False
        result["steps"].append({"name": "check_and_clear_psi", "ok": False, "error": str(exc)})
        await state.append_log(f"[VERWERFEN-WARN] PSI konnte nicht sicher geleert werden: {exc}")
        return result

    if do_reset:
        try:
            button_name = _current_measurement_mode_button()
            reset_code = _reset_code_for_button(settings, button_name)
            reset_address = _reset_address_from_settings(settings)
            reset_label = _reset_command_label(settings, reset_code, reset_address)
            await state.append_log(
                f"[VERWERFEN] PSI leer bestätigt – Modus-Reset {reset_label}."
            )
            init_info = await acquisition.reset_mode_and_initialize(reset_code, reset_address)
            result["steps"].append({"name": "reset_init", "ok": True, "detail": init_info})
        except Exception as exc:
            # PSI is already confirmed empty. A reset warning must not undo the
            # user's discard action; it is reported separately.
            result["reset_warning"] = str(exc)
            result["steps"].append({"name": "reset_init", "ok": False, "error": str(exc)})
            await state.append_log(f"[VERWERFEN-WARN] PSI ist leer, aber Reset/Adressierung fehlgeschlagen: {exc}")

    return result


@app.route("/api/sequence/leitungen", methods=["POST"])
async def run_leitungen_sequence(request: Request) -> JSONResponse:
    return JSONResponse(await _run_sequence("LEITUNGEN", sequences.run_leitungen_sequence))


@app.route("/api/sequence/sk", methods=["POST"])
async def run_sk_sequence(request: Request) -> JSONResponse:
    return JSONResponse(await _run_sequence("SK_I_II", sequences.run_sk_sequence))


# =========================================================
# Save / history / Excel
# =========================================================

async def _run_post_save_device_cleanup(record_id: int) -> dict[str, Any]:
    """After the local save, prepare PSI/SECUTEST for the next measurement.

    The database save must stay successful even when the field device refuses a
    cleanup command. Otherwise one retry on the UI would create duplicate local
    records.  Cleanup errors are therefore returned and logged, but not converted
    into a failed save response.
    """
    settings = database.get_settings()
    if settings.get("simulation_enabled", "0") == "1":
        await state.set_save_progress(92, "Simulation · Abschluss")
        await state.append_log(f"[POST-SAVE] Simulation aktiv – PSI-Löschen/Reset für Datensatz #{record_id} übersprungen.")
        return {"ok": True, "skipped": "simulation"}

    if state.connection_topology == "direct_secutest":
        result: dict[str, Any] = {"ok": True, "mode": "direct_secutest", "steps": []}
        await state.set_save_progress(70, "Direktmodus · kein PSI-Cleanup")
        await state.append_log(
            f"[POST-SAVE-DIREKT] Datensatz #{record_id}: kein MEM!/ESR? und keine Adressierungsprüfung nötig."
        )
        if state.direct_prx_pending_count > 0:
            result["steps"].append({"name": "direct_reset", "ok": True, "skipped": "PRX$28 wartet auf Abruf"})
            await state.set_save_progress(96, "Neue Messdaten warten · Reset übersprungen")
            await state.append_log(
                "[POST-SAVE-DIREKT] Neues PRX$28 ist vorgemerkt – Reset übersprungen, damit der wartende Datensatz erhalten bleibt."
            )
            return result
        try:
            await state.set_save_progress(82, "Drehschalterstellung wird geprüft")
            await state.append_log("[POST-SAVE-DIREKT] Vor Reset reale Drehschalterstellung mit TAS? abfragen.")
            reset_info = await acquisition.reset_mode_direct()
            result["steps"].append({"name": "direct_reset", "ok": True, "detail": reset_info})
            await state.set_save_progress(96, "Direkt-Reset abgeschlossen")
            await state.append_log(
                f"[POST-SAVE-DIREKT] TAS? -> {reset_info.get('tas_response', '?')} · "
                f"Schalter {reset_info.get('switch_position', '?')} -> "
                f"{reset_info.get('reset_command', 'RST!?')} ausgeführt · danach "
                ""
                "ohne IDN-/Adressierungsrunde."
            )
        except Exception as exc:
            result["ok"] = False
            result["steps"].append({"name": "direct_reset", "ok": False, "error": str(exc)})
            await state.set_save_progress(96, "Gespeichert · Reset-Warnung")
            await state.append_log(f"[POST-SAVE-DIREKT-WARN] Unadressierter Reset fehlgeschlagen: {exc}")
        return result

    result: dict[str, Any] = {"ok": True, "steps": []}

    try:
        psi_addr = "0" if settings.get("device_addressing_enabled", "0") == "1" else ""
        await state.set_save_progress(55, "PSI wird geleert")
        await state.append_log(f"[POST-SAVE] PSI-Speicher zwingend löschen (MEM{psi_addr}!) und mit ESR{psi_addr}? verifizieren.")
        psi_info = await acquisition.clear_psi_memory_verified(force=True)
        result["psi"] = psi_info
        result["steps"].append({"name": "clear_psi_verified", "ok": True, "detail": psi_info})
        await state.set_save_progress(76, "PSI leer bestätigt")
        await state.append_log(f"[POST-SAVE] MEM{psi_addr}! ausgeführt; ESR{psi_addr}? bestätigt 0 Protokolle.")
    except Exception as exc:
        result["ok"] = False
        result["steps"].append({"name": "clear_psi_verified", "ok": False, "error": str(exc)})
        await state.append_log(f"[POST-SAVE-STOP] PSI-Speicher ist nicht sicher leer: {exc}")
        result["steps"].append({
            "name": "reset_init",
            "ok": False,
            "skipped": "PSI-Löschen nicht bestätigt",
        })
        await state.set_save_progress(92, "Gespeichert · PSI-Warnung")
        return result

    try:
        button_name = _current_measurement_mode_button()
        reset_code = _reset_code_for_button(settings, button_name)
        reset_address = _reset_address_from_settings(settings)
        reset_label = _reset_command_label(settings, reset_code, reset_address)
        addressing_note = "mit Adressierungsprüfung" if settings.get("device_addressing_enabled", "0") == "1" else "ohne Geräteadressierung"
        await state.set_save_progress(84, "Messgerät wird zurückgesetzt")
        await state.append_log(
            f"[POST-SAVE] Modus-Reset nach tatsächlich erkannter Messart {button_name or 'unbekannt'}: "
            f"{reset_label} ({addressing_note})."
        )
        init_info = await acquisition.reset_mode_and_initialize(reset_code, reset_address)
        result["steps"].append({"name": "reset_init", "ok": True, "detail": init_info})
        await state.set_save_progress(96, "Reset abgeschlossen")
        identity = init_info.get("secutest_identity") or init_info.get("psi_after") or "OK"
        await state.append_log(f"[POST-SAVE] {init_info.get('reset_command', 'RST!'+reset_code)} ausgeführt: {identity}")
    except Exception as exc:
        result["ok"] = False
        result["steps"].append({"name": "reset_init", "ok": False, "error": str(exc)})
        await state.set_save_progress(96, "Gespeichert · Reset-Warnung")
        await state.append_log(f"[POST-SAVE-WARN] Reset/Adressierung fehlgeschlagen: {exc}")

    return result

@app.route("/api/records/save", methods=["POST"])
async def save_record(request: Request) -> JSONResponse:
    payload = await _read_json(request)
    measurement = state.current_measurement
    if measurement is None:
        raise HTTPException(status_code=409, detail="Keine Messung zum Speichern vorhanden.")

    project = _active_project_or_409()
    metadata = _metadata_from_payload(payload)
    if not metadata.kunde.strip():
        metadata.kunde = project.customer
    record = database.insert_record(measurement, metadata, project_id=project.id, raw_protocol=state.current_raw_protocol)
    database.record_measurement_saved()
    measurement_rate = state.measurement_rate_snapshot()
    state.app_state = "POST_SAVE_CLEANUP"
    state.is_loading = True
    await state.set_save_progress(28, "Lokal gespeichert")

    # Keep persistent location/operator fields, but do not carry the previous
    # device metadata into the next measurement.  The frontend keeps those last
    # values as suggestion buttons instead.
    draft_payload = dict(payload)
    draft_payload["id"] = ""
    draft_payload["geraeteart"] = ""
    draft_payload["hersteller"] = ""
    database.save_draft(_draft_from_payload(draft_payload))

    settings = database.get_settings()
    if settings.get("autosave_enabled", "1") == "1":
        autosave_path = PACKAGE_ROOT / settings.get("autosave_path", "data/records_autosave.xlsx")
        export_records_to_path(database.get_records("chronological", project_id=project.id), autosave_path, project=project)
        await state.append_log(f"[XLSX] Autosave aktualisiert: {autosave_path}")
        await state.set_save_progress(45, "Export aktualisiert")
    else:
        await state.set_save_progress(45, "Lokale Daten fertig")

    await state.append_log(f"[SAVE] Datensatz #{record.id} gespeichert.")
    cleanup_result = await _run_post_save_device_cleanup(record.id)
    asyncio.create_task(state.mark_saved(cleanup_ok=cleanup_result.get("ok", True)))
    return JSONResponse({
        "ok": True,
        "record": record.to_dict(),
        "post_save_cleanup": cleanup_result,
        "measurement_rate": measurement_rate,
    })


@app.route("/api/records", methods=["GET"])
async def list_records(request: Request) -> JSONResponse:
    sort = request.query_params.get("sort", "chronological_desc")
    records = database.get_records(sort)
    return JSONResponse({"records": [record.to_dict() for record in records]})


@app.route("/api/records/{record_id:int}", methods=["PUT"])
async def update_record(request: Request) -> JSONResponse:
    record_id = int(request.path_params["record_id"])
    payload = await _read_json(request)
    metadata = _metadata_from_payload(payload)
    updated = database.update_record(record_id, metadata)
    if updated is None:
        raise HTTPException(status_code=404, detail="Datensatz nicht gefunden.")
    await state.append_log(f"[SAVE] Datensatz #{record_id} aktualisiert.")
    await state.emit_state()
    return JSONResponse({"ok": True, "record": updated.to_dict()})


@app.route("/api/records/export.xlsx", methods=["GET"])
async def export_records(request: Request) -> StreamingResponse:
    project = _active_project_or_409()
    payload = export_records_to_bytes(database.get_records("chronological", project_id=project.id), project=project)
    filename = safe_project_filename(project) + ".xlsx"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return StreamingResponse(
        io.BytesIO(payload),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers=headers,
    )


@app.route("/api/records/raw.csv", methods=["GET"])
async def export_raw_records(request: Request) -> StreamingResponse:
    project = _active_project_or_409()
    payload = raw_archive_bytes(DATA_DIR, project)
    filename = safe_project_filename(project) + "_rohdaten.csv"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return StreamingResponse(io.BytesIO(payload), media_type="text/csv; charset=utf-8", headers=headers)


@app.route("/api/records/import.xlsx", methods=["POST"])
async def import_records(request: Request) -> JSONResponse:
    try:
        form = await request.form()
        upload = form.get("file")
        if upload is None or not hasattr(upload, "read"):
            raise HTTPException(status_code=400, detail="Keine XLSX-Datei im Feld 'file' übergeben.")
        payload = await upload.read()
        project = _active_project_or_409()
        records = import_records_from_bytes(payload)
        count = database.import_records(records, project_id=project.id)
        await state.append_log(f"[XLSX] {count} Datensätze importiert.")
        await state.emit_state()
        return JSONResponse({"ok": True, "imported": count})
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


# =========================================================
# Custom buttons / sequence playground
# =========================================================

@app.route("/api/custom-buttons", methods=["GET"])
async def list_custom_buttons(request: Request) -> JSONResponse:
    return JSONResponse({"buttons": database.get_custom_buttons()})


@app.route("/api/custom-buttons/{button_id:int}", methods=["PUT"])
async def update_custom_button(request: Request) -> JSONResponse:
    button_id = int(request.path_params["button_id"])
    payload = await _read_json(request)
    name = _as_text(payload, "name").strip()
    commands = _as_text(payload, "commands")
    if not name:
        raise HTTPException(status_code=400, detail="Button-Name darf nicht leer sein.")
    updated = database.update_custom_button(button_id, name, commands)
    if updated is None:
        raise HTTPException(status_code=404, detail="Button nicht gefunden.")
    await state.emit_state()
    return JSONResponse({"ok": True, "button": updated})


@app.route("/api/custom-buttons/{button_id:int}/run", methods=["POST"])
async def run_custom_button(request: Request) -> JSONResponse:
    button_id = int(request.path_params["button_id"])
    button = next((item for item in database.get_custom_buttons() if item["id"] == button_id), None)
    if button is None:
        raise HTTPException(status_code=404, detail="Button nicht gefunden.")

    commands = _parse_custom_commands(button["commands"])
    results: list[dict[str, Any]] = []
    if not commands:
        return JSONResponse({"ok": True, "button": button, "results": results})
    if state.listen_mode_enabled:
        raise HTTPException(status_code=409, detail="Lauschmodus aktiv – Custom-Buttons sind deaktiviert.")

    await state.append_log(f"[CUSTOM] {button['name']} gestartet ({len(commands)} Befehle)")
    for command in commands:
        try:
            frame = await client.send_command(command)
            results.append({"command": command, "ok": True, "frame": frame.to_dict()})
        except Exception as exc:
            results.append({"command": command, "ok": False, "error": str(exc)})
            await state.append_log(f"[CUSTOM-ERR] {command}: {exc}")
            break
    return JSONResponse({"ok": all(item["ok"] for item in results), "button": button, "results": results})


def _parse_custom_commands(raw: str) -> list[str]:
    normalized = raw.replace("|", "\n")
    commands: list[str] = []
    for line in normalized.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        commands.append(stripped)
    return commands


# =========================================================
# Entrypoint
# =========================================================

def main() -> None:
    uvicorn.run("secudata_web.app:app", host="0.0.0.0", port=8787, reload=False, log_level="warning", access_log=False)


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8787, reload=False, log_level="warning", access_log=False)
