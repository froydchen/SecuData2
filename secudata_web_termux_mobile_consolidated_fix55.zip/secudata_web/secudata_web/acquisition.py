from __future__ import annotations

import asyncio
import hashlib
import re
import time
from typing import Optional

from .client import SecutestLiveConnection
from .models import MesStatus, RawProtocolRecord
from .protocol import parse_direct_prx_blocks, parse_esr_count, parse_mes_status, parse_psi_record, split_psi_records


class SecutestAcquisitionService:
    def __init__(self, client: SecutestLiveConnection) -> None:
        self.client = client

    async def send_raw(self, command: str):
        return await self.client.send_command(command)

    async def detect_connection_topology(self, timeout_ms: int = 3000) -> dict[str, str]:
        """Identify whether the TCP/RS232 bridge terminates at PSI or SECUTEST."""
        frame = await self.client.send_command("IDN?", timeout_ms=timeout_ms)
        payload = frame.payload_without_checksum.strip()
        upper = payload.upper().replace("-", " ")
        if "PSI" in upper and "SECUTEST" in upper:
            topology = "psi"
        elif "SECUTEST" in upper:
            topology = "direct_secutest"
        else:
            topology = "unknown"
        return {"topology": topology, "identity": payload}

    async def wait_for_direct_prx_ready(self, timeout_ms: int = 500) -> bool:
        # PRX$28 is a literal undocumented AutoStore-ready token, not a regular
        # SECUTEST checksum frame. Match it on the raw normalized input.
        frame = await self.client.wait_for_unsolicited_payload("PRX$28", timeout_ms=timeout_ms)
        return frame is not None

    async def fetch_direct_prx_record(self, timeout_ms: int = 3500) -> RawProtocolRecord:
        """Fetch one complete direct-AutoStore result exactly like the PSI does."""
        frames = []
        for suffix in ("X", "Y", "Z"):
            frame = await self.client.send_raw_cr_command(
                f"PRX?{suffix}",
                timeout_ms=timeout_ms,
                response_prefix="PROTOKOLL",
            )
            frames.append(frame)

        # Do not send TAS!a from inside the PRX fetch transaction. Field testing
        # showed that a console TAS!a works after the fetch even without a reset,
        # while TAS!a sent from this command context does not. The listen loop
        # therefore finalizes the PRX session only after this method has returned
        # and the outer PSI/action lock has been released.

        raw_bytes_parts: list[bytes] = []
        for frame in frames:
            if frame.raw_bytes is not None:
                raw_bytes_parts.append(frame.raw_bytes + b"\r")
            else:
                raw_bytes_parts.append((frame.raw + "\r").encode("cp437", errors="replace"))
        combined_bytes = b"".join(raw_bytes_parts)
        return parse_direct_prx_blocks(
            frames[0].payload_without_checksum,
            frames[1].payload_without_checksum,
            frames[2].payload_without_checksum,
            raw_frame="\n".join(frame.raw for frame in frames),
            raw_frame_hex=combined_bytes.hex().upper(),
            raw_sha256=hashlib.sha256(combined_bytes).hexdigest(),
        )


    async def send_tas_a(self, timeout_ms: int = 3000) -> dict[str, str]:
        """Send ``TAS!a`` over exactly the same path as a manual console command.

        This intentionally uses ``client.send_command`` (the normal framed ``$CS``
        request/ACK path also used by the debug console's ``/api/command``
        endpoint) rather than the undocumented raw-CR path. Field testing showed
        the raw-CR variant does not leave the SECUTEST in the same state as a
        manually typed console ``TAS!a``, even though both are acknowledged with
        an identical-looking ``.Yx`` frame. Both the automatic finalization and
        the manual title-bar button go through this one method so they are
        guaranteed to behave identically to a console entry.
        """
        frame = await self.client.send_command("TAS!a", timeout_ms=timeout_ms)
        return {"command": "TAS!a", "ack": frame.payload_without_checksum}

    async def finalize_direct_prx_session(self, timeout_ms: int = 3000) -> dict[str, str]:
        """Finish the direct PRX hand-off exactly like the captured original PSI.

        The SECUTEST first completes the Z checksum frame, then emits the terminal
        readiness bytes ``> 0x11`` without CR.  Only after those bytes were observed
        does the PSI send its finalization command. The caller is responsible for
        only invoking this once metadata input has actually been unlocked for the
        user - this method itself only waits for the device-side terminal-ready
        marker, not for the app's own UI state.
        """
        ready = await self.client.wait_for_terminal_ready(timeout_ms=1800)
        if not ready:
            raise RuntimeError("SECUTEST meldet nach PRX?Z kein Terminal-Ready (> + XON)")
        info = await self.send_tas_a(timeout_ms=timeout_ms)
        return {**info, "terminal_ready": "yes"}

    async def query_switch_position(self, timeout_ms: int = 3000) -> dict[str, str]:
        """Read the actual SECUTEST rotary-switch position via ``TAS?``.

        Observed S2N+10 responses look like ``TASTEx=04;D;;-``.  The first
        two-digit value is the physical/active switch position and corresponds
        directly to the RST selector (e.g. 03 -> RST!3, 04 -> RST!4).
        """
        frame = await self.client.send_command("TAS?", timeout_ms=timeout_ms)
        payload = frame.payload_without_checksum.strip()
        match = re.search(r"^TASTE[^=]*=([0-9A-Fa-f]{2})(?:;|$)", payload, re.IGNORECASE)
        if not match:
            raise ValueError(f"TAS?-Antwort enthält keine erkennbare Schalterstellung: {payload!r}")
        raw_code = match.group(1).upper()
        try:
            position = int(raw_code, 16)
        except ValueError as exc:
            raise ValueError(f"Ungültige TAS?-Schalterstellung: {raw_code!r}") from exc
        if not 1 <= position <= 8:
            raise ValueError(f"TAS?-Schalterstellung außerhalb 1..8: {raw_code}")
        return {
            "response": payload,
            "raw_position": raw_code,
            "position": str(position),
            "reset_code": str(position),
        }

    async def reset_mode_direct(self, rst_code: str | int | None = None) -> dict[str, str]:
        """Reset the directly attached SECUTEST without PSI/addressing round-trips.

        Automatic callers should omit ``rst_code``: the real switch position is
        queried immediately beforehand with TAS? and the matching RST!n is used.
        An explicit code is retained only for manual/diagnostic compatibility.
        """
        switch_info: dict[str, str] | None = None
        if rst_code is None:
            switch_info = await self.query_switch_position(timeout_ms=3000)
            code_text = switch_info["reset_code"]
        else:
            code_text = str(rst_code).strip().upper().removeprefix("RST!")
            if not code_text.isdigit() or not 1 <= int(code_text) <= 8:
                raise ValueError(f"Ungültiger RST-Code: {rst_code!r}")

        command = f"RST!{int(code_text)}"
        frame = await self.client.send_command(command, timeout_ms=10000)

        result = {
            "mode": "direct",
            "commands": command,
            "reset_command": command,
            "ack": frame.payload_without_checksum,
        }
        if switch_info is not None:
            result.update({
                "tas_response": switch_info["response"],
                "switch_position": switch_info["raw_position"],
            })
        return result

    def _addressing_enabled(self) -> bool:
        database = getattr(self.client, "database", None)
        if database is None:
            # Standalone tests and diagnostic clients keep the historical addressed
            # behavior unless a real settings database is attached.
            return True
        try:
            return database.get_settings().get("device_addressing_enabled", "0") == "1"
        except Exception:
            return False

    def _psi_command(self, operation: str, operator: str) -> str:
        address = "0" if self._addressing_enabled() else ""
        return f"{operation}{address}{operator}"

    async def fetch_latest_psi_record(
        self,
        clear_after_read: bool = False,
        wait_timeout_ms: int = 15000,
        poll_interval_s: float = 1.0,
    ) -> RawProtocolRecord:
        """Wait briefly for PSI AutoStore, then fetch the newest WER? record.

        After NTZON;NULL the SECUTEST can need a few seconds to hand the record to
        the PSI AutoStore memory. During that window MES? may even time out once and
        ESR? can still report 0000 records. Therefore WER? must not be fired once
        and treated as a protocol failure immediately.
        """
        deadline = time.monotonic() + max(0, wait_timeout_ms) / 1000
        last_error: Optional[BaseException] = None

        while True:
            count = None
            try:
                count = await self.query_psi_store_count()
            except Exception as exc:
                last_error = exc

            if count is None or count > 0 or time.monotonic() >= deadline:
                try:
                    frame = await self.client.send_command("WER?", timeout_ms=max(10000, wait_timeout_ms))
                    records = split_psi_records(frame.payload_without_checksum)
                    latest = records[-1] if records else None
                    if latest is None:
                        raise RuntimeError("PSI-Speicher leer")
                    parsed = parse_psi_record(latest)
                    raw_bytes = frame.raw_bytes or frame.raw.encode("cp437", errors="replace")
                    parsed.raw_frame = frame.raw
                    parsed.raw_payload = frame.payload_without_checksum
                    parsed.raw_frame_hex = raw_bytes.hex().upper()
                    parsed.raw_sha256 = hashlib.sha256(raw_bytes).hexdigest()
                    if clear_after_read:
                        await self.clear_psi_memory()
                    return parsed
                except Exception as exc:
                    last_error = exc
                    if "NACK" in str(exc).upper():
                        raise RuntimeError("PSI-Speicher leer oder AutoStore noch nicht abgeschlossen") from exc
                    if time.monotonic() >= deadline:
                        raise

            await asyncio.sleep(poll_interval_s)

        # unreachable, keeps type checkers calm
        raise RuntimeError(f"PSI-Datensatz nicht abrufbar: {last_error}")

    async def clear_psi_memory(self) -> None:
        await self.client.send_command(self._psi_command("MEM", "!"))

    async def clear_psi_memory_verified(
        self,
        *,
        force: bool,
        clear_attempts: int = 3,
        verify_attempts: int = 4,
        settle_delay_s: float = 0.25,
    ) -> dict[str, object]:
        """Clear PSI protocol memory and prove via ESR? that it is empty.

        Commands are addressed as MEM0!/ESR0? only when addressing is enabled;
        otherwise the protocol's unaddressed MEM!/ESR? forms are used. ``force``
        controls whether MEM is sent even if the initial count is already zero. If the initial
        check is unavailable, clearing is performed conservatively so a stale
        record cannot be imported again.
        """

        before_count: Optional[int] = None
        initial_check_error = ""
        try:
            before_count = await self._query_psi_store_count_retried(attempts=3, delay_s=0.18)
        except Exception as exc:
            initial_check_error = str(exc)

        should_clear = force or before_count is None or before_count > 0
        result: dict[str, object] = {
            "force": force,
            "before_count": before_count,
            "initial_check_error": initial_check_error,
            "clear_sent": False,
            "clear_attempts": 0,
            "after_count": before_count,
            "verified_empty": before_count == 0 and not force,
        }
        if not should_clear:
            return result

        last_error: Optional[BaseException] = None
        last_count: Optional[int] = before_count
        for clear_attempt in range(1, max(1, clear_attempts) + 1):
            result["clear_attempts"] = clear_attempt
            try:
                await self.clear_psi_memory()
                result["clear_sent"] = True
            except Exception as exc:
                last_error = exc
                if clear_attempt < clear_attempts:
                    await asyncio.sleep(settle_delay_s)
                    continue
                break

            # PSI may acknowledge MEM! before ESR? reflects the updated count.
            for verify_attempt in range(1, max(1, verify_attempts) + 1):
                if settle_delay_s > 0:
                    await asyncio.sleep(settle_delay_s)
                try:
                    last_count = await self.query_psi_store_count()
                    result["after_count"] = last_count
                    result["verify_attempts"] = verify_attempt
                    if last_count == 0:
                        result["verified_empty"] = True
                        return result
                    last_error = RuntimeError(f"PSI enthält nach MEM! noch {last_count} Protokoll(e)")
                except Exception as exc:
                    last_error = exc

        detail = str(last_error) if last_error else f"PSI-Restbestand: {last_count}"
        raise RuntimeError(f"PSI-Speicher konnte nicht verifiziert geleert werden: {detail}")

    async def _query_psi_store_count_retried(self, attempts: int = 3, delay_s: float = 0.2) -> int:
        last_error: Optional[BaseException] = None
        for attempt in range(1, max(1, attempts) + 1):
            try:
                count = await self.query_psi_store_count()
                if count is None:
                    raise RuntimeError("ESR?-Antwort enthielt keine auswertbare Protokollanzahl")
                return count
            except Exception as exc:
                last_error = exc
                if attempt < attempts and delay_s > 0:
                    await asyncio.sleep(delay_s)
        raise RuntimeError(f"PSI-Speicherstand konnte nicht geprüft werden: {last_error}")

    def _looks_like_addressed_secutest_identity(self, payload: str) -> bool:
        upper = payload.upper()
        return payload.strip().upper().startswith("IDN1=1;") and "SECUTEST" in upper and "SECUTEST-PSI" not in upper

    async def quick_addressing_check(self, timeout_ms: int = 1400) -> dict[str, str]:
        """Verify current addressing with one command: IDN1?."""
        frame = await self.client.send_command("IDN1?", timeout_ms=timeout_ms)
        payload = frame.payload_without_checksum
        if not self._looks_like_addressed_secutest_identity(payload):
            raise RuntimeError(f"IDN1? lieferte keine adressierte SECUTEST-Identität: {payload}")
        return {"mode": "quick_check", "commands": "IDN1?", "secutest_identity": payload}

    async def compact_initialize_addressing(self, retries: int = 3, retry_delay_s: float = 0.35) -> dict[str, str]:
        """Set PSI=0 and SECUTEST=1 with the shortest robust command chain."""
        last_error: Optional[BaseException] = None
        for attempt in range(1, max(1, retries) + 1):
            try:
                psi_addressed = await self.client.send_command("IDN!0", timeout_ms=3000)
                secutest_addressed = await self.client.send_command("IDN1!1", timeout_ms=3000)
                secutest_identity = await self.client.send_command("IDN1?", timeout_ms=3000)
                if not self._looks_like_addressed_secutest_identity(secutest_identity.payload_without_checksum):
                    raise RuntimeError(f"SECUTEST-Identität nach Kurz-Init unplausibel: {secutest_identity.payload_without_checksum}")
                return {
                    "mode": "compact_init",
                    "attempt": str(attempt),
                    "commands": "IDN!0 → IDN1!1 → IDN1?",
                    "psi_addressed": psi_addressed.payload_without_checksum,
                    "secutest_addressed": secutest_addressed.payload_without_checksum,
                    "secutest_identity": secutest_identity.payload_without_checksum,
                }
            except Exception as exc:
                last_error = exc
                if attempt < retries:
                    await asyncio.sleep(retry_delay_s)
        raise RuntimeError(f"Kurze Adressierungs-Init fehlgeschlagen: {last_error}")

    async def ensure_addressing(self, retries: int = 3, retry_delay_s: float = 0.35) -> dict[str, str]:
        """Use one probe command if possible, initialize only if necessary."""
        try:
            return await self.quick_addressing_check()
        except Exception as quick_error:
            try:
                result = await self.compact_initialize_addressing(retries=retries, retry_delay_s=retry_delay_s)
                result["quick_check_error"] = str(quick_error)
                return result
            except Exception:
                result = await self.initialize_addressing(retries=1, retry_delay_s=retry_delay_s)
                result["quick_check_error"] = str(quick_error)
                result["mode"] = "full_init_fallback"
                return result

    async def initialize_addressing(self, retries: int = 5, retry_delay_s: float = 0.7) -> dict[str, str]:
        """Run the full legacy addressing handshake as fallback/diagnostic path."""
        last_error: Optional[BaseException] = None
        for attempt in range(1, max(1, retries) + 1):
            try:
                psi_before = await self.client.send_command("IDN?", timeout_ms=3000)
                psi_addressed = await self.client.send_command("IDN!0", timeout_ms=3000)
                psi_after = await self.client.send_command("IDN?", timeout_ms=3000)
                secutest_addressed = await self.client.send_command("IDN1!1", timeout_ms=3000)
                secutest_identity = await self.client.send_command("IDN1?", timeout_ms=3000)
                return {
                    "mode": "full_init",
                    "attempt": str(attempt),
                    "commands": "IDN? → IDN!0 → IDN? → IDN1!1 → IDN1?",
                    "psi_before": psi_before.payload_without_checksum,
                    "psi_addressed": psi_addressed.payload_without_checksum,
                    "psi_after": psi_after.payload_without_checksum,
                    "secutest_addressed": secutest_addressed.payload_without_checksum,
                    "secutest_identity": secutest_identity.payload_without_checksum,
                }
            except Exception as exc:
                last_error = exc
                if attempt < retries:
                    await asyncio.sleep(retry_delay_s)
        raise RuntimeError(f"Adressierungs-Check/Init fehlgeschlagen: {last_error}")

    async def reset_mode_and_initialize(self, rst_code: str | int, rst_address: str | int = 1) -> dict[str, str]:
        """Reset the selected virtual mode, with optional device addressing.

        With addressing disabled the SECUTEST is controlled by the protocol's
        unaddressed form (for example ``RST!3``). With addressing enabled the
        historical PSI=0 / SECUTEST=1 handshake and addressed reset are retained.
        """
        code_text = str(rst_code).strip().upper().removeprefix("RST!")
        if not code_text.isdigit() or not 1 <= int(code_text) <= 8:
            raise ValueError(f"Ungültige RST-Modusziffer: {rst_code!r}")

        address_text = str(rst_address).strip().upper()
        if address_text.startswith("RST") and "!" in address_text:
            address_text = address_text[3:].split("!", 1)[0]
        if not address_text.isdigit() or not 0 <= int(address_text) <= 90:
            raise ValueError(f"Ungültige RST-Adresse: {rst_address!r}")

        addressing_enabled = self._addressing_enabled()
        pre_init: dict[str, str] = {"mode": "addressing_disabled", "commands": "none"}
        if addressing_enabled:
            pre_init = await self.ensure_addressing(retries=3, retry_delay_s=0.35)
            reset_command = f"RST{int(address_text)}!{int(code_text)}"
        else:
            reset_command = f"RST!{int(code_text)}"
        reset_frame = await self.client.send_command(reset_command, timeout_ms=3000)

        settings = getattr(self.client, "database", None)
        settings = settings.get_settings() if settings is not None else {}
        settle_ms = int(settings.get("post_reset_settle_ms", "2200"))
        if settle_ms > 0:
            await asyncio.sleep(settle_ms / 1000)

        if addressing_enabled:
            post_init = await self.ensure_addressing(retries=5, retry_delay_s=0.4)
        else:
            post_init = {"mode": "addressing_disabled", "commands": "none"}
        return {
            "addressing_enabled": "1" if addressing_enabled else "0",
            "pre_check": pre_init,
            "post_check": post_init,
            "pre_init": pre_init,
            "post_init": post_init,
            "reset": reset_frame.payload_without_checksum,
            "reset_command": reset_command,
            "secutest_identity": post_init.get("secutest_identity", ""),
            "psi_after": post_init.get("psi_after", ""),
        }

    async def reset_current_mode_and_initialize(self) -> dict[str, str]:
        """Backward-compatible manual fallback. Avoid full RST!0 by default."""
        return await self.reset_mode_and_initialize(3, 1)

    async def query_psi_store_count(self) -> Optional[int]:
        frame = await self.client.send_command(self._psi_command("ESR", "?"))
        return parse_esr_count(frame.payload_without_checksum)

    async def query_mes_status(self) -> MesStatus:
        frame = await self.client.send_command("MES?")
        return parse_mes_status(frame.payload_without_checksum)

    async def press_enter(self) -> None:
        await self.client.send_command("TAS!4")

    async def fetch_protocol_from_device(self) -> Optional[str]:
        frame = await self.client.send_command("PRO?")
        payload = frame.payload_without_checksum.strip()
        return payload or None

    async def fetch_measurement_value(self, measure_number: int) -> Optional[str]:
        frame = await self.client.send_command(f"WER?{measure_number}")
        payload = frame.payload_without_checksum.strip()
        return payload or None

    async def trigger_measurement_by_number(self, measure_number: int) -> None:
        await self.client.send_command(f"MES!{measure_number}")
