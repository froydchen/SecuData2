from __future__ import annotations

import json
import sqlite3
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from .models import DraftInputState, FinalRecord, MeasurementMetadata, MeasurementRaw, Project, RawProtocolRecord


class Database:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        with self._lock, self._conn:
            self._conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS projects (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    customer TEXT NOT NULL,
                    cycle_month TEXT NOT NULL,
                    street TEXT NOT NULL DEFAULT '',
                    postal_code TEXT NOT NULL DEFAULT '',
                    city TEXT NOT NULL DEFAULT '',
                    test_interval_months TEXT NOT NULL DEFAULT '24',
                    inspector TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    project_id INTEGER,
                    project_sequence INTEGER,
                    created_at TEXT NOT NULL,
                    measurement_timestamp TEXT NOT NULL,
                    rpe REAL,
                    rins REAL,
                    ipe REAL,
                    u REAL,
                    is_ok INTEGER NOT NULL,
                    measurement_values TEXT NOT NULL DEFAULT '[]',
                    external_id TEXT NOT NULL DEFAULT '',
                    geraeteart TEXT NOT NULL DEFAULT '',
                    hersteller TEXT NOT NULL DEFAULT '',
                    raum_etage TEXT NOT NULL DEFAULT '',
                    kunde TEXT NOT NULL DEFAULT '',
                    typ_modell TEXT NOT NULL DEFAULT '',
                    seriennummer TEXT NOT NULL DEFAULT '',
                    pruefer TEXT NOT NULL DEFAULT '',
                    zusatztext TEXT NOT NULL DEFAULT '',
                    raw_protocol TEXT NOT NULL DEFAULT '',
                    raw_fields TEXT NOT NULL DEFAULT '[]',
                    raw_source TEXT NOT NULL DEFAULT '',
                    protocol_number TEXT NOT NULL DEFAULT ''
                );

                CREATE TABLE IF NOT EXISTS draft_input (
                    singleton_id INTEGER PRIMARY KEY CHECK (singleton_id = 1),
                    external_id TEXT NOT NULL DEFAULT '',
                    geraeteart TEXT NOT NULL DEFAULT '',
                    hersteller TEXT NOT NULL DEFAULT '',
                    raum_etage TEXT NOT NULL DEFAULT '',
                    kunde TEXT NOT NULL DEFAULT '',
                    typ_modell TEXT NOT NULL DEFAULT '',
                    seriennummer TEXT NOT NULL DEFAULT '',
                    pruefer TEXT NOT NULL DEFAULT '',
                    zusatztext TEXT NOT NULL DEFAULT '',
                    raw_protocol TEXT NOT NULL DEFAULT '',
                    raw_fields TEXT NOT NULL DEFAULT '[]',
                    raw_source TEXT NOT NULL DEFAULT '',
                    protocol_number TEXT NOT NULL DEFAULT ''
                );

                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS custom_buttons (
                    id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    commands TEXT NOT NULL DEFAULT ''
                );

                CREATE TABLE IF NOT EXISTS measurement_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    received_at REAL NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_measurement_events_received_at
                    ON measurement_events(received_at);
                """
            )
            self._conn.execute(
                """
                INSERT OR IGNORE INTO draft_input (
                    singleton_id, external_id, geraeteart, hersteller, raum_etage,
                    kunde, typ_modell, seriennummer, pruefer, zusatztext
                ) VALUES (1, '', '', '', '', '', '', '', '', '')
                """
            )
            project_columns = {row["name"] for row in self._conn.execute("PRAGMA table_info(projects)").fetchall()}
            if "street" not in project_columns:
                self._conn.execute("ALTER TABLE projects ADD COLUMN street TEXT NOT NULL DEFAULT ''")
            if "postal_code" not in project_columns:
                self._conn.execute("ALTER TABLE projects ADD COLUMN postal_code TEXT NOT NULL DEFAULT ''")
            if "city" not in project_columns:
                self._conn.execute("ALTER TABLE projects ADD COLUMN city TEXT NOT NULL DEFAULT ''")
            if "test_interval_months" not in project_columns:
                self._conn.execute("ALTER TABLE projects ADD COLUMN test_interval_months TEXT NOT NULL DEFAULT '24'")
            if "inspector" not in project_columns:
                self._conn.execute("ALTER TABLE projects ADD COLUMN inspector TEXT NOT NULL DEFAULT ''")

            columns = {row["name"] for row in self._conn.execute("PRAGMA table_info(records)").fetchall()}
            if "measurement_values" not in columns:
                self._conn.execute("ALTER TABLE records ADD COLUMN measurement_values TEXT NOT NULL DEFAULT '[]'")
            if "project_id" not in columns:
                self._conn.execute("ALTER TABLE records ADD COLUMN project_id INTEGER")
            if "project_sequence" not in columns:
                self._conn.execute("ALTER TABLE records ADD COLUMN project_sequence INTEGER")
            if "raw_protocol" not in columns:
                self._conn.execute("ALTER TABLE records ADD COLUMN raw_protocol TEXT NOT NULL DEFAULT ''")
            if "raw_fields" not in columns:
                self._conn.execute("ALTER TABLE records ADD COLUMN raw_fields TEXT NOT NULL DEFAULT '[]'")
            if "raw_source" not in columns:
                self._conn.execute("ALTER TABLE records ADD COLUMN raw_source TEXT NOT NULL DEFAULT ''")
            if "protocol_number" not in columns:
                self._conn.execute("ALTER TABLE records ADD COLUMN protocol_number TEXT NOT NULL DEFAULT ''")

            defaults = {
                "host": "10.10.100.254",
                "port": "8899",
                "simulation_enabled": "0",
                "autosave_enabled": "1",
                "autosave_path": "data/records_autosave.xlsx",
                "poll_interval_ms": "300",
                "command_timeout_ms": "2500",
                # RST!0 is a full watchdog reset and is too slow for the field workflow.
                # Live device mapping: RSTx!3 = SK I/II, RSTx!4 = Leitungen.
                # The target address is configurable because some bridge setups answer
                # through PSI address 0, while the SECUTEST behind it is address 1.
                "rst_code_sk_i_ii": "3",
                "rst_code_leitungen": "4",
                "device_addressing_enabled": "0",
                "rst_target_address": "1",
                "post_reset_settle_ms": "2200",
                "room_prompt_idle_seconds": "120",
                "measurement_rate_window_minutes": "30",
                "capture_scroll_position_px": "500",
                "auto_scan_after_measurement": "0",
                "active_project_id": "",
            }
            for key, value in defaults.items():
                self._conn.execute("INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)", (key, value))

            # fix39 migration: fix38 counted every received measurement in the
            # throughput display, including discarded measurements.  The same
            # table is retained for compatibility, but from now on it contains
            # saved-measurement events only.  Remove the old receive-based data
            # once so the displayed rate is not polluted after updating.
            rate_basis_migration = self._conn.execute(
                "SELECT value FROM settings WHERE key='measurement_rate_saved_only_v39'"
            ).fetchone()
            if rate_basis_migration is None:
                self._conn.execute("DELETE FROM measurement_events")
                self._conn.execute(
                    "INSERT INTO settings(key, value) VALUES ('measurement_rate_saved_only_v39', '1')"
                )

            # fix14 migration: fix13 shipped the two mode digits inverted.  If an
            # existing database still has exactly those old defaults, correct them
            # automatically.  User-edited values are left untouched.
            current_sk = self._conn.execute("SELECT value FROM settings WHERE key='rst_code_sk_i_ii'").fetchone()
            current_leitung = self._conn.execute("SELECT value FROM settings WHERE key='rst_code_leitungen'").fetchone()
            if current_sk and current_leitung and current_sk["value"] == "4" and current_leitung["value"] == "3":
                self._conn.execute("UPDATE settings SET value='3' WHERE key='rst_code_sk_i_ii'")
                self._conn.execute("UPDATE settings SET value='4' WHERE key='rst_code_leitungen'")

            for index in range(1, 7):
                self._conn.execute(
                    "INSERT OR IGNORE INTO custom_buttons(id, name, commands) VALUES (?, ?, ?)",
                    (index, f"USER {index}", ""),
                )

    def record_measurement_saved(self, saved_at: Optional[float] = None) -> None:
        """Record one measurement that was successfully persisted by the app."""
        timestamp = float(time.time() if saved_at is None else saved_at)
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT INTO measurement_events(received_at) VALUES (?)",
                (timestamp,),
            )
            # The display never needs ancient events. Keep a generous seven-day
            # history so changing the window does not bloat the field database.
            self._conn.execute(
                "DELETE FROM measurement_events WHERE received_at < ?",
                (timestamp - (7 * 24 * 60 * 60),),
            )

    def get_measurement_rate(self, window_minutes: int = 30, now: Optional[float] = None) -> dict[str, Any]:
        window = max(1, int(window_minutes))
        current = float(time.time() if now is None else now)
        cutoff = current - (window * 60)
        with self._lock:
            row = self._conn.execute(
                "SELECT COUNT(*) AS count, MAX(received_at) AS latest "
                "FROM measurement_events WHERE received_at >= ?",
                (cutoff,),
            ).fetchone()
        count = int(row["count"] if row else 0)
        latest = float(row["latest"]) if row and row["latest"] is not None else None
        return {
            "window_minutes": window,
            "count": count,
            "rate_per_hour": round(count * 60.0 / window, 2),
            "last_saved_at": latest,
        }

    def _project_from_row(self, row: sqlite3.Row | None) -> Optional[Project]:
        if row is None:
            return None
        keys = set(row.keys())
        return Project(
            id=int(row["id"]),
            name=row["name"],
            customer=row["customer"],
            cycle_month=row["cycle_month"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            street=row["street"] if "street" in keys else "",
            postal_code=row["postal_code"] if "postal_code" in keys else "",
            city=row["city"] if "city" in keys else "",
            test_interval_months=row["test_interval_months"] if "test_interval_months" in keys and row["test_interval_months"] else "24",
            inspector=row["inspector"] if "inspector" in keys else "",
        )

    def get_projects(self) -> list[Project]:
        with self._lock:
            rows = self._conn.execute("SELECT * FROM projects ORDER BY updated_at DESC, id DESC").fetchall()
        return [self._project_from_row(row) for row in rows if row is not None]

    def get_project(self, project_id: int) -> Optional[Project]:
        with self._lock:
            row = self._conn.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
        return self._project_from_row(row)

    def get_active_project_id(self) -> Optional[int]:
        with self._lock:
            row = self._conn.execute("SELECT value FROM settings WHERE key='active_project_id'").fetchone()
        if not row or not str(row["value"]).strip():
            return None
        try:
            return int(row["value"])
        except ValueError:
            return None

    def get_active_project(self) -> Optional[Project]:
        project_id = self.get_active_project_id()
        return self.get_project(project_id) if project_id is not None else None

    def set_active_project(self, project_id: int) -> Project:
        project = self.get_project(project_id)
        if project is None:
            raise ValueError("Projekt nicht gefunden.")
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT INTO settings(key, value) VALUES ('active_project_id', ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (str(project_id),),
            )
        return project

    def upsert_project(
        self,
        customer: str,
        cycle_month: str,
        street: str = "",
        postal_code: str = "",
        city: str = "",
        test_interval_months: str = "24",
        inspector: str = "",
        project_id: Optional[int] = None,
    ) -> Project:
        customer = customer.strip()
        cycle_month = cycle_month.strip()
        street = street.strip()
        postal_code = postal_code.strip()
        city = city.strip()
        test_interval_months = (test_interval_months or "24").strip()
        inspector = inspector.strip()
        if not customer:
            raise ValueError("Kundenname fehlt.")
        if not cycle_month:
            raise ValueError("Prüfzyklus Monat/Jahr fehlt.")
        if not street:
            raise ValueError("Straße fehlt.")
        if not postal_code:
            raise ValueError("Postleitzahl fehlt.")
        if not city:
            raise ValueError("Ort fehlt.")
        if not test_interval_months:
            raise ValueError("Prüfintervall fehlt.")
        if not inspector:
            raise ValueError("Prüfer fehlt.")
        name = f"{customer}_{self._format_cycle_label(cycle_month)}"
        now = datetime.now().isoformat(timespec="seconds")
        with self._lock, self._conn:
            if project_id:
                exists = self._conn.execute("SELECT id FROM projects WHERE id=?", (project_id,)).fetchone()
                if exists is None:
                    raise ValueError("Projekt nicht gefunden.")
                self._conn.execute(
                    "UPDATE projects SET name=?, customer=?, cycle_month=?, street=?, postal_code=?, city=?, test_interval_months=?, inspector=?, updated_at=? WHERE id=?",
                    (name, customer, cycle_month, street, postal_code, city, test_interval_months, inspector, now, project_id),
                )
                pid = project_id
            else:
                cursor = self._conn.execute(
                    "INSERT INTO projects(name, customer, cycle_month, street, postal_code, city, test_interval_months, inspector, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (name, customer, cycle_month, street, postal_code, city, test_interval_months, inspector, now, now),
                )
                pid = int(cursor.lastrowid)
            self._conn.execute(
                "INSERT INTO settings(key, value) VALUES ('active_project_id', ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (str(pid),),
            )
        project = self.get_project(pid)
        assert project is not None
        return project

    @staticmethod
    def _format_cycle_label(value: str) -> str:
        text = str(value or "").strip()
        # HTML month input returns YYYY-MM.  The filename/project display should be MM.JJJJ.
        if len(text) == 7 and text[4] == "-":
            return f"{text[5:7]}.{text[0:4]}"
        return text.replace("/", ".").replace(" ", "_")

    def get_settings(self) -> dict[str, str]:
        with self._lock:
            rows = self._conn.execute("SELECT key, value FROM settings").fetchall()
        return {row["key"]: row["value"] for row in rows}

    def set_settings(self, updates: dict[str, Any]) -> dict[str, str]:
        with self._lock, self._conn:
            for key, value in updates.items():
                self._conn.execute(
                    "INSERT INTO settings(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (key, str(value)),
                )
        return self.get_settings()

    def get_draft(self) -> DraftInputState:
        with self._lock:
            row = self._conn.execute("SELECT * FROM draft_input WHERE singleton_id = 1").fetchone()
        assert row is not None
        return DraftInputState(
            id=row["external_id"],
            geraeteart=row["geraeteart"],
            hersteller=row["hersteller"],
            raum_etage=row["raum_etage"],
            kunde=row["kunde"],
            typ_modell=row["typ_modell"],
            seriennummer=row["seriennummer"],
            pruefer=row["pruefer"],
            zusatztext=row["zusatztext"],
        )

    def save_draft(self, draft: DraftInputState) -> DraftInputState:
        with self._lock, self._conn:
            self._conn.execute(
                """
                UPDATE draft_input SET
                    external_id=?, geraeteart=?, hersteller=?, raum_etage=?, kunde=?,
                    typ_modell=?, seriennummer=?, pruefer=?, zusatztext=?
                WHERE singleton_id=1
                """,
                (
                    draft.id,
                    draft.geraeteart,
                    draft.hersteller,
                    draft.raum_etage,
                    draft.kunde,
                    draft.typ_modell,
                    draft.seriennummer,
                    draft.pruefer,
                    draft.zusatztext,
                ),
            )
        return self.get_draft()

    def insert_record(
        self,
        measurement: MeasurementRaw,
        metadata: MeasurementMetadata,
        project_id: Optional[int] = None,
        raw_protocol: Optional[RawProtocolRecord] = None,
    ) -> FinalRecord:
        created_at = measurement.timestamp or datetime.now().isoformat(timespec="seconds")
        if project_id is None:
            project_id = self.get_active_project_id()
        raw_text = raw_protocol.raw_record if raw_protocol else ""
        raw_fields = raw_protocol.raw_fields if raw_protocol else []
        raw_source = raw_protocol.source if raw_protocol else ""
        protocol_number = raw_protocol.protocol_number or "" if raw_protocol else ""
        with self._lock, self._conn:
            if project_id is not None:
                row = self._conn.execute(
                    "SELECT COALESCE(MAX(project_sequence), 0) + 1 AS next_seq FROM records WHERE project_id=?",
                    (project_id,),
                ).fetchone()
                project_sequence = int(row["next_seq"] or 1)
            else:
                project_sequence = None
            cursor = self._conn.execute(
                """
                INSERT INTO records (
                    project_id, project_sequence, created_at, measurement_timestamp, rpe, rins, ipe, u, is_ok, measurement_values,
                    external_id, geraeteart, hersteller, raum_etage, kunde,
                    typ_modell, seriennummer, pruefer, zusatztext,
                    raw_protocol, raw_fields, raw_source, protocol_number
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    project_id,
                    project_sequence,
                    created_at,
                    measurement.timestamp,
                    measurement.rpe,
                    measurement.rins,
                    measurement.ipe,
                    measurement.u,
                    1 if measurement.is_ok else 0,
                    json.dumps(measurement.values or [], ensure_ascii=False),
                    metadata.id,
                    metadata.geraeteart,
                    metadata.hersteller,
                    metadata.raum_etage,
                    metadata.kunde,
                    metadata.typ_modell,
                    metadata.seriennummer,
                    metadata.pruefer,
                    metadata.zusatztext,
                    raw_text,
                    json.dumps(raw_fields or [], ensure_ascii=False),
                    raw_source,
                    protocol_number,
                ),
            )
            record_id = int(cursor.lastrowid)
        return FinalRecord(
            id=record_id,
            project_sequence=project_sequence,
            created_at=created_at,
            measurement=measurement,
            metadata=metadata,
            project_id=project_id,
            raw_protocol=raw_text,
            raw_fields=list(raw_fields or []),
            raw_source=raw_source,
            protocol_number=protocol_number or None,
        )

    def update_record(self, record_id: int, metadata: MeasurementMetadata) -> Optional[FinalRecord]:
        with self._lock, self._conn:
            exists = self._conn.execute("SELECT id FROM records WHERE id = ?", (record_id,)).fetchone()
            if exists is None:
                return None
            self._conn.execute(
                """
                UPDATE records SET
                    external_id=?, geraeteart=?, hersteller=?, raum_etage=?, kunde=?,
                    typ_modell=?, seriennummer=?, pruefer=?, zusatztext=?
                WHERE id=?
                """,
                (
                    metadata.id,
                    metadata.geraeteart,
                    metadata.hersteller,
                    metadata.raum_etage,
                    metadata.kunde,
                    metadata.typ_modell,
                    metadata.seriennummer,
                    metadata.pruefer,
                    metadata.zusatztext,
                    record_id,
                ),
            )
        return self.get_record(record_id)

    def get_record(self, record_id: int) -> Optional[FinalRecord]:
        with self._lock:
            row = self._conn.execute("SELECT * FROM records WHERE id = ?", (record_id,)).fetchone()
        return self._row_to_record(row) if row else None

    def get_records(self, sort: str = "chronological_desc", project_id: Optional[int] = None) -> list[FinalRecord]:
        order_by = {
            "chronological": "created_at ASC, id ASC",
            "chronological_desc": "created_at DESC, id DESC",
            "id_asc": "external_id COLLATE NOCASE ASC, created_at DESC",
            "device_asc": "geraeteart COLLATE NOCASE ASC, created_at DESC",
            "manufacturer_asc": "hersteller COLLATE NOCASE ASC, created_at DESC",
            "room_asc": "raum_etage COLLATE NOCASE ASC, created_at DESC",
            "result_asc": "is_ok DESC, created_at DESC",
        }.get(sort, "created_at DESC, id DESC")
        if project_id is None:
            project_id = self.get_active_project_id()
        with self._lock:
            if project_id is None:
                rows = self._conn.execute(f"SELECT * FROM records ORDER BY {order_by}").fetchall()
            else:
                rows = self._conn.execute(f"SELECT * FROM records WHERE project_id=? ORDER BY {order_by}", (project_id,)).fetchall()
        return [self._row_to_record(row) for row in rows]

    def metadata_rows(self) -> list[dict[str, str]]:
        project_id = self.get_active_project_id()
        with self._lock:
            if project_id is None:
                rows = self._conn.execute(
                    "SELECT external_id, geraeteart, hersteller, raum_etage, kunde FROM records ORDER BY created_at DESC, id DESC"
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT external_id, geraeteart, hersteller, raum_etage, kunde FROM records WHERE project_id=? ORDER BY created_at DESC, id DESC",
                    (project_id,),
                ).fetchall()
        return [
            {
                "id": row["external_id"],
                "geraeteart": row["geraeteart"],
                "hersteller": row["hersteller"],
                "raum_etage": row["raum_etage"],
                "kunde": row["kunde"],
            }
            for row in rows
        ]

    def get_custom_buttons(self) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute("SELECT id, name, commands FROM custom_buttons ORDER BY id ASC").fetchall()
        return [{"id": row["id"], "name": row["name"], "commands": row["commands"]} for row in rows]

    def update_custom_button(self, button_id: int, name: str, commands: str) -> Optional[dict[str, Any]]:
        with self._lock, self._conn:
            exists = self._conn.execute("SELECT id FROM custom_buttons WHERE id = ?", (button_id,)).fetchone()
            if exists is None:
                return None
            self._conn.execute(
                "UPDATE custom_buttons SET name=?, commands=? WHERE id=?",
                (name.strip() or f"USER {button_id}", commands.strip(), button_id),
            )
        return next((button for button in self.get_custom_buttons() if button["id"] == button_id), None)

    def import_records(self, records: list[FinalRecord], project_id: Optional[int] = None) -> int:
        inserted = 0
        if project_id is None:
            project_id = self.get_active_project_id()
        with self._lock, self._conn:
            for record in records:
                target_project_id = record.project_id if record.project_id is not None else project_id
                if record.project_sequence is not None:
                    project_sequence = record.project_sequence
                elif target_project_id is not None:
                    row = self._conn.execute(
                        "SELECT COALESCE(MAX(project_sequence), 0) + 1 AS next_seq FROM records WHERE project_id=?",
                        (target_project_id,),
                    ).fetchone()
                    project_sequence = int(row["next_seq"] or 1)
                else:
                    project_sequence = None
                self._conn.execute(
                    """
                    INSERT INTO records (
                        project_id, project_sequence, created_at, measurement_timestamp, rpe, rins, ipe, u, is_ok, measurement_values,
                        external_id, geraeteart, hersteller, raum_etage, kunde,
                        typ_modell, seriennummer, pruefer, zusatztext,
                        raw_protocol, raw_fields, raw_source, protocol_number
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        target_project_id,
                        project_sequence,
                        record.created_at,
                        record.measurement.timestamp,
                        record.measurement.rpe,
                        record.measurement.rins,
                        record.measurement.ipe,
                        record.measurement.u,
                        1 if record.measurement.is_ok else 0,
                        json.dumps(record.measurement.values or [], ensure_ascii=False),
                        record.metadata.id,
                        record.metadata.geraeteart,
                        record.metadata.hersteller,
                        record.metadata.raum_etage,
                        record.metadata.kunde,
                        record.metadata.typ_modell,
                        record.metadata.seriennummer,
                        record.metadata.pruefer,
                        record.metadata.zusatztext,
                        record.raw_protocol,
                        json.dumps(record.raw_fields or [], ensure_ascii=False),
                        record.raw_source,
                        record.protocol_number or "",
                    ),
                )
                inserted += 1
        return inserted

    def _row_to_record(self, row: sqlite3.Row) -> FinalRecord:
        try:
            measurement_values = json.loads(row["measurement_values"] or "[]")
            if not isinstance(measurement_values, list):
                measurement_values = []
        except Exception:
            measurement_values = []
        try:
            raw_fields = json.loads(row["raw_fields"] or "[]") if "raw_fields" in row.keys() else []
            if not isinstance(raw_fields, list):
                raw_fields = []
        except Exception:
            raw_fields = []
        measurement = MeasurementRaw(
            rpe=row["rpe"],
            rins=row["rins"],
            ipe=row["ipe"],
            u=row["u"],
            timestamp=row["measurement_timestamp"],
            is_ok=bool(row["is_ok"]),
            values=measurement_values,
        )
        metadata = MeasurementMetadata(
            id=row["external_id"],
            geraeteart=row["geraeteart"],
            hersteller=row["hersteller"],
            raum_etage=row["raum_etage"],
            kunde=row["kunde"],
            typ_modell=row["typ_modell"],
            seriennummer=row["seriennummer"],
            pruefer=row["pruefer"],
            zusatztext=row["zusatztext"],
        )
        return FinalRecord(
            id=row["id"],
            project_sequence=(row["project_sequence"] if "project_sequence" in row.keys() else None),
            created_at=row["created_at"],
            measurement=measurement,
            metadata=metadata,
            project_id=row["project_id"] if "project_id" in row.keys() else None,
            raw_protocol=row["raw_protocol"] if "raw_protocol" in row.keys() else "",
            raw_fields=[str(value) for value in raw_fields],
            raw_source=row["raw_source"] if "raw_source" in row.keys() else "",
            protocol_number=(row["protocol_number"] if "protocol_number" in row.keys() and row["protocol_number"] else None),
        )
