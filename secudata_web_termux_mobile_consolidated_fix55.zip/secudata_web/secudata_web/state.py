from __future__ import annotations

import asyncio
from collections import deque
from datetime import datetime
from typing import Any, Optional

from starlette.websockets import WebSocket

from .database import Database
from .models import DraftInputState, MeasurementRaw, RawProtocolRecord, SequenceResult
from .protocol import reset_button_hint_from_fields


class EventHub:
    def __init__(self) -> None:
        self._clients: set[WebSocket] = set()
        self._lock = asyncio.Lock()

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        async with self._lock:
            self._clients.add(websocket)

    async def disconnect(self, websocket: WebSocket) -> None:
        async with self._lock:
            self._clients.discard(websocket)

    async def broadcast(self, payload: dict[str, Any]) -> None:
        async with self._lock:
            clients = list(self._clients)
        if not clients:
            return
        stale: list[WebSocket] = []
        for websocket in clients:
            try:
                await websocket.send_json(payload)
            except Exception:
                stale.append(websocket)
        if stale:
            async with self._lock:
                for websocket in stale:
                    self._clients.discard(websocket)


class AppState:
    def __init__(self, database: Database, event_hub: EventHub) -> None:
        self.database = database
        self.event_hub = event_hub
        self.connection_status = "DISCONNECTED"
        self.connection_detail = ""
        self.connection_topology = "unknown"
        self.connection_identity = ""
        self.app_state = "READY_FOR_MEASUREMENT"
        self.is_loading = False
        self.is_sequence_running = False
        self.cancel_sequence_requested = False
        self.listen_mode_enabled = False
        self.listen_state = "off"
        self.listen_message = ""
        self.listen_poll_interval_ms = 500
        self.listen_last_protocol_count: Optional[int] = None
        self.direct_prx_pending_count = 0
        self.listen_error_message: Optional[str] = None
        self.active_measurement_button: Optional[str] = None
        self.last_measurement_button: Optional[str] = None
        self.current_measurement: Optional[MeasurementRaw] = None
        self.current_raw_protocol: Optional[RawProtocolRecord] = None
        self.current_device_status: Optional[str] = None
        self.last_sequence_message: Optional[str] = None
        self.last_sequence_result: Optional[SequenceResult] = None
        self.error_message: Optional[str] = None
        self.save_progress_percent = 0
        self.save_progress_label = ""
        self.logs: deque[str] = deque(maxlen=240)
        self.comm_log: deque[dict[str, Any]] = deque(maxlen=240)
        self._state_lock = asyncio.Lock()

    async def append_log(self, message: str) -> None:
        timestamp = datetime.now().strftime("%d.%m.%y %H:%M:%S")
        line = f"[{timestamp}] {message}"
        self.logs.append(line)
        await self.event_hub.broadcast({"type": "log", "line": line})

    async def append_comm_log(self, entry: dict[str, Any]) -> None:
        self.comm_log.append(entry)
        await self.event_hub.broadcast({"type": "comm", "entry": entry})

    def measurement_rate_snapshot(self) -> dict[str, Any]:
        settings = self.database.get_settings()
        try:
            window_minutes = int(settings.get("measurement_rate_window_minutes", "30"))
        except (TypeError, ValueError):
            window_minutes = 30
        return self.database.get_measurement_rate(window_minutes)

    async def broadcast_draft(self, draft: DraftInputState, reason: str = "server") -> None:
        await self.event_hub.broadcast({"type": "draft", "draft": draft.to_dict(), "reason": reason})

    async def set_connection_status(self, status: str, detail: str = "") -> None:
        self.connection_status = status
        self.connection_detail = detail
        await self.emit_state()

    async def set_connection_topology(self, topology: str, identity: str = "") -> None:
        self.connection_topology = topology or "unknown"
        self.connection_identity = identity or ""
        await self.emit_state()

    async def note_direct_prx_pending(self, *, warn: bool = True) -> None:
        # PRX$28 may be repeated by the device until the result is collected.
        # One pending slot is enough; counting repeats would import the same
        # SECUTEST result multiple times after the user saves the current record.
        self.direct_prx_pending_count = 1
        if not warn:
            await self.emit_state()
            return
        message = (
            "Neue Messdaten stehen am SECUTEST bereit, aber die aktuelle Messung ist noch nicht gespeichert. "
            "Bitte zuerst speichern; der Abruf wird danach automatisch nachgeholt."
        )
        self.listen_state = "unsaved"
        self.listen_message = message
        self.listen_error_message = None
        await self.emit_state()
        await self.event_hub.broadcast({"type": "listen_new_data_pending", "message": message})

    async def consume_direct_prx_pending(self) -> bool:
        if self.direct_prx_pending_count <= 0:
            return False
        self.direct_prx_pending_count -= 1
        await self.emit_state()
        return True

    async def set_sequence_running(self, running: bool, button: Optional[str] = None) -> None:
        self.is_sequence_running = running
        self.is_loading = running
        if running:
            self.cancel_sequence_requested = False
        if button:
            self.active_measurement_button = button
            self.last_measurement_button = button
        self.app_state = "FETCHING_MEASUREMENT" if running else self.app_state
        await self.emit_state()

    def _remember_measurement_mode(self, raw_protocol: Optional[RawProtocolRecord]) -> None:
        if raw_protocol is None:
            return
        hint = reset_button_hint_from_fields(raw_protocol.raw_fields or [])
        if hint:
            self.active_measurement_button = hint
            self.last_measurement_button = hint

    async def set_sequence_result(
        self,
        result: SequenceResult,
        measurement: Optional[MeasurementRaw],
        raw_protocol: Optional[RawProtocolRecord],
    ) -> None:
        self.last_sequence_result = result
        self.last_sequence_message = result.message
        self.current_device_status = result.final_status_raw
        self.is_loading = False
        self.is_sequence_running = False
        self.cancel_sequence_requested = False
        self.error_message = None if result.success else result.message
        self.current_measurement = measurement or self.current_measurement
        self.current_raw_protocol = raw_protocol or self.current_raw_protocol
        self._remember_measurement_mode(self.current_raw_protocol)
        self.app_state = "MEASUREMENT_RECEIVED_NEEDS_METADATA" if measurement else "READY_FOR_MEASUREMENT"
        await self.emit_state()

    async def set_error(self, message: str) -> None:
        self.error_message = message
        self.is_loading = False
        self.is_sequence_running = False
        self.cancel_sequence_requested = False
        self.app_state = "READY_FOR_MEASUREMENT"
        await self.emit_state()

    async def set_measurement_ready(self, measurement: MeasurementRaw, raw_protocol: Optional[RawProtocolRecord]) -> None:
        self.save_progress_percent = 0
        self.save_progress_label = ""
        self.current_measurement = measurement
        self.current_raw_protocol = raw_protocol
        self._remember_measurement_mode(raw_protocol)
        self.app_state = "MEASUREMENT_RECEIVED_NEEDS_METADATA"
        self.is_loading = False
        self.is_sequence_running = False
        self.cancel_sequence_requested = False
        await self.emit_state()

    async def set_listen_mode(self, enabled: bool, message: str = "") -> None:
        self.listen_mode_enabled = enabled
        self.listen_state = "waiting" if enabled else "off"
        self.listen_message = message or (
            "Lauschmodus aktiv – warte auf PSI-Messdaten …" if enabled else "Lauschmodus aus."
        )
        self.listen_error_message = None
        if not enabled:
            self.direct_prx_pending_count = 0
        if enabled:
            self.active_measurement_button = None
            if self.app_state == "READY_FOR_MEASUREMENT":
                self.app_state = "LISTEN_WAITING"
        elif self.app_state in {"LISTEN_WAITING", "LISTEN_FETCHING", "LISTEN_ERROR"}:
            self.app_state = "READY_FOR_MEASUREMENT"
        await self.emit_state()

    async def set_listen_state(self, listen_state: str, message: str = "", error: Optional[str] = None) -> None:
        target_app_state = self.app_state
        if self.listen_mode_enabled and self.current_measurement is None and not self.is_loading:
            if listen_state == "waiting":
                target_app_state = "LISTEN_WAITING"
            elif listen_state == "fetching":
                target_app_state = "LISTEN_FETCHING"
            elif listen_state == "error":
                target_app_state = "LISTEN_ERROR"
        if (
            self.listen_state == listen_state
            and self.listen_message == message
            and self.listen_error_message == error
            and self.app_state == target_app_state
        ):
            return
        self.listen_state = listen_state
        self.listen_message = message
        self.listen_error_message = error
        self.app_state = target_app_state
        await self.emit_state()

    async def set_listen_measurement_ready(self, measurement: MeasurementRaw, raw_protocol: Optional[RawProtocolRecord]) -> None:
        self.save_progress_percent = 0
        self.save_progress_label = ""
        self.current_measurement = measurement
        self.current_raw_protocol = raw_protocol
        self._remember_measurement_mode(raw_protocol)
        self.listen_state = "unsaved"
        self.listen_message = "Messdaten empfangen – bitte Gerätedaten ergänzen und speichern."
        self.listen_error_message = None
        self.app_state = "MEASUREMENT_RECEIVED_NEEDS_METADATA"
        self.is_loading = False
        self.is_sequence_running = False
        self.cancel_sequence_requested = False
        await self.emit_state()
        await self.event_hub.broadcast({"type": "listen_measurement_received"})

    async def request_sequence_cancel(self) -> None:
        if self.is_sequence_running:
            self.cancel_sequence_requested = True
            await self.emit_state()

    async def discard_current_measurement(self) -> None:
        self.save_progress_percent = 0
        self.save_progress_label = ""
        self.current_measurement = None
        self.current_raw_protocol = None
        self.last_sequence_message = "Ungespeicherte Messung verworfen."
        self.error_message = None
        self.app_state = "LISTEN_WAITING" if self.listen_mode_enabled else "READY_FOR_MEASUREMENT"
        self.listen_state = "waiting" if self.listen_mode_enabled else self.listen_state
        if self.listen_mode_enabled:
            self.listen_message = (
                "Lauschmodus aktiv – warte direkt am SECUTEST auf PRX$28 …"
                if self.connection_topology == "direct_secutest"
                else "Lauschmodus aktiv – warte auf PSI-Messdaten …"
            )
        self.is_loading = False
        self.is_sequence_running = False
        self.cancel_sequence_requested = False
        await self.emit_state()

    async def set_save_progress(self, percent: int, label: str) -> None:
        self.save_progress_percent = max(0, min(100, int(percent)))
        self.save_progress_label = str(label or "")
        await self.emit_state()

    async def mark_saved(self, cleanup_ok: bool = True) -> None:
        self.save_progress_percent = 100
        self.save_progress_label = "Gespeichert" if cleanup_ok else "Gespeichert · Warnung"
        self.app_state = "SAVED"
        self.is_loading = False
        await self.emit_state()
        await asyncio.sleep(1.0)
        self.current_measurement = None
        self.current_raw_protocol = None
        self.active_measurement_button = None
        if self.listen_mode_enabled:
            self.listen_state = "waiting"
            self.listen_message = (
                "Speichern abgeschlossen – vorgemerkte SECUTEST-Daten werden jetzt abgerufen …"
                if self.connection_topology == "direct_secutest" and self.direct_prx_pending_count > 0
                else (
                    "Speichern abgeschlossen – warte auf nächstes PRX$28 …"
                    if self.connection_topology == "direct_secutest"
                    else "Speichern abgeschlossen – warte auf nächste PSI-Messung …"
                )
            )
            self.listen_error_message = None
            self.app_state = "LISTEN_WAITING"
        else:
            self.app_state = "READY_FOR_MEASUREMENT"
        self.save_progress_percent = 0
        self.save_progress_label = ""
        await self.emit_state()

    async def update_device_status(self, status: str) -> None:
        self.current_device_status = status
        await self.emit_state()

    async def emit_state(self) -> None:
        await self.event_hub.broadcast({"type": "state", "state": self.snapshot()})

    def snapshot(self) -> dict[str, Any]:
        draft = self.database.get_draft()
        settings = self.database.get_settings()
        active_project = self.database.get_active_project()
        projects = self.database.get_projects()
        active_project_id = active_project.id if active_project else None
        return {
            "connection_status": self.connection_status,
            "connection_detail": self.connection_detail,
            "connection_topology": self.connection_topology,
            "connection_identity": self.connection_identity,
            "app_state": self.app_state,
            "is_loading": self.is_loading,
            "is_sequence_running": self.is_sequence_running,
            "cancel_sequence_requested": self.cancel_sequence_requested,
            "listen_mode_enabled": self.listen_mode_enabled,
            "listen_state": self.listen_state,
            "listen_message": self.listen_message,
            "listen_poll_interval_ms": self.listen_poll_interval_ms,
            "listen_last_protocol_count": self.listen_last_protocol_count,
            "direct_prx_pending_count": self.direct_prx_pending_count,
            "listen_error_message": self.listen_error_message,
            "active_measurement_button": self.active_measurement_button,
            "last_measurement_button": self.last_measurement_button,
            "current_measurement": self.current_measurement.to_dict() if self.current_measurement else None,
            "current_raw_protocol": self.current_raw_protocol.to_dict() if self.current_raw_protocol else None,
            "current_device_status": self.current_device_status,
            "last_sequence_message": self.last_sequence_message,
            "last_sequence_result": self.last_sequence_result.to_dict() if self.last_sequence_result else None,
            "error_message": self.error_message,
            "save_progress_percent": self.save_progress_percent,
            "save_progress_label": self.save_progress_label,
            "logs": list(self.logs),
            "comm_log": list(self.comm_log),
            "draft": draft.to_dict(),
            "settings": settings,
            "records_count": len(self.database.get_records("chronological_desc", project_id=active_project_id)),
            "measurement_rate": self.measurement_rate_snapshot(),
            "active_project": active_project.to_dict() if active_project else None,
            "projects": [project.to_dict() for project in projects],
            "custom_buttons": self.database.get_custom_buttons(),
        }
