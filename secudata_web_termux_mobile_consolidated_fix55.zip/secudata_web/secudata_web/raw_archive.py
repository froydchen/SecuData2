from __future__ import annotations

import csv
import hashlib
import io
import json
from datetime import datetime
from pathlib import Path
from typing import Optional

from .models import Project, RawProtocolRecord
from .excel_io import safe_project_filename

RAW_CSV_HEADER = [
    "received_at",
    "project_id",
    "project_name",
    "source",
    "protocol_number",
    "protocol_date",
    "protocol_time",
    "sha256_raw_frame",
    "raw_frame_hex",
    "raw_frame_text",
    "raw_payload_without_outer_checksum",
    "raw_record_used_for_import",
    "raw_fields_json",
    "pcdocw_ps_pairs",
]


def raw_archive_path(data_dir: Path, project: Optional[Project]) -> Path:
    base = safe_project_filename(project, fallback="rohdaten")
    return data_dir / "raw" / f"{base}_rohdaten.csv"


def raw_archive_bytes(data_dir: Path, project: Optional[Project]) -> bytes:
    path = raw_archive_path(data_dir, project)
    if path.exists():
        return path.read_bytes()
    output = io.StringIO(newline="")
    writer = csv.writer(output, delimiter=";", quoting=csv.QUOTE_ALL, lineterminator="\r\n")
    writer.writerow(RAW_CSV_HEADER)
    return output.getvalue().encode("utf-8-sig")


def append_raw_protocol(data_dir: Path, project: Optional[Project], protocol: RawProtocolRecord) -> Path:
    path = raw_archive_path(data_dir, project)
    path.parent.mkdir(parents=True, exist_ok=True)
    is_new = not path.exists() or path.stat().st_size == 0

    raw_frame_text = protocol.raw_frame or protocol.raw_record or ""
    raw_frame_bytes = bytes.fromhex(protocol.raw_frame_hex) if protocol.raw_frame_hex else raw_frame_text.encode("cp437", errors="replace")
    sha = protocol.raw_sha256 or hashlib.sha256(raw_frame_bytes).hexdigest()

    row = [
        protocol.received_at or datetime.now().isoformat(timespec="seconds"),
        project.id if project else "",
        project.name if project else "",
        protocol.source,
        protocol.protocol_number or "",
        protocol.protocol_date or "",
        protocol.protocol_time or "",
        sha,
        raw_frame_bytes.hex().upper(),
        raw_frame_text,
        protocol.raw_payload or "",
        protocol.raw_record or "",
        json.dumps(protocol.raw_fields or [], ensure_ascii=False),
        _pcdocw_ps_pairs(protocol.raw_fields or []),
    ]

    with path.open("a", encoding="utf-8-sig" if is_new else "utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter=";", quoting=csv.QUOTE_ALL, lineterminator="\r\n")
        if is_new:
            writer.writerow(RAW_CSV_HEADER)
        writer.writerow(row)
    return path


def _pcdocw_ps_pairs(fields: list[str]) -> str:
    """Return a compact .ps-like mapping line for diagnostics.

    The original .ps file uses NUL-separated ``number,value`` pairs.  We keep the
    same shape inside one CSV cell so the exact PSI fields remain visible while
    the CSV file itself stays a normal CSV.
    """
    if not fields:
        return ""
    mapping: list[tuple[int, str]] = []
    for index, value in enumerate(fields):
        if value is None or str(value) == "":
            continue
        # PSI field index -> .ps diagnostic key; this mirrors the observed .ps
        # shape where values are exported with one-based/PCDOCW-style numbers.
        mapping.append((index + 1, str(value)))
    return "\x00".join(f"{key},{value}" for key, value in mapping)
