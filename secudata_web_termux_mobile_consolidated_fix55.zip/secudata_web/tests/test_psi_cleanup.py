import unittest
from types import SimpleNamespace

from secudata_web.acquisition import SecutestAcquisitionService
from secudata_web.client import SecutestLiveConnection


class FakeClient:
    def __init__(self, esr_counts):
        self.esr_counts = list(esr_counts)
        self.commands = []

    async def send_command(self, command, **_kwargs):
        self.commands.append(command)
        if command == "ESR0?":
            if not self.esr_counts:
                raise RuntimeError("Keine ESR-Testantwort mehr")
            count = self.esr_counts.pop(0)
            return SimpleNamespace(payload_without_checksum=f"ESR0=;001%;{count:04d}")
        if command == "MEM0!":
            return SimpleNamespace(payload_without_checksum="Y0")
        raise AssertionError(f"Unerwarteter Befehl: {command}")


class FakeDatabase:
    def __init__(self, settings):
        self.settings = dict(settings)

    def get_settings(self):
        return dict(self.settings)


class ConfigurableFakeClient(FakeClient):
    def __init__(self, esr_counts, settings):
        super().__init__(esr_counts)
        self.database = FakeDatabase(settings)

    async def send_command(self, command, **_kwargs):
        self.commands.append(command)
        if command in {"ESR?", "ESR0?"}:
            if not self.esr_counts:
                raise RuntimeError("Keine ESR-Testantwort mehr")
            count = self.esr_counts.pop(0)
            prefix = "ESR0" if command == "ESR0?" else "ESR"
            return SimpleNamespace(payload_without_checksum=f"{prefix}=;001%;{count:04d}")
        if command in {"MEM!", "MEM0!", "RST!3", "RST1!3", "RST!4", "RST1!4"}:
            return SimpleNamespace(payload_without_checksum="Y")
        raise AssertionError(f"Unerwarteter Befehl: {command}")


class PsiCleanupTests(unittest.IsolatedAsyncioTestCase):
    async def test_save_always_sends_mem_even_when_esr_is_already_zero(self):
        client = FakeClient([0, 0])
        service = SecutestAcquisitionService(client)

        result = await service.clear_psi_memory_verified(
            force=True,
            settle_delay_s=0,
        )

        self.assertEqual(client.commands, ["ESR0?", "MEM0!", "ESR0?"])
        self.assertTrue(result["clear_sent"])
        self.assertTrue(result["verified_empty"])

    async def test_discard_skips_mem_when_psi_is_empty(self):
        client = FakeClient([0])
        service = SecutestAcquisitionService(client)

        result = await service.clear_psi_memory_verified(
            force=False,
            settle_delay_s=0,
        )

        self.assertEqual(client.commands, ["ESR0?"])
        self.assertFalse(result["clear_sent"])
        self.assertTrue(result["verified_empty"])

    async def test_discard_clears_and_verifies_existing_psi_record(self):
        client = FakeClient([1, 1, 0])
        service = SecutestAcquisitionService(client)

        result = await service.clear_psi_memory_verified(
            force=False,
            settle_delay_s=0,
        )

        self.assertEqual(client.commands, ["ESR0?", "MEM0!", "ESR0?", "ESR0?"])
        self.assertEqual(result["before_count"], 1)
        self.assertEqual(result["after_count"], 0)
        self.assertTrue(result["verified_empty"])

    def test_addressed_mem_is_classified_as_ack_command(self):
        client = SecutestLiveConnection.__new__(SecutestLiveConnection)
        self.assertTrue(client._is_ack_command("MEM0!"))
        self.assertTrue(client._is_ack_command("MEM!"))
        self.assertTrue(client._is_ack_command("RST1!3"))
        self.assertTrue(client._is_ack_command("RST!3"))
        self.assertFalse(client._is_ack_command("ESR0?"))
        self.assertFalse(client._is_ack_command("ESR?"))

    async def test_cleanup_uses_unaddressed_commands_when_addressing_is_disabled(self):
        client = ConfigurableFakeClient([1, 0], {
            "device_addressing_enabled": "0",
            "post_reset_settle_ms": "0",
        })
        service = SecutestAcquisitionService(client)
        result = await service.clear_psi_memory_verified(force=False, settle_delay_s=0)
        self.assertEqual(client.commands, ["ESR?", "MEM!", "ESR?"])
        self.assertTrue(result["verified_empty"])

    async def test_mode_reset_skips_idn_handshake_when_addressing_is_disabled(self):
        client = ConfigurableFakeClient([], {
            "device_addressing_enabled": "0",
            "post_reset_settle_ms": "0",
        })
        service = SecutestAcquisitionService(client)
        result = await service.reset_mode_and_initialize(4, 1)
        self.assertEqual(client.commands, ["RST!4"])
        self.assertEqual(result["addressing_enabled"], "0")
        self.assertEqual(result["reset_command"], "RST!4")


if __name__ == "__main__":
    unittest.main()
