from pathlib import Path
import sqlite3
from tempfile import TemporaryDirectory
import unittest

from secudata_web.database import Database


class MeasurementRateTests(unittest.TestCase):
    def test_rate_counts_only_saved_events_inside_window(self):
        with TemporaryDirectory() as tmp:
            db = Database(Path(tmp) / "rate.db")
            db.record_measurement_saved(saved_at=1000)
            db.record_measurement_saved(saved_at=2500)
            db.record_measurement_saved(saved_at=3500)

            result = db.get_measurement_rate(window_minutes=30, now=4000)

            self.assertEqual(result["count"], 2)
            self.assertEqual(result["rate_per_hour"], 4.0)
            self.assertEqual(result["last_saved_at"], 3500.0)

    def test_fix39_migration_removes_old_receive_based_events_once(self):
        with TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "rate.db"
            conn = sqlite3.connect(db_path)
            conn.executescript(
                """
                CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE measurement_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    received_at REAL NOT NULL
                );
                INSERT INTO measurement_events(received_at) VALUES (1000), (2000);
                """
            )
            conn.commit()
            conn.close()

            db = Database(db_path)
            self.assertEqual(db.get_measurement_rate(window_minutes=240, now=3000)["count"], 0)

            db.record_measurement_saved(saved_at=2500)
            self.assertEqual(db.get_measurement_rate(window_minutes=240, now=3000)["count"], 1)
            db._conn.close()

            reopened = Database(db_path)
            self.assertEqual(reopened.get_measurement_rate(window_minutes=240, now=3000)["count"], 1)


if __name__ == "__main__":
    unittest.main()
