import unittest

from secudata_web.models import MeasurementRaw, RawProtocolRecord
from secudata_web.state import AppState, EventHub


def raw_protocol(marker: str) -> RawProtocolRecord:
    return RawProtocolRecord(
        source="PSI",
        raw_record=f"TEST;{marker};",
        protocol_number=None,
        protocol_date=None,
        protocol_time=None,
        parsed_measurement=None,
        parsed_metadata=None,
        raw_fields=["TEST", marker],
    )


class StateMeasurementModeTests(unittest.TestCase):
    def test_actual_line_measurement_bitfield_overrides_previous_button(self):
        state = AppState(None, EventHub())
        state.last_measurement_button = "SK_I_II"
        state._remember_measurement_mode(raw_protocol("0721200000000000"))
        self.assertEqual(state.active_measurement_button, "LEITUNGEN")
        self.assertEqual(state.last_measurement_button, "LEITUNGEN")

    def test_actual_sk_measurement_bitfield_is_remembered(self):
        state = AppState(None, EventHub())
        state.last_measurement_button = "LEITUNGEN"
        state._remember_measurement_mode(raw_protocol("0701200000000000"))
        self.assertEqual(state.active_measurement_button, "SK_I_II")
        self.assertEqual(state.last_measurement_button, "SK_I_II")


if __name__ == "__main__":
    unittest.main()
