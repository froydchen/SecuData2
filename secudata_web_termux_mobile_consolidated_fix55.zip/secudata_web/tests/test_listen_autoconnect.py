import json
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from starlette.exceptions import HTTPException

import secudata_web.app as app_module
from secudata_web.client import SecutestClientError


class FakeRequest:
    def __init__(self, payload):
        self.payload = payload

    async def json(self):
        return self.payload


class ListenAutoConnectTests(unittest.IsolatedAsyncioTestCase):
    async def test_enabling_listen_connects_before_starting_polling(self):
        fake_client = MagicMock()
        fake_client.connected = False
        fake_client.connect = AsyncMock()

        fake_state = MagicMock()
        fake_state.is_sequence_running = False
        fake_state.current_measurement = None
        fake_state.append_log = AsyncMock()
        fake_state.set_listen_mode = AsyncMock()
        fake_state.snapshot.return_value = {"connection_status": "CONNECTED"}

        connect_and_detect = AsyncMock(return_value={"topology": "psi", "identity": "SECUTEST PSI"})
        with (
            patch.object(app_module, "client", fake_client),
            patch.object(app_module, "state", fake_state),
            patch.object(app_module, "_active_project_or_409", return_value=object()),
            patch.object(app_module, "_connect_and_detect_topology", connect_and_detect),
            patch.object(app_module, "_ensure_listen_task_running") as ensure_task,
        ):
            response = await app_module.set_listen_mode(FakeRequest({"enabled": True}))

        payload = json.loads(response.body)
        connect_and_detect.assert_awaited_once()
        fake_state.set_listen_mode.assert_awaited_once()
        ensure_task.assert_called_once()
        self.assertTrue(payload["listen_mode_enabled"])
        self.assertTrue(payload["connection_auto_opened"])

    async def test_failed_connection_does_not_enable_listen_mode(self):
        fake_client = MagicMock()
        fake_client.connected = False
        fake_client.connect = AsyncMock(side_effect=SecutestClientError("offline"))

        fake_state = MagicMock()
        fake_state.is_sequence_running = False
        fake_state.current_measurement = None
        fake_state.append_log = AsyncMock()
        fake_state.set_listen_mode = AsyncMock()

        connect_and_detect = AsyncMock(side_effect=SecutestClientError("offline"))
        with (
            patch.object(app_module, "client", fake_client),
            patch.object(app_module, "state", fake_state),
            patch.object(app_module, "_active_project_or_409", return_value=object()),
            patch.object(app_module, "_connect_and_detect_topology", connect_and_detect),
            patch.object(app_module, "_ensure_listen_task_running") as ensure_task,
        ):
            with self.assertRaises(HTTPException) as caught:
                await app_module.set_listen_mode(FakeRequest({"enabled": True}))

        self.assertEqual(caught.exception.status_code, 502)
        connect_and_detect.assert_awaited_once()
        fake_state.set_listen_mode.assert_not_awaited()
        ensure_task.assert_not_called()

    def test_psi_commands_remain_allowed_in_listen_mode(self):
        for command in ("ESR?", "ESR0?", "WER?", "MEM!", "MEM0!"):
            self.assertTrue(app_module._is_psi_listen_safe_command(command))
        self.assertFalse(app_module._is_psi_listen_safe_command("RST!3"))


if __name__ == "__main__":
    unittest.main()
