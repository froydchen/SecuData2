from io import BytesIO

from openpyxl import load_workbook

from secudata_web.excel_io import export_records_to_bytes
from secudata_web.models import FinalRecord, MeasurementMetadata, MeasurementRaw, Project


def _record(bitfield: str) -> FinalRecord:
    return FinalRecord(
        id=1,
        project_sequence=1,
        created_at="2026-07-17T10:00:00",
        measurement=MeasurementRaw(
            rpe=0.077,
            rins=310.0,
            ipe=0.17,
            u=230.0,
            timestamp="2026-07-17T10:00:00",
            is_ok=True,
            values=[],
        ),
        metadata=MeasurementMetadata(id="ID4711", geraeteart="Monitor", hersteller="Sony", raum_etage="R1"),
        project_id=1,
        raw_fields=["XXXXXXXX", bitfield, "0.077", "<0.400", ">310.0", ">0.500", "0539", ">0500", "00.17", ">0000"],
        raw_source="TEST",
    )


def _project() -> Project:
    return Project(
        id=1,
        name="Klinik_07.2026",
        customer="Klinik Test",
        cycle_month="2026-07",
        created_at="2026-07-17T10:00:00",
        updated_at="2026-07-17T10:00:00",
        street="Musterstraße 1",
        postal_code="12345",
        city="Musterstadt",
        test_interval_months="24",
        inspector="M. Prüfer",
    )


def test_export_uses_bitfield_for_result_visual_and_project_master_columns():
    wb = load_workbook(BytesIO(export_records_to_bytes([_record("0701208005060000")], project=_project())), data_only=False)
    ws = wb["Prüfdaten"]
    assert ws["C7"].value == "0701208005060000"
    assert ws["D7"].value == "Klinik Test"
    assert ws["L7"].value == "NICHT OK"
    assert ws["M7"].value == "I"
    assert ws["Q7"].value == "NICHT OK"
    assert ws["S7"].value == "NICHT OK"
    assert ws["W7"].value == "NICHT OK"
    assert ws["BY7"].value == "M. Prüfer"
    assert ws["CJ7"].value == "24"
    assert ws["CL7"].value == "Musterstraße 1"
    assert ws["CM7"].value == "12345"
    assert ws["CN7"].value == "Musterstadt"


def test_export_sets_sichtpruefung_sl_to_dash_for_non_sk1():
    wb = load_workbook(BytesIO(export_records_to_bytes([_record("0600200000000000")], project=_project())), data_only=False)
    ws = wb["Prüfdaten"]
    assert ws["L7"].value == "OK"
    assert ws["M7"].value == "II"
    assert ws["Q7"].value == "-"
    assert ws["W7"].value == "OK"


def test_export_always_uses_receive_time_and_visual_ok_columns():
    record = _record("0701200000000000")
    record.created_at = "2026-07-22T02:00:00"
    record.measurement.timestamp = "2026-07-22T01:23:45"
    # Simulate the wrong PSI clock still being present elsewhere in the raw tail.
    record.raw_fields.extend(["01.01.07", "12:00", "Monitor", "Sony", "151", "ID4711"])

    wb = load_workbook(BytesIO(export_records_to_bytes([record], project=_project())), data_only=False)
    ws = wb["Prüfdaten"]
    assert ws["J7"].value == "22.07.26"
    assert ws["K7"].value.strftime("%H:%M:%S") == "01:23:45"
    assert ws["Q7"].value == "OK"
    assert ws["R7"].value == "OK"
    assert ws["S7"].value == "OK"
    assert ws["T7"].value == "OK"
    assert ws["U7"].value == "OK"
    assert ws["V7"].value == "OK"
    assert ws["W7"].value == "OK"
