import unittest

from secudata_web.protocol import parse_direct_prx_blocks


class DirectPrxParserTests(unittest.TestCase):
    def test_captured_x_y_z_are_mapped_without_wer_parser(self):
        x = "Protokollx=XXXXXXXX;000021000000510000000C000000060000220000;;;15.08.26;12:47:31"
        y = "Protokollx=XXXXXXXX;;;;;>+310.0MΩ;>2.000MΩ; +0527V ;+0500V ;;;;;;; +0.000mA;<0.500mA;;;;;;;;"
        z = "Protokollx=XXXXXXXX;;;;;;;;;;;;;;;;;;;; +197.2V ;+253.0V ;;"

        protocol = parse_direct_prx_blocks(x, y, z)
        measurement = protocol.parsed_measurement

        self.assertEqual(protocol.source, "SECUTEST_DIRECT_PRX")
        self.assertIsNotNone(measurement)
        self.assertIsNone(measurement.rpe)
        self.assertAlmostEqual(measurement.rins, 310.0)
        self.assertAlmostEqual(measurement.ipe, 0.0)
        self.assertAlmostEqual(measurement.u, 197.2)
        self.assertTrue(measurement.is_ok)
        self.assertEqual(protocol.raw_fields[0], "XXXXXXXX")
        self.assertEqual(protocol.raw_fields[10].strip(), ">+310.0MΩ")
        self.assertEqual(protocol.raw_fields[12].strip(), "+0527V")
        self.assertEqual(protocol.raw_fields[20].strip(), "+0.000mA")
        labels = [item["label"] for item in measurement.values]
        self.assertIn("MW R-ISO", labels)
        self.assertIn("MW U-ISO", labels)
        self.assertIn("MW EGA", labels)
        self.assertIn("MW U-LN", labels)


if __name__ == "__main__":
    unittest.main()

class DirectTopologyTests(unittest.IsolatedAsyncioTestCase):
    async def test_detects_psi_identity(self):
        from unittest.mock import AsyncMock, MagicMock
        from secudata_web.acquisition import SecutestAcquisitionService

        client = MagicMock()
        frame = MagicMock()
        frame.payload_without_checksum = "IDN0=0;GMN;SECUTEST PSI;GTM5016000R0001;17 08 26 23 00 00"
        client.send_command = AsyncMock(return_value=frame)
        info = await SecutestAcquisitionService(client).detect_connection_topology()
        self.assertEqual(info["topology"], "psi")

    async def test_detects_direct_secutest_identity(self):
        from unittest.mock import AsyncMock, MagicMock
        from secudata_web.acquisition import SecutestAcquisitionService

        client = MagicMock()
        frame = MagicMock()
        frame.payload_without_checksum = "IDN1=1;GMN;SecuTest S;GTM5015000R0001;17 Aug 2026 230000"
        client.send_command = AsyncMock(return_value=frame)
        info = await SecutestAcquisitionService(client).detect_connection_topology()
        self.assertEqual(info["topology"], "direct_secutest")

class DirectPrxHandshakeTests(unittest.IsolatedAsyncioTestCase):
    async def test_literal_prx28_is_accepted_even_though_public_checksum_is_invalid(self):
        from unittest.mock import AsyncMock, MagicMock
        from secudata_web.client import SecutestLiveConnection
        from secudata_web.protocol import parse_incoming_frame

        database = MagicMock()
        database.get_settings.return_value = {"command_timeout_ms": "2500"}
        state = MagicMock()
        state.append_log = AsyncMock()
        state.append_comm_log = AsyncMock()
        client = SecutestLiveConnection(database, state)
        client.connected = True
        client.reader = MagicMock()
        writer = MagicMock()
        writer.write = MagicMock()
        writer.drain = AsyncMock()
        client.writer = writer

        empty = parse_incoming_frame(b"$24")
        ready = parse_incoming_frame(b"PRX$28")
        self.assertFalse(ready.is_checksum_valid)  # special literal, not public $CS framing
        await client.incoming.put(empty)
        await client.incoming.put(ready)

        frame = await client.wait_for_unsolicited_payload("PRX$28", timeout_ms=100)
        self.assertIsNotNone(frame)
        self.assertEqual(frame.normalized, "PRX$28")
        writer.write.assert_called_with(b"\x11")

    async def test_direct_fetch_does_not_send_tas_inside_prx_transaction(self):
        from unittest.mock import AsyncMock, MagicMock, call
        from secudata_web.acquisition import SecutestAcquisitionService

        client = MagicMock()
        x = MagicMock(raw="Protokollx=XXXXXXXX;000021000000510000000C000000060000220000;;;15.08.26;12:47:31$64", raw_bytes=None,
                      payload_without_checksum="Protokollx=XXXXXXXX;000021000000510000000C000000060000220000;;;15.08.26;12:47:31")
        y = MagicMock(raw="Protokollx=XXXXXXXX;;;;;>+310.0MΩ;>2.000MΩ; +0527V ;+0500V ;;;;;;; +0.000mA;<0.500mA;;;;;;;;$97", raw_bytes=None,
                      payload_without_checksum="Protokollx=XXXXXXXX;;;;;>+310.0MΩ;>2.000MΩ; +0527V ;+0500V ;;;;;;; +0.000mA;<0.500mA;;;;;;;;")
        z = MagicMock(raw="Protokollx=XXXXXXXX;;;;;;;;;;;;;;;;;;;; +197.2V ;+253.0V ;;$42", raw_bytes=None,
                      payload_without_checksum="Protokollx=XXXXXXXX;;;;;;;;;;;;;;;;;;;; +197.2V ;+253.0V ;;")
        client.send_raw_cr_command = AsyncMock(side_effect=[x, y, z])
        client.send_command = AsyncMock(return_value=MagicMock(payload_without_checksum=".Yx"))

        protocol = await SecutestAcquisitionService(client).fetch_direct_prx_record(timeout_ms=3500)

        self.assertIsNotNone(protocol.parsed_measurement)
        self.assertAlmostEqual(protocol.parsed_measurement.u, 197.2)
        self.assertEqual(
            client.send_raw_cr_command.await_args_list,
            [
                call("PRX?X", timeout_ms=3500, response_prefix="PROTOKOLL"),
                call("PRX?Y", timeout_ms=3500, response_prefix="PROTOKOLL"),
                call("PRX?Z", timeout_ms=3500, response_prefix="PROTOKOLL"),
            ],
        )
        client.send_command.assert_not_awaited()


class DirectPrxFinalizeTests(unittest.IsolatedAsyncioTestCase):
    async def test_finalize_waits_for_terminal_ready_then_uses_console_tas_path(self):
        from unittest.mock import AsyncMock, MagicMock, call
        from secudata_web.acquisition import SecutestAcquisitionService

        client = MagicMock()
        client.wait_for_terminal_ready = AsyncMock(return_value=True)
        client.send_command = AsyncMock(return_value=MagicMock(payload_without_checksum=".Yx"))
        result = await SecutestAcquisitionService(client).finalize_direct_prx_session(timeout_ms=3000)
        self.assertEqual(result, {"command": "TAS!a", "ack": ".Yx", "terminal_ready": "yes"})
        self.assertEqual(client.wait_for_terminal_ready.await_args_list, [call(timeout_ms=1800)])
        # TAS!a must go through the same framed send_command path as a manual
        # console entry, not the undocumented raw-CR command.
        self.assertEqual(client.send_command.await_args_list, [call("TAS!a", timeout_ms=3000)])
        client.send_raw_cr_ack_command.assert_not_called()

    async def test_finalize_raises_when_terminal_not_ready(self):
        from unittest.mock import AsyncMock, MagicMock
        from secudata_web.acquisition import SecutestAcquisitionService

        client = MagicMock()
        client.wait_for_terminal_ready = AsyncMock(return_value=False)
        client.send_command = AsyncMock()
        with self.assertRaises(RuntimeError):
            await SecutestAcquisitionService(client).finalize_direct_prx_session(timeout_ms=3000)
        client.send_command.assert_not_awaited()


class DirectPrxManualTasTests(unittest.IsolatedAsyncioTestCase):
    async def test_send_tas_a_uses_console_send_command_path(self):
        from unittest.mock import AsyncMock, MagicMock, call
        from secudata_web.acquisition import SecutestAcquisitionService

        client = MagicMock()
        client.send_command = AsyncMock(return_value=MagicMock(payload_without_checksum=".Yx"))
        result = await SecutestAcquisitionService(client).send_tas_a(timeout_ms=3000)
        self.assertEqual(result, {"command": "TAS!a", "ack": ".Yx"})
        self.assertEqual(client.send_command.await_args_list, [call("TAS!a", timeout_ms=3000)])


class DirectResetSwitchDetectionTests(unittest.IsolatedAsyncioTestCase):
    async def test_tas_04_selects_rst4(self):
        from unittest.mock import AsyncMock, MagicMock, call
        from secudata_web.acquisition import SecutestAcquisitionService

        client = MagicMock()
        client.send_command = AsyncMock(side_effect=[
            MagicMock(payload_without_checksum="TASTEx=04;D;;-"),
            MagicMock(payload_without_checksum=".Yx"),
        ])
        result = await SecutestAcquisitionService(client).reset_mode_direct()
        self.assertEqual(result["switch_position"], "04")
        self.assertEqual(result["reset_command"], "RST!4")
        self.assertEqual(client.send_command.await_args_list, [
            call("TAS?", timeout_ms=3000),
            call("RST!4", timeout_ms=10000),
        ])

    async def test_tas_03_selects_rst3(self):
        from unittest.mock import AsyncMock, MagicMock, call
        from secudata_web.acquisition import SecutestAcquisitionService

        client = MagicMock()
        client.send_command = AsyncMock(side_effect=[
            MagicMock(payload_without_checksum="TASTEx=03;D;;-"),
            MagicMock(payload_without_checksum=".Yx"),
        ])
        result = await SecutestAcquisitionService(client).reset_mode_direct()
        self.assertEqual(result["switch_position"], "03")
        self.assertEqual(result["reset_command"], "RST!3")
        self.assertEqual(client.send_command.await_args_list, [
            call("TAS?", timeout_ms=3000),
            call("RST!3", timeout_ms=10000),
        ])
