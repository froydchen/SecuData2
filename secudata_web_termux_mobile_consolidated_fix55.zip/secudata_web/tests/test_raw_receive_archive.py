import csv
from pathlib import Path

from secudata_web.models import MeasurementRaw, RawProtocolRecord
from secudata_web.raw_archive import append_raw_protocol


def test_raw_archive_uses_captured_receive_timestamp_and_corrected_fields(tmp_path: Path):
    protocol = RawProtocolRecord(
        source="TEST",
        raw_record="XXXXXXXX;0701200000000000;22.07.26;01:23:45",
        protocol_number="1",
        protocol_date="22.07.26",
        protocol_time="01:23:45",
        parsed_measurement=MeasurementRaw.now(),
        parsed_metadata=None,
        raw_fields=["XXXXXXXX", "0701200000000000", "22.07.26", "01:23:45"],
        raw_frame="WERTEx=ORIGINAL;01.01.07;12:00$00",
        received_at="2026-07-22T01:23:45",
    )
    path = append_raw_protocol(tmp_path, None, protocol)
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter=";"))

    assert rows[0]["received_at"] == "2026-07-22T01:23:45"
    assert "22.07.26;01:23:45" in rows[0]["raw_record_used_for_import"]
    assert "0701200000000000" in rows[0]["raw_fields_json"]
    assert "01.01.07;12:00" in rows[0]["raw_frame_text"]
