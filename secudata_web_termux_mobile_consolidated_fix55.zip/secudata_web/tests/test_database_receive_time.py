from secudata_web.database import Database
from secudata_web.models import MeasurementMetadata, MeasurementRaw


def test_new_record_created_at_is_receive_time(tmp_path):
    db = Database(tmp_path / "test.db")
    measurement = MeasurementRaw(
        rpe=0.1,
        rins=2.0,
        ipe=0.2,
        u=230.0,
        timestamp="2026-07-22T01:23:45",
        is_ok=True,
    )
    record = db.insert_record(measurement, MeasurementMetadata(id="1"))
    assert record.created_at == "2026-07-22T01:23:45"
    assert record.measurement.timestamp == "2026-07-22T01:23:45"
