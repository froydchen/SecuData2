const app = {
  state: null,
  history: [],
  visibleLogs: [],
  draftSaveTimer: null,
  draftSaveAbortController: null,
  ws: null,
  draftInitialized: false,
  activeCaptureField: 'id',
  captureTarget: 'id',
  suggestionRequestIds: {},
  suggestionAbortControllers: {},
  suggestionCache: { id: ['-'], geraeteart: ['-'], hersteller: ['-'] },
  lastCaptureSuggestions: { id: '', geraeteart: '', hersteller: '' },
  preparedMeasurementKey: null,
  autoScannerStartedForKey: '',
  autoScannerStartingForKey: '',
  autoScannerTimer: null,
  pendingSequenceKind: null,
  longPressTimer: null,
  longPressTriggered: false,
  scanner: { stream: null, rafId: null, detector: null, active: false, busy: false, lastValue: '', stableCount: 0, minReadyAt: 0 },
  listenAudio: { context: null, enabledByGesture: false, customUrl: '', customName: '' },
  projectPromptShown: false,
  mobileSaveDrag: { active: false, armed: false, startY: 0, pointerId: null, progress: 0, holdTimer: null, suppressClick: false },
  mobilePsiDrag: { active: false, armed: false, startY: 0, pointerId: null, progress: 0, holdTimer: null, suppressClick: false, busy: false },
  mobileTasABusy: false,
  captureUiInactive: false,
  roomTimerResetAt: Date.now(),
  roomReminderTimer: null,
  roomReminderShownForCycle: false,
  roomReminderManualOpen: false,
  measurementRateTimer: null,
  captureViewportLocked: false,
  captureViewportPositionTimer: null,
  captureViewportTargetY: null,
};


const captureFields = ['id', 'geraeteart', 'hersteller'];
const captureFieldLabels = {
  id: 'ID',
  geraeteart: 'Geräteart',
  hersteller: 'Hersteller',
};

const draftFields = [
  'id',
  'geraeteart',
  'hersteller',
  'raum_etage',
  'kunde',
];

function el(id) {
  return document.getElementById(id);
}

async function fetchJson(url, options = {}) {
  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    ...options,
  });
  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await response.json() : await response.text();
  if (!response.ok) {
    const detail = typeof data === 'object' && data?.detail ? data.detail : String(data);
    throw new Error(detail || `${response.status} ${response.statusText}`);
  }
  return data;
}

function toast(message) {
  const node = el('toast');
  node.textContent = message;
  node.classList.add('visible');
  window.clearTimeout(node._timer);
  node._timer = window.setTimeout(() => node.classList.remove('visible'), 2800);
}


function loadCustomListenSound() {
  try {
    app.listenAudio.customUrl = window.localStorage.getItem('secutest.listenSoundDataUrl') || '';
    app.listenAudio.customName = window.localStorage.getItem('secutest.listenSoundName') || '';
  } catch (_error) {
    app.listenAudio.customUrl = '';
    app.listenAudio.customName = '';
  }
}

function renderCustomListenSoundInfo() {
  const node = el('setting-listen-sound-name');
  if (!node) return;
  node.textContent = app.listenAudio.customUrl
    ? `Eigener Ton: ${app.listenAudio.customName || 'Audio-Datei'}`
    : 'Standardton aktiv';
}

function clearCustomListenSound() {
  try {
    window.localStorage.removeItem('secutest.listenSoundDataUrl');
    window.localStorage.removeItem('secutest.listenSoundName');
  } catch (_error) {}
  app.listenAudio.customUrl = '';
  app.listenAudio.customName = '';
  const fileInput = el('setting-listen-sound-file');
  if (fileInput) fileInput.value = '';
  renderCustomListenSoundInfo();
  toast('Standard-Empfangston aktiv.');
}

async function saveCustomListenSoundFromInput() {
  const input = el('setting-listen-sound-file');
  const file = input?.files?.[0];
  if (!file) return;
  if (!file.type.startsWith('audio/')) {
    toast('Ton nicht übernommen: Bitte eine Audio-Datei wählen.');
    input.value = '';
    return;
  }
  if (file.size > 1_500_000) {
    toast('Ton nicht übernommen: Datei bitte kleiner als 1,5 MB halten. Sonst wird localStorage zum Drama.');
    input.value = '';
    return;
  }
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Audio-Datei konnte nicht gelesen werden.'));
    reader.readAsDataURL(file);
  });
  try {
    window.localStorage.setItem('secutest.listenSoundDataUrl', dataUrl);
    window.localStorage.setItem('secutest.listenSoundName', file.name || 'Audio-Datei');
    app.listenAudio.customUrl = dataUrl;
    app.listenAudio.customName = file.name || 'Audio-Datei';
    renderCustomListenSoundInfo();
  } catch (_error) {
    toast('Ton nicht gespeichert: Browser-Speicher voll oder blockiert.');
  }
}

function playCustomListenSound() {
  if (!app.listenAudio.customUrl) return false;
  try {
    const audio = new Audio(app.listenAudio.customUrl);
    audio.volume = 1;
    audio.play().catch(() => playStandardListenBeep());
    return true;
  } catch (_error) {
    return false;
  }
}

function ensureListenAudioReady() {
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return null;
    if (!app.listenAudio.context) {
      app.listenAudio.context = new AudioContextClass();
    }
    if (app.listenAudio.context.state === 'suspended') {
      app.listenAudio.context.resume().catch(() => {});
    }
    app.listenAudio.enabledByGesture = true;
    return app.listenAudio.context;
  } catch (_error) {
    return null;
  }
}

function playStandardListenBeep() {
  const ctx = ensureListenAudioReady();
  if (!ctx) return;
  try {
    const now = ctx.currentTime;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.18, now + 0.018);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.24);
    gain.connect(ctx.destination);

    const first = ctx.createOscillator();
    first.type = 'sine';
    first.frequency.setValueAtTime(1040, now);
    first.connect(gain);
    first.start(now);
    first.stop(now + 0.13);

    const second = ctx.createOscillator();
    second.type = 'sine';
    second.frequency.setValueAtTime(1320, now + 0.10);
    second.connect(gain);
    second.start(now + 0.10);
    second.stop(now + 0.24);
  } catch (_error) {}
}

function playListenBeep() {
  if (!playCustomListenSound()) {
    playStandardListenBeep();
  }
}

function playListenWarningBeep() {
  const ctx = ensureListenAudioReady();
  if (!ctx) return;
  try {
    const now = ctx.currentTime;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.22, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.62);
    gain.connect(ctx.destination);
    [0, 0.20, 0.40].forEach((offset) => {
      const osc = ctx.createOscillator();
      osc.type = 'square';
      osc.frequency.setValueAtTime(720, now + offset);
      osc.connect(gain);
      osc.start(now + offset);
      osc.stop(now + offset + 0.11);
    });
  } catch (_error) {}
}

function playSaveSolvedJingle() {
  const ctx = ensureListenAudioReady();
  if (!ctx) return;
  try {
    const now = ctx.currentTime;
    const master = ctx.createGain();
    master.gain.setValueAtTime(0.0001, now);
    master.gain.exponentialRampToValueAtTime(0.16, now + 0.018);
    master.gain.exponentialRampToValueAtTime(0.0001, now + 0.72);
    master.connect(ctx.destination);
    [659.25, 783.99, 987.77].forEach((frequency, index) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const start = now + index * 0.115;
      osc.type = index === 2 ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(frequency, start);
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(index === 2 ? 0.52 : 0.34, start + 0.018);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + (index === 2 ? 0.42 : 0.22));
      osc.connect(gain);
      gain.connect(master);
      osc.start(start);
      osc.stop(start + (index === 2 ? 0.44 : 0.24));
    });
  } catch (_error) {}
}


function isMobileViewport() {
  return window.matchMedia?.('(max-width: 820px)').matches;
}

function configuredCaptureScrollY(settings = app.state?.settings) {
  const parsed = Number(settings?.capture_scroll_position_px ?? 500);
  if (!Number.isFinite(parsed)) return 500;
  return Math.max(0, Math.min(5000, Math.round(parsed)));
}

function positionMobileCaptureViewport({ force = false } = {}) {
  if (!isMobileViewport()) return;
  if (!force && !app.captureViewportLocked) return;
  if (el('barcodeScannerDialog')?.open) return;

  const targetY = configuredCaptureScrollY();
  app.captureViewportTargetY = targetY;
  try {
    window.scrollTo({ top: targetY, left: 0, behavior: 'auto' });
  } catch (_error) {
    window.scrollTo(0, targetY);
  }
}

function lockMobileCaptureViewport({ position = false, forcePosition = false } = {}) {
  if (!isMobileViewport()) return;
  const wasLocked = app.captureViewportLocked;
  app.captureViewportLocked = true;
  app.captureViewportTargetY = configuredCaptureScrollY();
  document.body.classList.add('capture-input-locked');
  document.documentElement.classList.add('capture-input-locked');

  // Initial alignment only. Afterwards the user may scroll manually; field
  // changes and keyboard viewport events must not force the page back again.
  if (position || forcePosition || !wasLocked) {
    positionMobileCaptureViewport({ force: true });
    window.clearTimeout(app.captureViewportPositionTimer);
    app.captureViewportPositionTimer = window.setTimeout(() => {
      if (app.captureViewportLocked && !el('barcodeScannerDialog')?.open) {
        positionMobileCaptureViewport({ force: true });
      }
      app.captureViewportPositionTimer = null;
    }, 180);
  }
}

function unlockMobileCaptureViewport() {
  app.captureViewportLocked = false;
  app.captureViewportTargetY = null;
  window.clearTimeout(app.captureViewportPositionTimer);
  app.captureViewportPositionTimer = null;
  document.body.classList.remove('capture-input-locked');
  document.documentElement.classList.remove('capture-input-locked');
}

function focusMobileInputStable() {
  const input = el('mobileFieldInput');
  if (!input) return;
  lockMobileCaptureViewport({ position: false });
  if (document.activeElement !== input) {
    try {
      input.focus({ preventScroll: true });
    } catch (_error) {
      input.focus();
    }
  }
}

function activateTab(tabName) {
  document.querySelectorAll('.tab').forEach((tab) => {
    tab.classList.toggle('active', tab.dataset.tab === tabName);
  });
  document.querySelectorAll('.tab-panel').forEach((panel) => {
    panel.classList.toggle('active', panel.id === `tab-${tabName}`);
  });
}

function readDraftFromInputs() {
  const payload = {};
  draftFields.forEach((field) => {
    payload[field] = el(`field-${field}`)?.value ?? '';
  });
  return payload;
}

function applyDraftToInputs(draft = {}) {
  draftFields.forEach((field) => {
    const node = el(`field-${field}`);
    if (!node) return;
    node.value = draft[field] ?? '';
  });
}

function applyServerDraft(draft = {}) {
  applyDraftToInputs(draft);
  updateMobileContext();
  updateMobileCaptureDisplay({ syncInput: true });
  refreshSuggestions(app.activeCaptureField);
}

function updateMobileContext() {
  const customer = el('field-kunde')?.value?.trim() || '–';
  const room = el('field-raum_etage')?.value?.trim() || '';
  if (el('mobileContextCustomer')) el('mobileContextCustomer').textContent = customer;
  if (el('mobileContextRoom')) el('mobileContextRoom').textContent = room || '–';
  const roomTab = el('roomContextTab');
  if (roomTab) {
    roomTab.textContent = room || 'Raum';
    roomTab.title = room ? `Raum ändern: ${room}` : 'Raum eingeben';
    roomTab.setAttribute('aria-label', room ? `Raum ${room} ändern` : 'Raum eingeben');
  }
}

function captureFieldValue(field) {
  return el(`field-${field}`)?.value ?? '';
}

function setCaptureFieldValue(field, value) {
  const node = el(`field-${field}`);
  if (!node) return;
  node.value = value ?? '';
  updateMobileContext();
  updateMobileCaptureDisplay({ syncInput: field === app.activeCaptureField });
  scheduleDraftSave();
}

function normalizeSuggestionValue(value) {
  return String(value ?? '').trim();
}

function loadLastCaptureSuggestions() {
  try {
    const parsed = JSON.parse(window.localStorage.getItem('secutest.lastCaptureSuggestions') || '{}');
    captureFields.forEach((field) => {
      const value = normalizeSuggestionValue(parsed[field]);
      if (value && value !== '-') app.lastCaptureSuggestions[field] = value;
    });
  } catch (_error) {}
}

function persistLastCaptureSuggestions() {
  try {
    window.localStorage.setItem('secutest.lastCaptureSuggestions', JSON.stringify(app.lastCaptureSuggestions));
  } catch (_error) {}
}

function rememberLastCaptureValues(source = readDraftFromInputs()) {
  let changed = false;
  captureFields.forEach((field) => {
    const value = normalizeSuggestionValue(source?.[field]);
    if (value && value !== '-' && value !== app.lastCaptureSuggestions[field]) {
      app.lastCaptureSuggestions[field] = value;
      changed = true;
    }
  });
  if (changed) persistLastCaptureSuggestions();
}

function clearCaptureFields({ saveDraft = false } = {}) {
  captureFields.forEach((field) => {
    const node = el(`field-${field}`);
    if (node) node.value = '';
  });
  updateMobileContext();
  updateMobileCaptureDisplay({ syncInput: true });
  captureFields.forEach((field) => refreshSuggestions(field, { forceRender: field === app.activeCaptureField }));
  if (saveDraft) scheduleDraftSave();
}

function mergeSuggestionValues(field, values = []) {
  const ordered = ['-'];
  const last = normalizeSuggestionValue(app.lastCaptureSuggestions[field]);
  if (last && last !== '-') ordered.push(last);
  (values || []).forEach((value) => {
    const normalized = normalizeSuggestionValue(value);
    if (!normalized || ordered.includes(normalized)) return;
    ordered.push(normalized);
  });
  return ordered;
}

function measurementStateKey(state) {
  const measurement = state?.current_measurement;
  if (!measurement) return '';
  return [
    measurement.timestamp || '',
    state.current_raw_protocol?.protocol_number || '',
    (state.current_raw_protocol?.raw_record || '').slice(0, 80),
  ].join('|');
}

function prepareNewMeasurementInput(state) {
  if (state?.app_state !== 'MEASUREMENT_RECEIVED_NEEDS_METADATA' || !state.current_measurement) return;
  const key = measurementStateKey(state);
  if (!key || key === app.preparedMeasurementKey) return;
  rememberLastCaptureValues(readDraftFromInputs());
  app.preparedMeasurementKey = key;
  app.autoScannerStartedForKey = '';
  app.autoScannerStartingForKey = '';
  window.clearTimeout(app.autoScannerTimer);
  app.autoScannerTimer = null;
  noteMeasurementActivity();
  app.activeCaptureField = 'id';
  app.captureTarget = 'id';
  clearCaptureFields({ saveDraft: true });
  activateCaptureField('id', { focus: false });
  lockMobileCaptureViewport({ position: true, forcePosition: true });

  const autoScan = state?.settings?.auto_scan_after_measurement === '1';
  if (!autoScan) {
    // Position first, then open the keyboard without allowing Chrome to choose a
    // new scroll position of its own.
    window.requestAnimationFrame(() => window.requestAnimationFrame(focusMobileInputStable));
  }
}

function queueAutoScannerForMeasurement(state = app.state, { delay = 80 } = {}) {
  if (state?.app_state !== 'MEASUREMENT_RECEIVED_NEEDS_METADATA' || !state.current_measurement) return;
  if (state?.settings?.auto_scan_after_measurement !== '1') return;
  const key = measurementStateKey(state);
  if (!key || app.autoScannerStartedForKey === key || app.autoScannerStartingForKey === key) return;
  if (app.scanner.active || el('barcodeScannerDialog')?.open) {
    app.autoScannerStartedForKey = key;
    return;
  }

  window.clearTimeout(app.autoScannerTimer);
  app.autoScannerTimer = window.setTimeout(async () => {
    const currentState = app.state;
    if (
      currentState?.app_state !== 'MEASUREMENT_RECEIVED_NEEDS_METADATA'
      || measurementStateKey(currentState) !== key
      || currentState?.settings?.auto_scan_after_measurement !== '1'
    ) return;

    app.autoScannerStartingForKey = key;
    positionMobileCaptureViewport({ force: true });
    const started = await startIdScanner({ auto: true, focusOnFailure: false });
    if (started) app.autoScannerStartedForKey = key;
    app.autoScannerStartingForKey = '';
  }, Math.max(0, delay));
}

function advanceCaptureFieldFrom(field) {
  const index = captureFields.indexOf(field);
  if (index < 0) {
    activateCaptureField('id', { focus: true });
    return;
  }
  if (index === captureFields.length - 1) {
    activateCaptureField('id', { focus: true });
    return;
  }
  activateCaptureField(captureFields[index + 1], { focus: true });
}

function updateMobileCaptureDisplay({ syncInput = false } = {}) {
  const entryGrid = document.querySelector('.mobile-entry-grid');
  if (entryGrid) entryGrid.dataset.activeCapture = app.captureTarget || app.activeCaptureField;
  document.querySelectorAll('[data-capture-field]').forEach((row) => {
    const field = row.dataset.captureField;
    const active = field === app.captureTarget;
    const value = captureFieldValue(field).trim();
    row.classList.toggle('active', active);
    row.classList.toggle('filled', Boolean(value));
    const display = el(`mobileDisplay-${field}`);
    if (!display) return;
    display.textContent = value || captureFieldLabels[field] || field;
    display.classList.toggle('placeholder', !value);
  });

  const saveButton = el('mobileSaveButton');
  saveButton?.classList.toggle('capture-next', !app.captureUiInactive);
  const input = el('mobileFieldInput');
  const liveInputWrap = input?.closest('.mobile-live-input');
  if (liveInputWrap) liveInputWrap.dataset.activeCapture = app.captureTarget || app.activeCaptureField;
  const inlineScanButton = el('mobileScanIdButton');
  const scanVisible = app.activeCaptureField === 'id';
  liveInputWrap?.classList.toggle('scan-visible', scanVisible);
  if (inlineScanButton) {
    inlineScanButton.hidden = !scanVisible;
    inlineScanButton.disabled = !scanVisible || app.captureUiInactive;
    inlineScanButton.setAttribute('aria-hidden', scanVisible ? 'false' : 'true');
  }
  if (!input) return;
  input.placeholder = captureFieldLabels[app.activeCaptureField] || '';
  input.setAttribute('enterkeyhint', app.activeCaptureField === 'hersteller' ? 'done' : 'next');
  if (syncInput || document.activeElement !== input) {
    input.value = captureFieldValue(app.activeCaptureField);
  }
}

function setCaptureUiInactive(inactive) {
  const next = Boolean(inactive);
  app.captureUiInactive = next;
  const panel = document.querySelector('.mobile-capture-panel');
  panel?.classList.toggle('capture-ui-inactive', next);

  captureFields.forEach((field) => {
    const desktopInput = el(`field-${field}`);
    if (desktopInput) desktopInput.disabled = next;
  });
  document.querySelectorAll('[data-capture-field]').forEach((row) => {
    row.disabled = next;
    row.setAttribute('aria-disabled', next ? 'true' : 'false');
  });

  const input = el('mobileFieldInput');
  if (input) {
    input.disabled = next;
    input.setAttribute('aria-disabled', next ? 'true' : 'false');
    if (next && document.activeElement === input) input.blur();
  }
  document.querySelectorAll('.mobile-suggestion-button').forEach((button) => {
    button.disabled = next;
  });
  const scanButton = el('mobileScanIdButton');
  if (scanButton) scanButton.disabled = next || app.activeCaptureField !== 'id';
  updateMobileCaptureDisplay({ syncInput: false });
}

function compactSaveProgressLabel(label, complete = false) {
  const value = String(label || '').toLowerCase();
  if (complete) return value.includes('warn') ? 'Warnung' : 'Fertig';
  if (value.includes('warn')) return 'Warnung';
  if (value.includes('psi')) return 'PSI';
  if (value.includes('reset') || value.includes('zurück')) return 'Reset';
  if (value.includes('export')) return 'Export';
  if (value.includes('lokal')) return 'Lokal';
  if (value.includes('simulation')) return 'Sim.';
  if (value.includes('gespeichert')) return 'Fertig';
  return label ? String(label).slice(0, 7) : 'Speichert';
}

function renderMobileSaveProgress(state = app.state) {
  const button = el('mobileSaveButton');
  const label = el('mobileActionLabel');
  const hint = el('mobileActionHint');
  if (!button) return;

  const rawProgress = Number(state?.save_progress_percent ?? 0);
  const progress = Number.isFinite(rawProgress) ? Math.max(0, Math.min(100, rawProgress)) : 0;
  const saving = state?.app_state === 'POST_SAVE_CLEANUP' || (progress > 0 && progress < 100);
  const complete = state?.app_state === 'SAVED' || progress >= 100;
  const progressLabel = String(state?.save_progress_label || '').trim();

  button.style.setProperty('--save-progress', String(progress / 100));
  button.classList.toggle('saving', saving);
  button.classList.toggle('save-complete', complete);
  button.setAttribute('aria-busy', saving ? 'true' : 'false');
  button.title = progressLabel || (complete ? 'Gespeichert' : saving ? 'Speichervorgang läuft' : 'Zum nächsten Feld; lange halten und nach unten ziehen zum Speichern');
  button.setAttribute('aria-label', button.title);

  if (saving || complete) {
    if (label) label.textContent = compactSaveProgressLabel(progressLabel, complete);
    if (hint) hint.textContent = `${Math.round(progress)} %`;
  } else {
    if (label) label.textContent = 'Weiter';
    if (hint) hint.textContent = 'halten + ↓';
  }
}

function setLocalMobileSaveProgress(percent, labelText) {
  const button = el('mobileSaveButton');
  const label = el('mobileActionLabel');
  const hint = el('mobileActionHint');
  if (!button) return;
  const progress = Math.max(0, Math.min(100, Number(percent) || 0));
  button.style.setProperty('--save-progress', String(progress / 100));
  button.classList.toggle('saving', progress > 0 && progress < 100);
  button.classList.toggle('save-complete', progress >= 100);
  button.setAttribute('aria-busy', progress > 0 && progress < 100 ? 'true' : 'false');
  if (label) label.textContent = compactSaveProgressLabel(labelText, progress >= 100);
  if (hint) hint.textContent = `${Math.round(progress)} %`;
  button.title = labelText || (progress >= 100 ? 'Gespeichert' : 'Speichervorgang läuft');
  button.setAttribute('aria-label', button.title);
}

async function finalizeCaptureField(field = app.activeCaptureField) {
  if (field !== 'geraeteart') return;
  const raw = captureFieldValue('geraeteart');
  if (!raw.trim()) return;
  try {
    const data = await fetchJson('/api/draft/expand-device', {
      method: 'POST',
      body: JSON.stringify({ value: raw }),
    });
    const expanded = String(data.value ?? '').trim();
    if (expanded && expanded !== raw) {
      setCaptureFieldValue('geraeteart', expanded);
      refreshSuggestions('hersteller');
    }
  } catch (_error) {
    // Expansion is helpful, but field switching must never block on it.
  }
}

function activateCaptureField(field, { focus = true } = {}) {
  if (!captureFields.includes(field)) return;
  const previousField = app.activeCaptureField;
  app.activeCaptureField = field;
  app.captureTarget = field;
  updateMobileCaptureDisplay({ syncInput: true });
  refreshSuggestions(field, { forceRender: true });
  const input = el('mobileFieldInput');
  if (focus && input) focusMobileInputStable();
  if (previousField !== field) {
    finalizeCaptureField(previousField);
  }
}

function activateSaveTarget({ focus = true } = {}) {
  finalizeCaptureField(app.activeCaptureField);
  app.captureTarget = 'save';
  updateMobileCaptureDisplay({ syncInput: true });
  if (focus) {
    const button = el('mobileSaveButton');
    try { button?.focus({ preventScroll: true }); } catch (_error) { button?.focus(); }
  }
}

function stepCaptureField(direction) {
  const current = app.activeCaptureField;
  const currentIndex = Math.max(0, captureFields.indexOf(current));
  const nextIndex = (currentIndex + direction + captureFields.length) % captureFields.length;
  activateCaptureField(captureFields[nextIndex], { focus: true });
}

function writeMobileInputToActiveField() {
  const input = el('mobileFieldInput');
  if (!input) return;
  const field = app.activeCaptureField;
  const target = el(`field-${field}`);
  if (!target) return;
  target.value = input.value;
  updateMobileCaptureDisplay({ syncInput: false });
  scheduleDraftSave();
  refreshSuggestions(field);
}

function renderMobileSuggestions(field, values = []) {
  const node = el('mobileSuggestionButtons');
  if (!node || field !== app.activeCaptureField) return;
  const deduped = mergeSuggestionValues(field, values);
  node.innerHTML = deduped.slice(0, 8).map((value) => `
    <button type="button" class="mobile-suggestion-button" data-mobile-suggestion="${escapeAttribute(value)}" ${app.captureUiInactive ? 'disabled' : ''}>${escapeHtml(value)}</button>
  `).join('');
  node.querySelectorAll('[data-mobile-suggestion]').forEach((button) => {
    // Keep the shared text input focused while choosing a suggestion. Otherwise
    // Android closes the keyboard, focuses the button, then opens the keyboard
    // again for the next field and scrolls the page twice.
    button.addEventListener('pointerdown', (event) => event.preventDefault());
    button.addEventListener('mousedown', (event) => event.preventDefault());
    button.addEventListener('click', async () => {
      const field = app.activeCaptureField;
      setCaptureFieldValue(field, button.dataset.mobileSuggestion || '');
      if (field === 'geraeteart') {
        await finalizeCaptureField('geraeteart');
      }
      refreshSuggestions(field, { forceRender: true });
      advanceCaptureFieldFrom(field);
    });
  });
}

function cancelPendingDraftSave() {
  window.clearTimeout(app.draftSaveTimer);
  app.draftSaveTimer = null;
  try {
    app.draftSaveAbortController?.abort();
  } catch (_error) {}
  app.draftSaveAbortController = null;
}

function scheduleDraftSave() {
  window.clearTimeout(app.draftSaveTimer);
  app.draftSaveTimer = window.setTimeout(async () => {
    const controller = new AbortController();
    try {
      app.draftSaveAbortController?.abort();
    } catch (_error) {}
    app.draftSaveAbortController = controller;
    app.draftSaveTimer = null;
    try {
      await fetchJson('/api/draft', {
        method: 'POST',
        body: JSON.stringify(readDraftFromInputs()),
        signal: controller.signal,
      });
    } catch (error) {
      if (error?.name !== 'AbortError') toast(`Entwurf nicht gespeichert: ${error.message}`);
    } finally {
      if (app.draftSaveAbortController === controller) app.draftSaveAbortController = null;
    }
  }, 250);
}

function renderState(state) {
  app.state = state;

  const connected = state.connection_status === 'CONNECTED';
  el('connectionStatus').textContent = state.connection_status || 'DISCONNECTED';
  el('connectionDetail').textContent = state.connection_detail || '';
  el('connectionDot').classList.toggle('connected', connected);

  if (!app.draftInitialized) {
    applyServerDraft(state.draft || {});
    app.draftInitialized = true;
  }

  prepareNewMeasurementInput(state);
  renderAppStatePill(state.app_state);
  renderMeasurement(state.current_measurement, state.current_raw_protocol);
  renderRunningSequenceDialog(state);
  // Run this after the sequence dialog has been closed. The former timer was
  // marked as completed before the camera had actually opened and could vanish
  // silently when another modal was still active.
  queueAutoScannerForMeasurement(state);
  el('deviceStatus').textContent = state.current_device_status || '–';
  el('sequenceMessage').textContent = state.last_sequence_message || '–';
  el('rawProtocol').textContent = state.current_raw_protocol?.raw_record || '–';

  const noProject = !state.active_project;
  const listenOn = Boolean(state.listen_mode_enabled);
  const measurementReady = state.app_state === 'MEASUREMENT_RECEIVED_NEEDS_METADATA' && Boolean(state.current_measurement);
  const captureInactive = listenOn && !measurementReady;
  const workflowDisabled = Boolean(state.is_sequence_running || state.is_loading || noProject);
  const remoteWorkflowDisabled = workflowDisabled || listenOn;
  const listenToggleDisabled = Boolean(state.is_sequence_running || state.is_loading || noProject);
  const saveDisabled = state.app_state !== 'MEASUREMENT_RECEIVED_NEEDS_METADATA' || Boolean(state.is_loading || noProject);
  el('leitungenButton').disabled = remoteWorkflowDisabled;
  el('skButton').disabled = remoteWorkflowDisabled;
  el('saveButton').disabled = saveDisabled;
  el('mobileSaveButton').disabled = saveDisabled;
  ['listenModeButton', 'mobileListenModeButton'].forEach((id) => {
    const button = el(id);
    if (!button) return;
    button.disabled = listenToggleDisabled;
    button.classList.toggle('active', listenOn);
    button.setAttribute('aria-pressed', listenOn ? 'true' : 'false');
  });
  const mobilePsiButton = el('mobilePsiButton');
  if (mobilePsiButton) {
    mobilePsiButton.disabled = Boolean(state.is_sequence_running || state.is_loading || app.mobilePsiDrag.busy);
    mobilePsiButton.classList.toggle('listen-safe', listenOn);
  }
  const mobileTasAButton = el('mobileTasAButton');
  if (mobileTasAButton) {
    const directTopology = state.connection_topology === 'direct_secutest';
    mobileTasAButton.hidden = !directTopology;
    mobileTasAButton.disabled = Boolean(!directTopology || state.is_sequence_running || app.mobileTasABusy);
    mobileTasAButton.classList.toggle('listen-safe', listenOn);
  }
  el('connectButton').disabled = connected;
  el('disconnectButton').disabled = !connected;

  if (el('mobileWorkflowStatus')) {
    el('mobileWorkflowStatus').textContent = state.listen_mode_enabled
      ? (state.listen_message || 'Lauschmodus aktiv')
      : (state.current_raw_protocol?.source || state.active_measurement_button || '–');
  }
  if (el('mobileDeviceStatus')) {
    el('mobileDeviceStatus').textContent = state.current_device_status || '–';
  }
  if (el('mobileRawProtocol')) {
    el('mobileRawProtocol').textContent = state.current_raw_protocol?.raw_record || '–';
  }

  if (Array.isArray(state.logs) && app.visibleLogs.length === 0) {
    app.visibleLogs = [...state.logs];
    renderTerminal();
  }
  renderCommList(state.comm_log || []);
  renderMeasurementRate(state.measurement_rate || {});
  renderCustomButtons(state.custom_buttons || []);
  applySettings(state.settings || {});
  applyProjectState(state);
  maybePromptForProject(state);
  setCaptureUiInactive(captureInactive);
  updateMobileContext();
  updateMobileCaptureDisplay({ syncInput: false });
  renderMobileSaveProgress(state);
  scheduleRoomReminder(state);
}

function renderAppStatePill(value) {
  const node = el('appStatePill');
  node.classList.remove('pending', 'saved', 'fetching');
  const mapping = {
    READY_FOR_MEASUREMENT: 'Bereit',
    LISTEN_WAITING: 'Lauschmodus · wartet',
    LISTEN_FETCHING: 'Lauschmodus · liest PSI',
    LISTEN_ERROR: 'Lauschmodus · Fehler',
    FETCHING_MEASUREMENT: 'Rufe Messdaten ab…',
    MEASUREMENT_RECEIVED_NEEDS_METADATA: 'Messdaten empfangen',
    POST_SAVE_CLEANUP: 'Speichere · PSI leer · Reset/Init…',
    SAVED: 'Gespeichert',
  };
  node.textContent = mapping[value] || value || 'Bereit';
  if (value === 'FETCHING_MEASUREMENT') node.classList.add('fetching');
  if (value === 'LISTEN_WAITING' || value === 'LISTEN_FETCHING') node.classList.add('fetching');
  if (value === 'POST_SAVE_CLEANUP') node.classList.add('fetching');
  if (value === 'MEASUREMENT_RECEIVED_NEEDS_METADATA') node.classList.add('pending');
  if (value === 'SAVED') node.classList.add('saved');
}

function formatValue(value, suffix) {
  return value === null || value === undefined ? '' : `${value} ${suffix}`;
}

function twoDigit(value) {
  return String(value).padStart(2, '0');
}

function formatDisplayTimestamp(value) {
  const raw = String(value ?? '').trim();
  if (!raw) return '';

  const iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})/);
  if (iso) {
    return `${iso[4]}:${iso[5]} ${iso[3]}.${iso[2]}.${iso[1].slice(-2)}`;
  }

  const germanWithTimeFirst = raw.match(/^(\d{2})[.\/-](\d{2})[.\/-](\d{2,4})\s+(\d{2}):(\d{2})/);
  if (germanWithTimeFirst) {
    return `${germanWithTimeFirst[4]}:${germanWithTimeFirst[5]} ${germanWithTimeFirst[1]}.${germanWithTimeFirst[2]}.${germanWithTimeFirst[3].slice(-2)}`;
  }

  const already = raw.match(/^(\d{2}):(\d{2})\s+(\d{2})[.\/-](\d{2})[.\/-](\d{2,4})/);
  if (already) {
    return `${already[1]}:${already[2]} ${already[3]}.${already[4]}.${already[5].slice(-2)}`;
  }

  const date = new Date(raw);
  if (!Number.isNaN(date.getTime())) {
    return `${twoDigit(date.getHours())}:${twoDigit(date.getMinutes())} ${twoDigit(date.getDate())}.${twoDigit(date.getMonth() + 1)}.${String(date.getFullYear()).slice(-2)}`;
  }

  return raw;
}

function measurementItems(measurement) {
  if (!measurement) return [];
  const rawItems = Array.isArray(measurement.values) ? measurement.values : [];
  const items = rawItems
    .map((item) => ({ label: String(item?.label ?? '').trim(), value: String(item?.value ?? '').trim() }))
    .filter((item) => item.label && item.value);
  if (items.length) return items;
  return [
    { label: 'Rpe', value: formatValue(measurement.rpe, 'Ω') },
    { label: 'Rins', value: formatValue(measurement.rins, 'MΩ') },
    { label: 'Ipe', value: formatValue(measurement.ipe, 'mA') },
    { label: 'U', value: formatValue(measurement.u, 'V') },
  ].filter((item) => item.value);
}

function protocolMeasurementInfo(rawFields = [], fallbackMode = '') {
  const marker = String(rawFields?.[1] || '').replace(/[^0-9a-f]/gi, '').toUpperCase();
  let mode = String(fallbackMode || '').trim();
  const tests = [];
  const qualifiers = [];
  if (marker.length >= 4) {
    const bb = Number.parseInt(marker.slice(0, 2), 16);
    const cc = Number.parseInt(marker.slice(2, 4), 16);
    if (Number.isFinite(cc)) {
      if (cc & (1 << 5)) mode = 'Leitung';
      else if (cc & (1 << 4)) mode = 'EDV / Teil 240';
      else if (cc & (1 << 1)) mode = 'SK III';
      else if (cc & (1 << 0)) mode = 'SK I';
      else mode = 'SK II';
      if (cc & (1 << 2)) qualifiers.push('Teil 200');
      if (cc & (1 << 3)) qualifiers.push('hoher IEA');
      if (cc & (1 << 7)) qualifiers.push('Klemmenanschluss');
    }
    if (Number.isFinite(bb)) {
      const labels = ['R-SL', 'R-ISO', 'I-EA', 'I-Sonde', 'U AC/DC', 'ΔI', 'Funktionstest'];
      labels.forEach((label, bit) => { if (bb & (1 << bit)) tests.push(label); });
    }
  }
  if (mode === 'LEITUNGEN') mode = 'Leitung';
  if (mode === 'SK_I_II') mode = 'SK I/II';
  return { mode: mode || 'Messart unbekannt', tests, qualifiers };
}

function measurementRows(measurement) {
  const rows = [];
  const byKey = new Map();
  measurementItems(measurement).forEach((item) => {
    const match = item.label.match(/^(MW|GW)\s+(.+)$/i);
    const kind = match?.[1]?.toUpperCase() || 'MW';
    const label = (match?.[2] || item.label).replace(/_/g, ' ').replace(/\s+/g, ' ').trim();
    const key = label.toUpperCase();
    let row = byKey.get(key);
    if (!row) {
      row = { label, measured: '', limit: '' };
      byKey.set(key, row);
      rows.push(row);
    }
    if (kind === 'GW') row.limit = item.value;
    else if (!row.measured) row.measured = item.value;
  });
  return rows;
}

function measurementTable(measurement) {
  const rows = measurementRows(measurement);
  if (!rows.length) return '<div class="placeholder">Keine belegten Messwertfelder erkannt.</div>';
  return `
    <div class="measurement-table-wrap">
      <table class="measurement-table">
        <thead><tr><th>Prüfung</th><th>Messwert</th><th>Grenzwert</th></tr></thead>
        <tbody>${rows.map((row) => `
          <tr><th>${escapeHtml(row.label)}</th><td>${escapeHtml(row.measured || '–')}</td><td>${escapeHtml(row.limit || '–')}</td></tr>
        `).join('')}</tbody>
      </table>
    </div>`;
}

function measurementInfoBar(info) {
  const tests = info.tests.length ? `<span class="measurement-tests">${escapeHtml(info.tests.join(' · '))}</span>` : '';
  const qualifiers = info.qualifiers.map((value) => `<span class="measurement-qualifier">${escapeHtml(value)}</span>`).join('');
  return `<div class="measurement-info-bar"><strong>${escapeHtml(info.mode)}</strong>${tests}${qualifiers}</div>`;
}

function renderMeasurement(measurement, rawProtocol = null) {
  const nodes = [el('measurementSummary'), el('mobileMeasurementSummary')].filter(Boolean);
  const renderEmpty = '<div class="placeholder">Noch keine Messdaten übernommen.</div>';
  if (!measurement) {
    nodes.forEach((node) => {
      node.className = node.id === 'mobileMeasurementSummary' ? 'measurement-summary mobile-measurement-summary' : 'measurement-summary';
      node.innerHTML = renderEmpty;
    });
    return;
  }
  const fallbackMode = app.state?.active_measurement_button || app.state?.last_measurement_button || '';
  const info = protocolMeasurementInfo(rawProtocol?.raw_fields || [], fallbackMode);
  const html = `
    <div class="measurement-title">
      <span>${measurement.is_ok ? 'STATUS: OK' : 'STATUS: FEHLER'}</span>
      <span class="muted">${escapeHtml(formatDisplayTimestamp(measurement.timestamp))}</span>
    </div>
    ${measurementInfoBar(info)}
    ${measurementTable(measurement)}
  `;
  nodes.forEach((node) => {
    const mobileClass = node.id === 'mobileMeasurementSummary' ? ' mobile-measurement-summary' : '';
    node.className = `measurement-summary${mobileClass} ${measurement.is_ok ? 'ok' : 'failed'}`;
    node.innerHTML = html;
  });
}

function measurementBox(label, value) {
  return `<div class="measurement-value"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`;
}

function appendLog(line) {
  app.visibleLogs.push(line);
  if (app.visibleLogs.length > 240) app.visibleLogs.shift();
  renderTerminal();
}

function renderTerminal() {
  const content = app.visibleLogs.length ? app.visibleLogs.join('\n') : 'Noch keine Verbindungslogs vorhanden.';
  const terminal = el('terminal');
  if (terminal) {
    terminal.textContent = content;
    terminal.scrollTop = terminal.scrollHeight;
  }
  const mobileTerminal = el('mobileTerminal');
  if (mobileTerminal) {
    mobileTerminal.textContent = content;
    mobileTerminal.scrollTop = mobileTerminal.scrollHeight;
  }
  const mobileDebugTerminal = el('mobileDebugTerminal');
  if (mobileDebugTerminal) {
    mobileDebugTerminal.textContent = content;
    mobileDebugTerminal.scrollTop = mobileDebugTerminal.scrollHeight;
  }
}

function renderCommList(entries) {
  const recent = [...entries].slice(-28).reverse();
  const html = recent.map((entry) => {
    const rx = entry.direction === 'RX';
    const okClass = rx ? (entry.checksum_ok ? 'ok' : 'bad') : '';
    return `
      <article class="comm-entry ${entry.direction.toLowerCase()} ${okClass}">
        <div class="comm-entry-top">
          <strong>${escapeHtml(entry.direction)}</strong>
          <span>${escapeHtml(formatDisplayTimestamp(entry.timestamp))}</span>
          <span>${entry.checksum_ok === null || entry.checksum_ok === undefined ? '' : (entry.checksum_ok ? 'Checksum OK' : 'Checksum FEHLER')}</span>
        </div>
        <code>${escapeHtml(entry.plain_text || '')}</code>
      </article>
    `;
  }).join('');
  [el('commList'), el('mobileCommList')].filter(Boolean).forEach((node) => {
    node.innerHTML = html;
  });
}

function applySettings(settings, { force = false } = {}) {
  // Do not overwrite a checkbox or input while the settings dialog is being
  // edited. Live state messages used to make a visibly checked option revert
  // before the save click reached the server.
  if (!force && el('settingsDialog')?.open) return;
  el('setting-host').value = settings.host ?? '10.10.100.254';
  el('setting-port').value = settings.port ?? '8899';
  el('setting-poll').value = settings.poll_interval_ms ?? '300';
  el('setting-timeout').value = settings.command_timeout_ms ?? '2500';
  el('setting-rst-sk').value = settings.rst_code_sk_i_ii ?? '3';
  el('setting-rst-leitungen').value = settings.rst_code_leitungen ?? '4';
  const addressingEnabled = settings.device_addressing_enabled === '1';
  if (el('setting-device-addressing')) el('setting-device-addressing').checked = addressingEnabled;
  if (el('setting-rst-address')) {
    el('setting-rst-address').value = settings.rst_target_address ?? '1';
    el('setting-rst-address').disabled = !addressingEnabled;
  }
  document.querySelectorAll('.addressing-dependent-setting').forEach((node) => node.classList.toggle('setting-disabled', !addressingEnabled));
  if (el('setting-post-reset-settle')) el('setting-post-reset-settle').value = settings.post_reset_settle_ms ?? '2200';
  if (el('setting-room-idle-seconds')) el('setting-room-idle-seconds').value = settings.room_prompt_idle_seconds ?? '120';
  if (el('setting-measurement-rate-window')) el('setting-measurement-rate-window').value = settings.measurement_rate_window_minutes ?? '30';
  if (el('setting-capture-scroll-position')) el('setting-capture-scroll-position').value = settings.capture_scroll_position_px ?? '500';
  if (el('setting-auto-scan-after-measurement')) el('setting-auto-scan-after-measurement').checked = settings.auto_scan_after_measurement === '1';
  renderCustomListenSoundInfo();
  el('setting-simulation').checked = settings.simulation_enabled === '1';
  el('setting-autosave').checked = settings.autosave_enabled !== '0';
  el('setting-autosave-path').value = settings.autosave_path ?? 'data/records_autosave.xlsx';
}

async function connectTcp() {
  try {
    await fetchJson('/api/connect', { method: 'POST', body: '{}' });
    toast('Verbindung aufgebaut.');
  } catch (error) {
    toast(`Connect fehlgeschlagen: ${error.message}`);
  }
}

async function disconnectTcp() {
  try {
    await fetchJson('/api/disconnect', { method: 'POST', body: '{}' });
    toast('Verbindung getrennt.');
  } catch (error) {
    toast(`Disconnect fehlgeschlagen: ${error.message}`);
  }
}

function hasUnsavedMeasurement() {
  return Boolean(app.state?.current_measurement || app.state?.app_state === 'MEASUREMENT_RECEIVED_NEEDS_METADATA');
}

function showDialog(dialog) {
  if (!dialog) return false;
  if (dialog.open) return true;
  try {
    dialog.showModal();
    return dialog.open;
  } catch (_error) {
    return false;
  }
}

function closeDialog(dialog) {
  if (!dialog || !dialog.open) return;
  try { dialog.close(); } catch (_error) {}
}

function currentMonthValue() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

function formatProjectCycle(value) {
  const raw = String(value || '').trim();
  if (/^\d{4}-\d{2}$/.test(raw)) return `${raw.slice(5, 7)}.${raw.slice(0, 4)}`;
  return raw || '–';
}

function projectMetaLine(active, recordsCount = 0) {
  if (!active) return 'Bitte Kundenname, Straße, PLZ, Ort, Intervall + Prüfzyklus anlegen.';
  const address = [active.street, [active.postal_code, active.city].filter(Boolean).join(' ')].filter(Boolean).join(', ');
  const interval = active.test_interval_months || '24';
  return `${active.customer} · ${formatProjectCycle(active.cycle_month)} · ${address || 'Adresse fehlt'} · ${interval} Mon. · ${recordsCount || 0} Datensätze`;
}

function fillProjectForm(project = null, { overwriteFocused = false } = {}) {
  const panelFocused = document.activeElement?.closest?.('#projectMiniPanel');
  if (panelFocused && !overwriteFocused) return;
  if (el('projectId')) el('projectId').value = project?.id || '';
  if (el('projectCustomerInput')) el('projectCustomerInput').value = project?.customer || el('field-kunde')?.value || '';
  if (el('projectInspectorInput')) el('projectInspectorInput').value = project?.inspector || '';
  if (el('projectCycleMonthInput')) el('projectCycleMonthInput').value = project?.cycle_month || currentMonthValue();
  if (el('projectStreetInput')) el('projectStreetInput').value = project?.street || '';
  if (el('projectPostalCodeInput')) el('projectPostalCodeInput').value = project?.postal_code || '';
  if (el('projectCityInput')) el('projectCityInput').value = project?.city || '';
  if (el('projectIntervalInput')) el('projectIntervalInput').value = project?.test_interval_months || '24';
}

function applyProjectState(state = app.state || {}) {
  const active = state.active_project || null;
  const projects = Array.isArray(state.projects) ? state.projects : [];
  if (el('projectCurrentName')) el('projectCurrentName').textContent = active?.name || 'Kein Projekt geladen';
  if (el('projectCurrentMeta')) {
    el('projectCurrentMeta').textContent = projectMetaLine(active, state.records_count || 0);
  }
  fillProjectForm(active);
  const select = el('projectSelect');
  if (select) {
    select.innerHTML = projects.length
      ? projects.map((project) => `<option value="${project.id}" ${active?.id === project.id ? 'selected' : ''}>${escapeHtml(project.name)}</option>`).join('')
      : '<option value="">Keine Projekte</option>';
  }
}

function maybePromptForProject(state = app.state || {}) {
  if (state.active_project || app.projectPromptShown) return;
  app.projectPromptShown = true;
  fillProjectForm(null, { overwriteFocused: true });
  showDialog(el('historyDialog'));
  window.setTimeout(() => el('projectCustomerInput')?.focus(), 50);
  toast('Bitte zuerst Projekt-Stammdaten anlegen. Wenig Bürokratie, maximale Rettungsleine.');
}

function newProjectDraft() {
  fillProjectForm(null, { overwriteFocused: true });
  window.setTimeout(() => el('projectCustomerInput')?.focus(), 0);
}

async function saveProject() {
  try {
    const payload = {
      id: el('projectId')?.value || '',
      customer: el('projectCustomerInput')?.value?.trim() || '',
      inspector: el('projectInspectorInput')?.value?.trim() || '',
      cycle_month: el('projectCycleMonthInput')?.value || currentMonthValue(),
      street: el('projectStreetInput')?.value?.trim() || '',
      postal_code: el('projectPostalCodeInput')?.value?.trim() || '',
      city: el('projectCityInput')?.value?.trim() || '',
      test_interval_months: el('projectIntervalInput')?.value?.trim() || '24',
    };
    const data = await fetchJson('/api/projects', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    app.projectPromptShown = Boolean(data.project);
    toast(`Projekt aktiv: ${data.project?.name || 'OK'}`);
    await loadHistory();
  } catch (error) {
    toast(`Projekt nicht gespeichert: ${error.message}`);
  }
}

async function loadSelectedProject() {
  const id = el('projectSelect')?.value;
  if (!id) return;
  try {
    const data = await fetchJson('/api/projects/active', {
      method: 'POST',
      body: JSON.stringify({ id: Number(id) }),
    });
    toast(`Projekt geladen: ${data.project?.name || 'OK'}`);
    await loadHistory();
  } catch (error) {
    toast(`Projekt nicht geladen: ${error.message}`);
  }
}


function scannerSupportedFormats() {
  return [
    'qr_code',
    'code_128',
    'code_39',
    'code_93',
    'ean_13',
    'ean_8',
    'upc_a',
    'upc_e',
    'itf',
    'codabar',
    'data_matrix',
    'pdf417',
  ];
}

async function createBarcodeDetector() {
  if (!('BarcodeDetector' in window)) {
    throw new Error('BarcodeDetector wird von diesem Browser nicht unterstützt. Nutze Chrome/Edge auf Android oder gib die ID manuell ein.');
  }
  let formats = scannerSupportedFormats();
  if (typeof window.BarcodeDetector.getSupportedFormats === 'function') {
    const supported = await window.BarcodeDetector.getSupportedFormats();
    formats = formats.filter((format) => supported.includes(format));
  }
  if (!formats.length) throw new Error('Keine Barcode-Formate im Browser verfügbar.');
  return new window.BarcodeDetector({ formats });
}

function resetScannerStability() {
  app.scanner.lastValue = '';
  app.scanner.stableCount = 0;
  app.scanner.minReadyAt = Date.now() + 450;
}

function stopIdScanner({ focusInput = true } = {}) {
  app.scanner.active = false;
  app.scanner.busy = false;
  if (app.scanner.rafId) {
    window.cancelAnimationFrame(app.scanner.rafId);
    app.scanner.rafId = null;
  }
  if (app.scanner.stream) {
    app.scanner.stream.getTracks().forEach((track) => track.stop());
    app.scanner.stream = null;
  }
  const video = el('barcodeVideo');
  if (video) video.srcObject = null;
  closeDialog(el('barcodeScannerDialog'));
  resetScannerStability();
  if (focusInput) {
    window.setTimeout(() => focusMobileInputStable(), 0);
  }
}


function barcodeBoxFromCandidate(code) {
  if (code?.boundingBox) {
    return code.boundingBox;
  }
  const points = Array.isArray(code?.cornerPoints) ? code.cornerPoints : [];
  if (!points.length) return null;
  const xs = points.map((point) => Number(point.x)).filter(Number.isFinite);
  const ys = points.map((point) => Number(point.y)).filter(Number.isFinite);
  if (!xs.length || !ys.length) return null;
  const left = Math.min(...xs);
  const top = Math.min(...ys);
  return { x: left, y: top, width: Math.max(...xs) - left, height: Math.max(...ys) - top };
}

function barcodeLooksUsable(code, video) {
  const raw = String(code?.rawValue ?? '').trim();
  if (raw.length < 3) return false;
  const box = barcodeBoxFromCandidate(code);
  if (!box || !video?.videoWidth || !video?.videoHeight) {
    return Date.now() >= app.scanner.minReadyAt;
  }
  const width = Number(box.width) || 0;
  const height = Number(box.height) || 0;
  const areaRatio = (width * height) / (video.videoWidth * video.videoHeight);
  const centerX = (Number(box.x) + width / 2) / video.videoWidth;
  const centerY = (Number(box.y) + height / 2) / video.videoHeight;
  const centerInReticle = centerX >= 0.18 && centerX <= 0.82 && centerY >= 0.18 && centerY <= 0.82;
  const bigEnough = areaRatio >= 0.006 || Math.max(width / video.videoWidth, height / video.videoHeight) >= 0.09;
  return centerInReticle && bigEnough && Date.now() >= app.scanner.minReadyAt;
}

function considerBarcodeCandidate(code, video) {
  const raw = String(code?.rawValue ?? '').trim();
  if (!barcodeLooksUsable(code, video)) return null;
  if (raw === app.scanner.lastValue) {
    app.scanner.stableCount += 1;
  } else {
    app.scanner.lastValue = raw;
    app.scanner.stableCount = 1;
  }
  const status = el('barcodeScannerStatus');
  if (status) status.textContent = app.scanner.stableCount < 2
    ? `Erkannt: ${raw} – bitte kurz ruhig halten…`
    : `Übernehme: ${raw}`;
  return app.scanner.stableCount >= 2 ? raw : null;
}

function applyScannedId(value) {
  const normalized = String(value ?? '').trim();
  if (!normalized) return;
  setCaptureFieldValue('id', normalized);
  refreshSuggestions('id', { forceRender: true });
  stopIdScanner({ focusInput: false });
  toast(`ID gescannt: ${normalized}`);
  advanceCaptureFieldFrom('id');
}

async function scanFrame() {
  if (!app.scanner.active || app.scanner.busy) return;
  const video = el('barcodeVideo');
  if (!video || !app.scanner.detector) return;
  if (video.readyState < 2) {
    app.scanner.rafId = window.requestAnimationFrame(scanFrame);
    return;
  }
  app.scanner.busy = true;
  try {
    const codes = await app.scanner.detector.detect(video);
    const candidates = Array.isArray(codes) ? codes.filter((code) => String(code.rawValue ?? '').trim()) : [];
    const usable = candidates.find((code) => barcodeLooksUsable(code, video)) || null;
    if (usable) {
      const stableValue = considerBarcodeCandidate(usable, video);
      if (stableValue) {
        applyScannedId(stableValue);
        return;
      }
    }
  } catch (_error) {
    // Short camera frames can fail during autofocus/exposure changes. Keep scanning.
  } finally {
    app.scanner.busy = false;
  }
  if (app.scanner.active) app.scanner.rafId = window.requestAnimationFrame(scanFrame);
}

async function startIdScanner({ auto = false, focusOnFailure = true } = {}) {
  activateCaptureField('id', { focus: false });
  stopIdScanner({ focusInput: false });
  resetScannerStability();
  if (!navigator.mediaDevices?.getUserMedia) {
    toast('Kamera wird in diesem Browser/Kontext nicht freigegeben. Lokal über 127.0.0.1 starten.');
    return false;
  }
  const dialog = el('barcodeScannerDialog');
  const status = el('barcodeScannerStatus');
  const video = el('barcodeVideo');
  if (!dialog || !video) return false;
  if (status) status.textContent = 'Kamera wird gestartet…';

  // A finished measurement can arrive while the running-sequence modal is
  // still closing. Explicitly close it and verify that the scanner modal really
  // opened instead of swallowing showModal() errors.
  if (!app.state?.is_sequence_running) closeDialog(el('runningSequenceDialog'));
  await new Promise((resolve) => window.requestAnimationFrame(resolve));
  if (!showDialog(dialog)) {
    toast('Scanner nicht gestartet: Scannerfenster konnte nicht geöffnet werden.');
    return false;
  }

  try {
    app.scanner.detector = await createBarcodeDetector();
    const constraints = {
      video: {
        facingMode: { ideal: 'environment' },
        width: { ideal: 1280 },
        height: { ideal: 720 },
      },
      audio: false,
    };
    app.scanner.stream = await navigator.mediaDevices.getUserMedia(constraints);
    video.srcObject = app.scanner.stream;
    video.setAttribute('playsinline', '');
    await video.play();
    app.scanner.active = true;
    if (status) status.textContent = auto ? 'Scanner automatisch geöffnet. Barcode ruhig in den Rahmen halten.' : 'QR- oder Barcode ruhig in den Rahmen halten.';
    app.scanner.rafId = window.requestAnimationFrame(scanFrame);
    return true;
  } catch (error) {
    stopIdScanner({ focusInput: focusOnFailure });
    toast(`Scanner nicht gestartet: ${error.message}`);
    return false;
  }
}

function renderRunningSequenceDialog(state) {
  const dialog = el('runningSequenceDialog');
  if (!dialog) return;
  if (state?.is_sequence_running) {
    const label = state.active_measurement_button === 'LEITUNGEN' ? 'Leitungen' : 'SK I/II';
    if (el('runningSequenceText')) {
      el('runningSequenceText').textContent = `${label}: Messung läuft. TAS!4/MES? wird wiederholt bis NTZON;NULL erkannt wird.`;
    }
    showDialog(dialog);
  } else {
    closeDialog(dialog);
  }
}

function noteMeasurementActivity() {
  app.roomTimerResetAt = Date.now();
  app.roomReminderShownForCycle = false;
  window.clearTimeout(app.roomReminderTimer);
  app.roomReminderTimer = null;
  const dialog = el('roomReminderDialog');
  if (dialog?.open && !app.roomReminderManualOpen) closeDialog(dialog);
  scheduleRoomReminder(app.state);
}

function roomReminderSeconds(state = app.state) {
  const raw = Number(state?.settings?.room_prompt_idle_seconds ?? 120);
  return Number.isFinite(raw) && raw > 0 ? raw : 0;
}

function anyOtherDialogOpen(roomDialog) {
  return [...document.querySelectorAll('dialog[open]')].some((dialog) => dialog !== roomDialog);
}

function openRoomReminderDialog({ manual = false } = {}) {
  const dialog = el('roomReminderDialog');
  if (!dialog || dialog.open) return;
  if (!manual && (hasUnsavedMeasurement() || anyOtherDialogOpen(dialog))) {
    scheduleRoomReminder(app.state, { retryBlocked: true });
    return;
  }
  if (manual && anyOtherDialogOpen(dialog)) return;

  const currentRoom = el('field-raum_etage')?.value?.trim() || '';
  if (el('roomReminderInput')) el('roomReminderInput').value = currentRoom;
  app.roomReminderManualOpen = manual;
  // Opening the room editor satisfies the reminder for this measurement cycle,
  // but does not reset its timestamp. Only new measurement data may do that.
  app.roomReminderShownForCycle = true;
  showDialog(dialog);
  window.setTimeout(() => {
    const input = el('roomReminderInput');
    if (!input) return;
    input.focus({ preventScroll: true });
    const end = input.value.length;
    input.setSelectionRange(end, end);
  }, 50);
}

function scheduleRoomReminder(state = app.state, { retryBlocked = false } = {}) {
  window.clearTimeout(app.roomReminderTimer);
  app.roomReminderTimer = null;

  const seconds = roomReminderSeconds(state);
  if (!seconds || app.roomReminderShownForCycle) return;
  if (state?.is_loading || state?.is_sequence_running || state?.current_measurement) {
    if (retryBlocked) {
      app.roomReminderTimer = window.setTimeout(() => scheduleRoomReminder(app.state, { retryBlocked: true }), 1000);
    }
    return;
  }
  if (el('roomReminderDialog')?.open || anyOtherDialogOpen(el('roomReminderDialog'))) {
    app.roomReminderTimer = window.setTimeout(() => scheduleRoomReminder(app.state, { retryBlocked: true }), 1000);
    return;
  }

  const dueAt = app.roomTimerResetAt + (seconds * 1000);
  const delay = Math.max(0, dueAt - Date.now());
  app.roomReminderTimer = window.setTimeout(() => openRoomReminderDialog({ manual: false }), delay);
}

function closeRoomReminder({ save = false } = {}) {
  if (save) {
    const value = el('roomReminderInput')?.value ?? '';
    const roomField = el('field-raum_etage');
    if (roomField) {
      roomField.value = value;
      roomField.dispatchEvent(new Event('input', { bubbles: true }));
    }
    updateMobileContext();
    scheduleDraftSave();
  }
  closeDialog(el('roomReminderDialog'));
  app.roomReminderManualOpen = false;
}

function renderMeasurementRate(info = {}) {
  const windowMinutes = Math.max(1, Number(info.window_minutes ?? 30) || 30);
  const count = Math.max(0, Number(info.count ?? 0) || 0);
  const rate = Math.max(0, Number(info.rate_per_hour ?? 0) || 0);
  const rateText = rate.toLocaleString('de-DE', { minimumFractionDigits: rate % 1 ? 1 : 0, maximumFractionDigits: 1 });
  if (el('mobileMeasurementRate')) el('mobileMeasurementRate').textContent = `${rateText} Messungen/h`;
  if (el('mobileMeasurementRateDetail')) {
    el('mobileMeasurementRateDetail').textContent = `${count} ${count === 1 ? 'gespeicherte Messung' : 'gespeicherte Messungen'} in den letzten ${windowMinutes} Minuten`;
  }
}

async function refreshMeasurementRate() {
  try {
    const info = await fetchJson('/api/measurement-rate');
    if (app.state) app.state.measurement_rate = info;
    renderMeasurementRate(info);
  } catch (_error) {
    // The main workflow must remain usable if this small status query fails.
  }
}

function startMeasurementRatePolling() {
  window.clearInterval(app.measurementRateTimer);
  app.measurementRateTimer = window.setInterval(refreshMeasurementRate, 30000);
}

async function toggleListenMode() {
  ensureListenAudioReady();
  const enabled = !Boolean(app.state?.listen_mode_enabled);
  if (enabled && hasUnsavedMeasurement()) {
    toast('Ungespeicherte Messdaten vorhanden – bitte zuerst speichern oder verwerfen.');
    return;
  }
  try {
    const data = await fetchJson('/api/listen-mode', {
      method: 'POST',
      body: JSON.stringify({ enabled }),
    });
    if (data.state) renderState(data.state);
    toast(enabled ? 'Lauschmodus aktiv.' : 'Lauschmodus aus.');
  } catch (error) {
    toast(error.message);
  }
}

function askUnsavedBeforeSequence(kind) {
  app.pendingSequenceKind = kind;
  showDialog(el('unsavedMeasurementDialog'));
}

async function runSequence(kind, { force = false } = {}) {
  if (!force && hasUnsavedMeasurement()) {
    askUnsavedBeforeSequence(kind);
    return;
  }
  const endpoint = kind === 'leitungen' ? '/api/sequence/leitungen' : '/api/sequence/sk';
  try {
    const result = await fetchJson(endpoint, { method: 'POST', body: '{}' });
    toast(result.result?.message || 'Sequenz beendet.');
  } catch (error) {
    toast(error.message);
  }
}

async function continuePendingSequenceAfterClear() {
  const kind = app.pendingSequenceKind;
  app.pendingSequenceKind = null;
  closeDialog(el('unsavedMeasurementDialog'));
  if (kind) await runSequence(kind, { force: true });
}

async function discardCurrentMeasurement({ reset = true } = {}) {
  try {
    const data = await fetchJson('/api/measurement/discard', {
      method: 'POST',
      body: JSON.stringify({ reset }),
    });
    app.preparedMeasurementKey = null;
    app.autoScannerStartedForKey = '';
    app.autoScannerStartingForKey = '';
    window.clearTimeout(app.autoScannerTimer);
    app.autoScannerTimer = null;
    stopIdScanner({ focusInput: false });
    unlockMobileCaptureViewport();
    clearCaptureFields({ saveDraft: true });
    toast(data.message || (reset ? 'Messung verworfen. PSI leer + Reset/Init erledigt.' : 'Messung verworfen. PSI leer, kein Reset.'));
    return true;
  } catch (error) {
    // Do not clear the local fields when PSI cleanup could not be confirmed.
    // The user can retry instead of having the same PSI record reappear silently.
    toast(`Verwerfen fehlgeschlagen: ${error.message}`);
    return false;
  }
}

async function cancelRunningSequence({ reset = false } = {}) {
  const endpoint = reset ? '/api/sequence/cancel-reset' : '/api/sequence/cancel';
  try {
    const result = await fetchJson(endpoint, { method: 'POST', body: '{}' });
    toast(result.message || (reset ? 'Abbruch + Reset angefordert.' : 'Abbruch angefordert.'));
  } catch (error) {
    toast(error.message);
  }
}

async function saveRecord() {
  try {
    setLocalMobileSaveProgress(5, 'Start');
    const payload = readDraftFromInputs();
    rememberLastCaptureValues(payload);
    // Prevent an older delayed /api/draft request from writing the just-saved
    // ID/device values back into the persistent draft after the save endpoint
    // has already cleared them.
    cancelPendingDraftSave();
    const data = await fetchJson('/api/records/save', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    app.activeCaptureField = 'id';
    app.captureTarget = 'id';
    app.preparedMeasurementKey = null;
    app.autoScannerStartedForKey = '';
    app.autoScannerStartingForKey = '';
    window.clearTimeout(app.autoScannerTimer);
    app.autoScannerTimer = null;
    stopIdScanner({ focusInput: false });
    unlockMobileCaptureViewport();
    clearCaptureFields({ saveDraft: false });
    try {
      await fetchJson('/api/draft', {
        method: 'POST',
        body: JSON.stringify(readDraftFromInputs()),
      });
    } catch (_error) {
      // The save endpoint already cleared these fields server-side. This second
      // write only closes a possible browser-side race and is non-critical.
    }
    refreshSuggestions('id', { forceRender: true });
    if (data.measurement_rate) {
      if (app.state) app.state.measurement_rate = data.measurement_rate;
      renderMeasurementRate(data.measurement_rate);
    }
    const cleanupOk = data.post_save_cleanup?.ok !== false;
    setLocalMobileSaveProgress(100, cleanupOk ? 'Gespeichert' : 'Mit Warnung');
    playSaveSolvedJingle();
    toast(cleanupOk
      ? 'Datensatz gespeichert. PSI leer bestätigt + Reset/Init erledigt.'
      : 'Datensatz gespeichert, aber PSI NICHT als leer bestätigt! Nicht weiter messen; Verbindungs-Log prüfen.');
    return true;
  } catch (error) {
    renderMobileSaveProgress(app.state);
    toast(`Speichern fehlgeschlagen: ${error.message}`);
    return false;
  }
}

async function sendCommand(command = null) {
  const raw = command ?? el('commandInput').value;
  const normalized = String(raw || '').trim();
  if (!normalized) {
    toast('Kein Befehl eingegeben.');
    return;
  }
  try {
    const data = await fetchJson('/api/command', {
      method: 'POST',
      body: JSON.stringify({ command: normalized }),
    });
    toast(`Antwort: ${data.frame?.payload_without_checksum || 'OK'}`);
    if (!command) el('commandInput').select();
  } catch (error) {
    toast(`Befehl fehlgeschlagen: ${error.message}`);
  }
}

async function manualAction(endpoint, successMessage) {
  try {
    await fetchJson(endpoint, { method: 'POST', body: '{}' });
    toast(successMessage);
  } catch (error) {
    toast(error.message);
  }
}

async function saveSettings() {
  try {
    const payload = {
      host: el('setting-host').value.trim(),
      port: Number(el('setting-port').value || 8899),
      poll_interval_ms: Number(el('setting-poll').value || 300),
      command_timeout_ms: Number(el('setting-timeout').value || 2500),
      rst_code_sk_i_ii: el('setting-rst-sk').value || '3',
      rst_code_leitungen: el('setting-rst-leitungen').value || '4',
      device_addressing_enabled: el('setting-device-addressing')?.checked || false,
      rst_target_address: el('setting-rst-address')?.value || '1',
      post_reset_settle_ms: el('setting-post-reset-settle')?.value || '2200',
      room_prompt_idle_seconds: el('setting-room-idle-seconds')?.value || '120',
      measurement_rate_window_minutes: el('setting-measurement-rate-window')?.value || '30',
      capture_scroll_position_px: el('setting-capture-scroll-position')?.value || '500',
      auto_scan_after_measurement: el('setting-auto-scan-after-measurement')?.checked || false,
      simulation_enabled: el('setting-simulation').checked,
      autosave_enabled: el('setting-autosave').checked,
      autosave_path: el('setting-autosave-path').value.trim() || 'data/records_autosave.xlsx',
    };
    await saveCustomListenSoundFromInput();
    const data = await fetchJson('/api/settings', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    if (app.state) app.state.settings = data.settings || app.state.settings;
    applySettings(data.settings || {}, { force: true });
    el('settingsDialog').close();
    if (app.captureViewportLocked) positionMobileCaptureViewport({ force: true });
    scheduleRoomReminder(app.state);
    await refreshMeasurementRate();
    toast('Einstellungen gespeichert.');
  } catch (error) {
    toast(`Einstellungen nicht gespeichert: ${error.message}`);
  }
}

async function importExcel(file) {
  if (!file) return;
  const formData = new FormData();
  formData.append('file', file);
  try {
    const response = await fetch('/api/records/import.xlsx', {
      method: 'POST',
      body: formData,
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || 'Import fehlgeschlagen.');
    toast(`${data.imported} Datensätze importiert.`);
    await loadHistory();
  } catch (error) {
    toast(`Import fehlgeschlagen: ${error.message}`);
  } finally {
    if (el('projectImportInput')) el('projectImportInput').value = '';
  }
}

async function refreshSuggestions(field, { forceRender = false } = {}) {
  if (!captureFields.includes(field)) return;
  const requestId = (app.suggestionRequestIds[field] || 0) + 1;
  app.suggestionRequestIds[field] = requestId;

  // Abort only the older request for the same field. Requests for other fields
  // must not overwrite or cancel the active mobile button list.
  try {
    app.suggestionAbortControllers[field]?.abort();
  } catch (_error) {}
  const controller = new AbortController();
  app.suggestionAbortControllers[field] = controller;

  const queryMap = {
    id: el('field-id').value,
    geraeteart: el('field-geraeteart').value,
    hersteller: el('field-hersteller').value,
  };
  const datalistMap = {
    id: 'suggestions-id',
    geraeteart: 'suggestions-device',
    hersteller: 'suggestions-manufacturer',
  };

  // Keep the UI responsive immediately, even if Chrome is still busy with a
  // previous fetch/WebSocket task. The '-' button is never optional.
  if (forceRender || field === app.activeCaptureField) {
    renderMobileSuggestions(field, app.suggestionCache[field] || ['-']);
  }

  try {
    const params = new URLSearchParams({
      field,
      q: queryMap[field] || '',
      geraeteart: el('field-geraeteart').value || '',
      ts: String(Date.now()),
    });
    const data = await fetchJson(`/api/suggestions?${params.toString()}`, { signal: controller.signal });
    if (requestId !== app.suggestionRequestIds[field]) return;
    const values = mergeSuggestionValues(field, data.values || []);
    app.suggestionCache[field] = values;

    const datalist = el(datalistMap[field]);
    if (datalist) {
      datalist.innerHTML = values.map((value) => `<option value="${escapeAttribute(value)}"></option>`).join('');
    }
    if (field === app.activeCaptureField) {
      renderMobileSuggestions(field, values);
    }
  } catch (error) {
    if (error?.name === 'AbortError') return;
    // Suggestions are convenience only; do not spam the UI on failure.
    if (field === app.activeCaptureField) renderMobileSuggestions(field, app.suggestionCache[field] || ['-']);
  }
}

async function openHistory() {
  applyProjectState(app.state || {});
  el('historyDialog').showModal();
  await loadHistory();
}

async function loadHistory() {
  try {
    const sort = el('historySort').value;
    const data = await fetchJson(`/api/records?sort=${encodeURIComponent(sort)}`);
    app.history = data.records || [];
    renderHistory();
  } catch (error) {
    toast(`Verlauf fehlgeschlagen: ${error.message}`);
  }
}

function renderHistory() {
  const search = el('historySearch').value.trim().toLowerCase();
  const resultFilter = el('historyResultFilter').value;
  const filtered = app.history.filter((record) => {
    const ok = Boolean(record.measurement?.is_ok);
    if (resultFilter === 'ok' && !ok) return false;
    if (resultFilter === 'failed' && ok) return false;
    if (!search) return true;
    const haystack = [
      record.metadata?.id,
      record.metadata?.geraeteart,
      record.metadata?.hersteller,
      record.metadata?.kunde,
      record.metadata?.raum_etage,
      record.measurement?.rpe,
      record.measurement?.rins,
      record.measurement?.ipe,
      record.measurement?.u,
      ...(measurementItems(record.measurement).flatMap((item) => [item.label, item.value])),
    ].filter(Boolean).join(' ').toLowerCase();
    return haystack.includes(search);
  });
  el('historyCount').textContent = `${filtered.length} von ${app.history.length} Datensätzen angezeigt`;
  el('historyList').innerHTML = filtered.map(renderHistoryItem).join('');
  document.querySelectorAll('[data-edit-record]').forEach((button) => {
    button.addEventListener('click', () => openEditRecord(Number(button.dataset.editRecord)));
  });
}

function renderHistoryItem(record) {
  const ok = Boolean(record.measurement?.is_ok);
  const meta = record.metadata || {};
  const meas = record.measurement || {};
  const sequenceLabel = record.project_sequence ? `Nr. ${String(record.project_sequence).padStart(4, '0')}` : `DB #${record.id}`;
  const measurementInfo = protocolMeasurementInfo(record.raw_fields || [], record.raw_source || '');
  const measurementHtml = `${measurementInfoBar(measurementInfo)}${measurementTable(meas)}`;
  return `
    <article class="history-item">
      <div class="history-top">
        <strong><span class="record-sequence">${escapeHtml(sequenceLabel)}</span> ${escapeHtml(meta.id || 'Ohne ID')}</strong>
        <span>${escapeHtml(meta.geraeteart || '–')}</span>
        <span>${escapeHtml(meta.hersteller || '–')}</span>
        <span>${escapeHtml(meta.raum_etage || 'Kein Raum')}</span>
        <span class="history-result ${ok ? 'ok' : 'failed'}">${ok ? 'OK' : 'Fehler'}</span>
      </div>
      <div class="history-meta">
        <span>Messung: ${ok ? 'BESTANDEN' : 'NICHT BESTANDEN'} · Empfangen: ${escapeHtml(formatDisplayTimestamp(meas.timestamp || record.created_at))}</span>
        <div class="history-measurements">${measurementHtml}</div>
      </div>
      <div class="modal-actions">
        <button class="secondary tiny" data-edit-record="${record.id}">Datensatz bearbeiten</button>
      </div>
    </article>
  `;
}

function openEditRecord(recordId) {
  const record = app.history.find((item) => item.id === recordId);
  if (!record) return;
  const meta = record.metadata || {};
  el('edit-record-id').value = recordId;
  ['id', 'geraeteart', 'hersteller', 'kunde', 'raum_etage'].forEach((field) => {
    el(`edit-${field}`).value = meta[field] || '';
  });
  el('editRecordDialog').showModal();
}

async function saveEditedRecord() {
  const recordId = Number(el('edit-record-id').value);
  const payload = {};
  ['id', 'geraeteart', 'hersteller', 'kunde', 'raum_etage'].forEach((field) => {
    payload[field] = el(`edit-${field}`).value || '';
  });
  try {
    await fetchJson(`/api/records/${recordId}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    el('editRecordDialog').close();
    await loadHistory();
    toast('Datensatz aktualisiert.');
  } catch (error) {
    toast(`Änderung fehlgeschlagen: ${error.message}`);
  }
}

function renderCustomButtons(buttons) {
  const node = el('customButtons');
  node.innerHTML = buttons.map((button) => `
    <article class="custom-button-card">
      <h3>${escapeHtml(button.name)}</h3>
      <pre>${escapeHtml((button.commands || '').split(/\r?\n/).slice(0, 4).join('\n') || 'Noch leer')}</pre>
      <div class="custom-button-actions">
        <button data-run-custom="${button.id}">Start</button>
        <button class="secondary" data-edit-custom="${button.id}">Edit</button>
      </div>
    </article>
  `).join('');
  document.querySelectorAll('[data-run-custom]').forEach((button) => {
    button.addEventListener('click', () => runCustomButton(Number(button.dataset.runCustom)));
  });
  document.querySelectorAll('[data-edit-custom]').forEach((button) => {
    button.addEventListener('click', () => openCustomButtonEditor(Number(button.dataset.editCustom)));
  });
}

function openCustomButtonEditor(buttonId) {
  const button = (app.state?.custom_buttons || []).find((item) => item.id === buttonId);
  if (!button) return;
  el('custom-button-id').value = buttonId;
  el('custom-button-name').value = button.name || `USER ${buttonId}`;
  el('custom-button-commands').value = button.commands || '';
  el('customButtonDialog').showModal();
}

async function saveCustomButton() {
  const buttonId = Number(el('custom-button-id').value);
  try {
    await fetchJson(`/api/custom-buttons/${buttonId}`, {
      method: 'PUT',
      body: JSON.stringify({
        name: el('custom-button-name').value,
        commands: el('custom-button-commands').value,
      }),
    });
    el('customButtonDialog').close();
    toast('Button gespeichert.');
  } catch (error) {
    toast(`Button nicht gespeichert: ${error.message}`);
  }
}

async function runCustomButton(buttonId) {
  try {
    const data = await fetchJson(`/api/custom-buttons/${buttonId}/run`, {
      method: 'POST',
      body: '{}',
    });
    toast(data.ok ? 'Sequenz-Button abgeschlossen.' : 'Sequenz-Button mit Abbruch beendet.');
  } catch (error) {
    toast(`Sequenz-Button fehlgeschlagen: ${error.message}`);
  }
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll('`', '&#096;');
}

function installClearButtons() {
  const selectors = [
    '#mobileFieldInput',
    ...draftFields.map((field) => `#field-${field}`),
    '#edit-id', '#edit-geraeteart', '#edit-hersteller', '#edit-kunde', '#edit-raum_etage',
    '#projectCustomerInput', '#projectInspectorInput', '#projectStreetInput', '#projectPostalCodeInput', '#projectCityInput', '#projectIntervalInput',
  ];
  document.querySelectorAll(selectors.join(',')).forEach((input) => {
    if (!input || input.type === 'hidden' || input.dataset.clearInstalled === '1') return;
    const parent = input.parentElement;
    if (!parent) return;
    parent.classList.add('clearable-field');
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'input-clear-button';
    button.setAttribute('aria-label', 'Feldinhalt löschen');
    button.textContent = '×';
    button.addEventListener('pointerdown', (event) => event.preventDefault());
    button.addEventListener('click', (event) => {
      event.preventDefault();
      input.value = '';
      input.dispatchEvent(new Event('input', { bubbles: true }));
      if (input.id === 'mobileFieldInput') {
        writeMobileInputToActiveField();
      }
      input.focus();
    });
    parent.appendChild(button);
    input.dataset.clearInstalled = '1';
  });
}

function connectWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  app.ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
  app.ws.onopen = () => {
    app.ws.send('ready');
  };
  app.ws.onmessage = (event) => {
    try {
      const payload = JSON.parse(event.data);
      if (payload.type === 'state') {
        renderState(payload.state);
      } else if (payload.type === 'draft') {
        applyServerDraft(payload.draft || {});
      } else if (payload.type === 'log') {
        appendLog(payload.line);
      } else if (payload.type === 'comm') {
        const current = app.state?.comm_log || [];
        current.push(payload.entry);
        if (current.length > 240) current.shift();
        if (app.state) app.state.comm_log = current;
        renderCommList(current);
      } else if (payload.type === 'listen_measurement_received') {
        lockMobileCaptureViewport({ position: true, forcePosition: true });
        playListenBeep();
        // The dedicated receive event is an additional reliable trigger for the
        // automatic scanner. The state event remains the trigger for normal
        // button-driven measurements.
        queueAutoScannerForMeasurement(app.state, { delay: 0 });
      } else if (payload.type === 'listen_new_data_pending') {
        playListenWarningBeep();
        toast(payload.message || 'Neue Messdaten stehen bereit. Bitte aktuelle Messung zuerst speichern.');
      }
    } catch (_error) {
      // Ignore malformed socket messages.
    }
  };
  app.ws.onclose = () => {
    window.setTimeout(connectWebSocket, 1200);
  };
}

async function loadInitialState() {
  try {
    const state = await fetchJson('/api/state');
    renderState(state);
  } catch (error) {
    toast(`Initialisierung fehlgeschlagen: ${error.message}`);
  }
}

function setMobileSaveDragVisual(button, { armed = false, progress = 0 } = {}) {
  if (!button) return;
  const normalized = Math.max(0, Math.min(1, Number(progress) || 0));
  button.classList.toggle('gesture-active', app.mobileSaveDrag.active);
  button.classList.toggle('gesture-armed', armed);
  button.classList.toggle('drag-save', armed && normalized >= 1);
  button.style.setProperty('--save-progress', String(normalized));
  const percent = Math.round(normalized * 100);
  button.setAttribute('data-drag-label', armed ? `Speichern ${percent} %` : 'Halten …');
  const label = el('mobileActionLabel');
  const hint = el('mobileActionHint');
  if (label) label.textContent = armed ? 'Nach unten' : 'Halten';
  if (hint) hint.textContent = armed ? `${percent} %` : 'zum Speichern';
}

function resetMobileSaveDragVisual(button = el('mobileSaveButton')) {
  window.clearTimeout(app.mobileSaveDrag.holdTimer);
  app.mobileSaveDrag.holdTimer = null;
  if (!button) return;
  button.classList.remove('gesture-active', 'gesture-armed', 'drag-save');
  button.removeAttribute('data-drag-label');
  if (!button.classList.contains('saving') && !button.classList.contains('save-complete')) {
    button.style.setProperty('--save-progress', '0');
    const label = el('mobileActionLabel');
    const hint = el('mobileActionHint');
    if (label) label.textContent = 'Weiter';
    if (hint) hint.textContent = 'halten + ↓';
  }
}

function installMobileSaveDrag() {
  const button = el('mobileSaveButton');
  if (!button) return;

  button.addEventListener('pointerdown', (event) => {
    if (button.disabled || button.classList.contains('saving') || !hasUnsavedMeasurement()) return;
    event.preventDefault();
    ensureListenAudioReady();
    window.clearTimeout(app.mobileSaveDrag.holdTimer);
    app.mobileSaveDrag = {
      active: true,
      armed: false,
      startY: event.clientY,
      pointerId: event.pointerId,
      progress: 0,
      holdTimer: null,
      suppressClick: true,
    };
    try { button.setPointerCapture(event.pointerId); } catch (_error) {}
    setMobileSaveDragVisual(button, { armed: false, progress: 0 });
    app.mobileSaveDrag.holdTimer = window.setTimeout(() => {
      if (!app.mobileSaveDrag.active || app.mobileSaveDrag.pointerId !== event.pointerId) return;
      app.mobileSaveDrag.armed = true;
      try { navigator.vibrate?.(24); } catch (_error) {}
      setMobileSaveDragVisual(button, { armed: true, progress: app.mobileSaveDrag.progress });
    }, 360);
  });

  button.addEventListener('pointermove', (event) => {
    if (!app.mobileSaveDrag.active || app.mobileSaveDrag.pointerId !== event.pointerId) return;
    event.preventDefault();
    const deltaY = Math.max(0, event.clientY - app.mobileSaveDrag.startY);
    const progress = Math.max(0, Math.min(1, deltaY / 64));
    app.mobileSaveDrag.progress = progress;
    if (!app.mobileSaveDrag.armed) return;
    setMobileSaveDragVisual(button, { armed: true, progress });
  });

  const finish = async (event, cancelled = false) => {
    if (!app.mobileSaveDrag.active || app.mobileSaveDrag.pointerId !== event.pointerId) return;
    event.preventDefault();
    const armed = app.mobileSaveDrag.armed;
    const progress = app.mobileSaveDrag.progress;
    window.clearTimeout(app.mobileSaveDrag.holdTimer);
    app.mobileSaveDrag.active = false;
    app.mobileSaveDrag.holdTimer = null;
    try { button.releasePointerCapture(event.pointerId); } catch (_error) {}

    if (cancelled) {
      resetMobileSaveDragVisual(button);
    } else if (!armed) {
      resetMobileSaveDragVisual(button);
      stepCaptureField(1);
    } else if (progress >= 1) {
      resetMobileSaveDragVisual(button);
      await saveRecord();
    } else {
      resetMobileSaveDragVisual(button);
      toast('Zum Speichern weiter nach unten ziehen.');
    }
    window.setTimeout(() => { app.mobileSaveDrag.suppressClick = false; }, 0);
  };

  button.addEventListener('pointerup', (event) => finish(event, false));
  button.addEventListener('pointercancel', (event) => finish(event, true));
  button.addEventListener('click', (event) => {
    event.preventDefault();
    if (app.mobileSaveDrag.suppressClick) event.stopPropagation();
  });
}


function setMobilePsiDragVisual(button, { armed = false, progress = 0 } = {}) {
  if (!button) return;
  const normalized = Math.max(0, Math.min(1, Number(progress) || 0));
  const percent = Math.round(normalized * 100);
  button.classList.toggle('gesture-active', app.mobilePsiDrag.active);
  button.classList.toggle('gesture-armed', armed);
  button.classList.toggle('drag-delete', armed && normalized >= 1);
  button.style.setProperty('--psi-delete-progress', String(normalized));
  const label = el('mobilePsiLabel');
  const hint = el('mobilePsiHint');
  if (label) label.textContent = armed ? 'Löschen' : 'Halten';
  if (hint) hint.textContent = armed ? `${percent} %` : 'für Löschen';
  button.setAttribute('aria-label', armed
    ? `PSI-Speicher löschen: ${percent} Prozent erreicht`
    : 'Gedrückt halten und nach unten ziehen zum Löschen des PSI-Speichers');
}

function resetMobilePsiDragVisual(button = el('mobilePsiButton')) {
  window.clearTimeout(app.mobilePsiDrag.holdTimer);
  app.mobilePsiDrag.holdTimer = null;
  if (!button) return;
  button.classList.remove('gesture-active', 'gesture-armed', 'drag-delete', 'fetching', 'deleting', 'delete-complete');
  button.style.setProperty('--psi-delete-progress', '0');
  const label = el('mobilePsiLabel');
  const hint = el('mobilePsiHint');
  if (label) label.textContent = 'PSI';
  if (hint) hint.textContent = 'holen';
  button.setAttribute('aria-label', 'Letztes PSI-Ergebnis holen; lange halten und nach unten ziehen zum Löschen');
}

function setMobilePsiBusy(busy, mode = '') {
  app.mobilePsiDrag.busy = Boolean(busy);
  const button = el('mobilePsiButton');
  if (!button) return;
  button.disabled = Boolean(busy || app.state?.is_sequence_running || app.state?.is_loading);
  button.classList.toggle('fetching', Boolean(busy && mode === 'fetch'));
  button.classList.toggle('deleting', Boolean(busy && mode === 'delete'));
  const label = el('mobilePsiLabel');
  const hint = el('mobilePsiHint');
  if (busy) {
    if (label) label.textContent = mode === 'delete' ? 'Löscht' : 'Holt';
    if (hint) hint.textContent = '…';
    button.setAttribute('aria-busy', 'true');
  } else {
    button.removeAttribute('aria-busy');
    resetMobilePsiDragVisual(button);
  }
}

async function fetchLatestPsiFromTitle() {
  if (app.mobilePsiDrag.busy) return;
  setMobilePsiBusy(true, 'fetch');
  try {
    await fetchJson('/api/manual/fetch-latest', { method: 'POST', body: '{}' });
    toast('Letzter PSI-Datensatz übernommen.');
  } catch (error) {
    toast(`PSI-Abruf fehlgeschlagen: ${error.message}`);
  } finally {
    setMobilePsiBusy(false);
  }
}

async function sendTasAFromTitle() {
  if (app.mobileTasABusy) return;
  const button = el('mobileTasAButton');
  app.mobileTasABusy = true;
  if (button) button.disabled = true;
  try {
    await fetchJson('/api/manual/tas-a', { method: 'POST', body: '{}' });
    toast('TAS!a gesendet.');
  } catch (error) {
    toast(`TAS!a fehlgeschlagen: ${error.message}`);
  } finally {
    app.mobileTasABusy = false;
    if (button) button.disabled = Boolean(app.state && app.state.connection_topology !== 'direct_secutest');
  }
}

async function clearPsiFromTitle() {
  if (app.mobilePsiDrag.busy) return;
  setMobilePsiBusy(true, 'delete');
  try {
    await fetchJson('/api/manual/clear-psi', { method: 'POST', body: '{}' });
    const button = el('mobilePsiButton');
    button?.classList.add('delete-complete');
    const label = el('mobilePsiLabel');
    const hint = el('mobilePsiHint');
    if (label) label.textContent = 'Leer';
    if (hint) hint.textContent = 'bestätigt';
    try { navigator.vibrate?.([28, 45, 38]); } catch (_error) {}
    toast('PSI-Speicher gelöscht und als leer bestätigt.');
    await new Promise((resolve) => window.setTimeout(resolve, 650));
  } catch (error) {
    toast(`PSI-Löschen fehlgeschlagen: ${error.message}`);
  } finally {
    setMobilePsiBusy(false);
  }
}

function installMobilePsiDrag() {
  const button = el('mobilePsiButton');
  if (!button) return;

  button.addEventListener('pointerdown', (event) => {
    if (button.disabled || app.mobilePsiDrag.busy) return;
    event.preventDefault();
    ensureListenAudioReady();
    window.clearTimeout(app.mobilePsiDrag.holdTimer);
    app.mobilePsiDrag = {
      active: true,
      armed: false,
      startY: event.clientY,
      pointerId: event.pointerId,
      progress: 0,
      holdTimer: null,
      suppressClick: true,
      busy: false,
    };
    try { button.setPointerCapture(event.pointerId); } catch (_error) {}
    setMobilePsiDragVisual(button, { armed: false, progress: 0 });
    app.mobilePsiDrag.holdTimer = window.setTimeout(() => {
      if (!app.mobilePsiDrag.active || app.mobilePsiDrag.pointerId !== event.pointerId) return;
      app.mobilePsiDrag.armed = true;
      try { navigator.vibrate?.(24); } catch (_error) {}
      setMobilePsiDragVisual(button, { armed: true, progress: app.mobilePsiDrag.progress });
    }, 360);
  });

  button.addEventListener('pointermove', (event) => {
    if (!app.mobilePsiDrag.active || app.mobilePsiDrag.pointerId !== event.pointerId) return;
    event.preventDefault();
    const deltaY = Math.max(0, event.clientY - app.mobilePsiDrag.startY);
    const progress = Math.max(0, Math.min(1, deltaY / 64));
    app.mobilePsiDrag.progress = progress;
    if (app.mobilePsiDrag.armed) setMobilePsiDragVisual(button, { armed: true, progress });
  });

  const finish = async (event, cancelled = false) => {
    if (!app.mobilePsiDrag.active || app.mobilePsiDrag.pointerId !== event.pointerId) return;
    event.preventDefault();
    const armed = app.mobilePsiDrag.armed;
    const progress = app.mobilePsiDrag.progress;
    window.clearTimeout(app.mobilePsiDrag.holdTimer);
    app.mobilePsiDrag.active = false;
    app.mobilePsiDrag.holdTimer = null;
    try { button.releasePointerCapture(event.pointerId); } catch (_error) {}

    if (cancelled) {
      resetMobilePsiDragVisual(button);
    } else if (!armed) {
      resetMobilePsiDragVisual(button);
      await fetchLatestPsiFromTitle();
    } else if (progress >= 1) {
      resetMobilePsiDragVisual(button);
      await clearPsiFromTitle();
    } else {
      resetMobilePsiDragVisual(button);
      toast('Zum Löschen weiter nach unten ziehen.');
    }
    window.setTimeout(() => { app.mobilePsiDrag.suppressClick = false; }, 0);
  };

  button.addEventListener('pointerup', (event) => finish(event, false));
  button.addEventListener('pointercancel', (event) => finish(event, true));
  button.addEventListener('click', (event) => {
    event.preventDefault();
    if (app.mobilePsiDrag.suppressClick) event.stopPropagation();
  });
  button.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter' && event.key !== ' ') return;
    event.preventDefault();
    fetchLatestPsiFromTitle();
  });
}

function bindEvents() {
  installClearButtons();
  document.querySelectorAll('.tab').forEach((tab) => {
    tab.addEventListener('click', () => {
      if (tab.id === 'roomContextTab') {
        activateTab('customer');
        openRoomReminderDialog({ manual: true });
        return;
      }
      activateTab(tab.dataset.tab);
    });
  });

  el('connectButton').addEventListener('click', connectTcp);
  el('disconnectButton').addEventListener('click', disconnectTcp);
  el('listenModeButton')?.addEventListener('click', toggleListenMode);
  el('mobileListenModeButton')?.addEventListener('click', toggleListenMode);
  el('mobileTasAButton')?.addEventListener('click', sendTasAFromTitle);
  el('leitungenButton').addEventListener('click', () => runSequence('leitungen'));
  el('skButton').addEventListener('click', () => runSequence('sk'));
  el('saveButton').addEventListener('click', saveRecord);
  installMobileSaveDrag();
  installMobilePsiDrag();
  el('mobileSaveButton')?.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter' && event.key !== ' ') return;
    event.preventDefault();
    stepCaptureField(1);
  });
  el('mobileScanIdButton')?.addEventListener('pointerdown', (event) => event.preventDefault());
  el('mobileScanIdButton')?.addEventListener('click', () => startIdScanner());
  el('desktopScanIdButton')?.addEventListener('click', () => startIdScanner());
  el('barcodeScannerCancelButton')?.addEventListener('click', () => stopIdScanner({ focusInput: true }));
  el('barcodeScannerDialog')?.addEventListener('cancel', (event) => { event.preventDefault(); stopIdScanner({ focusInput: true }); });
  el('sequenceCancelButton').addEventListener('click', () => cancelRunningSequence({ reset: false }));
  const cancelResetButton = el('sequenceCancelResetButton');
  cancelResetButton.addEventListener('pointerdown', (event) => {
    event.preventDefault();
    app.longPressTriggered = false;
    window.clearTimeout(app.longPressTimer);
    app.longPressTimer = window.setTimeout(() => {
      app.longPressTriggered = true;
      cancelRunningSequence({ reset: true });
    }, 650);
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach((eventName) => {
    cancelResetButton.addEventListener(eventName, () => {
      window.clearTimeout(app.longPressTimer);
      app.longPressTimer = null;
    });
  });
  cancelResetButton.addEventListener('click', (event) => {
    event.preventDefault();
    if (!app.longPressTriggered) toast('Für Reset bitte lange drücken. Kurzer Tipp macht hier absichtlich nichts.');
  });
  el('unsavedSaveButton').addEventListener('click', async () => {
    try {
      const saved = await saveRecord();
      if (saved) await continuePendingSequenceAfterClear();
    } catch (error) {
      toast(error.message);
    }
  });
  el('unsavedDiscardButton').addEventListener('click', async () => {
    try {
      await discardCurrentMeasurement();
      await continuePendingSequenceAfterClear();
    } catch (error) {
      toast(error.message);
    }
  });
  el('unsavedCancelButton').addEventListener('click', () => { app.pendingSequenceKind = null; closeDialog(el('unsavedMeasurementDialog')); });
  el('sendCommandButton').addEventListener('click', () => sendCommand());
  el('commandInput').addEventListener('keydown', (event) => {
    if (event.key === 'Enter') sendCommand();
  });

  document.querySelectorAll('[data-command]').forEach((button) => {
    button.addEventListener('click', () => sendCommand(button.dataset.command));
  });

  el('manualMesButton').addEventListener('click', () => manualAction('/api/manual/mes', 'MES? abgefragt.'));
  el('manualEnterButton').addEventListener('click', () => manualAction('/api/manual/enter', 'ENTER gesendet.'));
  el('resetInitButton').addEventListener('click', () => manualAction('/api/manual/reset-init', 'Reset + Adressierung abgeschlossen.'));

  draftFields.forEach((field) => {
    const node = el(`field-${field}`);
    if (!node) return;
    node.addEventListener('input', () => {
      scheduleDraftSave();
      updateMobileContext();
      updateMobileCaptureDisplay({ syncInput: false });
    });
  });
  el('field-id').addEventListener('input', () => refreshSuggestions('id'));
  el('field-geraeteart').addEventListener('input', () => refreshSuggestions('geraeteart'));
  el('field-hersteller').addEventListener('input', () => refreshSuggestions('hersteller'));
  captureFields.forEach((field) => {
    const node = el(`field-${field}`);
    if (!node) return;
    node.addEventListener('focus', () => {
      if (app.activeCaptureField !== field) activateCaptureField(field, { focus: false });
      refreshSuggestions(field, { forceRender: true });
    });
  });
  el('field-geraeteart').addEventListener('blur', () => {
    finalizeCaptureField('geraeteart');
    refreshSuggestions('hersteller');
  });
  el('field-geraeteart').addEventListener('change', () => {
    finalizeCaptureField('geraeteart');
    refreshSuggestions('hersteller');
  });

  document.querySelectorAll('[data-capture-field]').forEach((row) => {
    row.setAttribute('tabindex', '-1');
    row.addEventListener('pointerdown', (event) => { event.preventDefault(); activateCaptureField(row.dataset.captureField); });
    row.addEventListener('mousedown', (event) => event.preventDefault());
  });
  el('mobileFieldInput').addEventListener('input', writeMobileInputToActiveField);
  el('mobileFieldInput').addEventListener('focus', () => {
    app.captureTarget = app.activeCaptureField;
    updateMobileCaptureDisplay({ syncInput: false });
    lockMobileCaptureViewport({ position: false });
    refreshSuggestions(app.activeCaptureField, { forceRender: true });
  });
  el('mobileFieldInput').addEventListener('keydown', (event) => {
    if (event.key === 'Enter') { event.preventDefault(); stepCaptureField(1); }
    if (event.key === 'Tab') { event.preventDefault(); stepCaptureField(event.shiftKey ? -1 : 1); }
  });
  // No continuous scroll correction here: after the initial alignment the user
  // can move the page manually, and all three fields keep that chosen position.

  el('roomReminderCloseButton')?.addEventListener('click', () => closeRoomReminder({ save: false }));
  el('roomReminderForm')?.addEventListener('submit', (event) => { event.preventDefault(); closeRoomReminder({ save: true }); });
  el('roomReminderDialog')?.addEventListener('cancel', (event) => { event.preventDefault(); closeRoomReminder({ save: false }); });

  el('settingsButton').addEventListener('click', () => { renderCustomListenSoundInfo(); el('settingsDialog').showModal(); });
  el('settingsCancelButton').addEventListener('click', () => el('settingsDialog').close());
  el('setting-clear-listen-sound')?.addEventListener('click', clearCustomListenSound);
  el('settingsSaveButton').addEventListener('click', saveSettings);
  el('setting-device-addressing')?.addEventListener('change', (event) => {
    const enabled = Boolean(event.target.checked);
    document.querySelectorAll('.addressing-dependent-setting').forEach((node) => node.classList.toggle('setting-disabled', !enabled));
    if (el('setting-rst-address')) el('setting-rst-address').disabled = !enabled;
  });
  el('projectImportInput')?.addEventListener('change', (event) => importExcel(event.target.files?.[0]));
  el('projectNewButton')?.addEventListener('click', newProjectDraft);
  el('projectSaveButton')?.addEventListener('click', saveProject);
  el('projectLoadButton')?.addEventListener('click', loadSelectedProject);
  el('projectSelect')?.addEventListener('change', () => {
    const selected = (app.state?.projects || []).find((project) => String(project.id) === el('projectSelect')?.value);
    if (selected) {
      fillProjectForm(selected, { overwriteFocused: true });
    }
  });

  el('historyButton').addEventListener('click', openHistory);
  el('historyCloseButton').addEventListener('click', () => el('historyDialog').close());
  el('historySearch').addEventListener('input', renderHistory);
  el('historySort').addEventListener('change', loadHistory);
  el('historyResultFilter').addEventListener('change', renderHistory);

  el('editCancelButton').addEventListener('click', () => el('editRecordDialog').close());
  el('editSaveButton').addEventListener('click', saveEditedRecord);

  el('customCancelButton').addEventListener('click', () => el('customButtonDialog').close());
  el('customSaveButton').addEventListener('click', saveCustomButton);

  el('clearLogButton').addEventListener('click', () => {
    app.visibleLogs = [];
    renderTerminal();
  });
}

window.addEventListener('DOMContentLoaded', async () => {
  loadLastCaptureSuggestions();
  loadCustomListenSound();
  bindEvents();
  await loadInitialState();
  startMeasurementRatePolling();
  connectWebSocket();
  // During field testing Chrome kept serving an old cached UI via the previous
  // service worker. For the mobile capture workflow we prefer fresh local files.
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistrations()
      .then((regs) => Promise.all(regs.map((reg) => reg.unregister())))
      .catch(() => {});
  }
  if ('caches' in window) {
    caches.keys()
      .then((keys) => Promise.all(keys.map((key) => caches.delete(key))))
      .catch(() => {});
  }
  refreshSuggestions('id', { forceRender: true });
  refreshSuggestions('geraeteart');
  refreshSuggestions('hersteller');
});
